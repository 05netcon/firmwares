/*
 *------------------------------------------------------------------
 * menu resource file
 * Copyright (c) 2006, 2008, 2012 by cisco Systems, Inc.
 *------------------------------------------------------------------
*/

var re_menu_txt_contents = "Contents";
var re_menu_txt_dashboard = "Dashboard";
var re_menu_txt_configure = "Configure";
var re_menu_txt_smartports = "Smartports";
var re_menu_txt_portset = "Port Settings";
var re_menu_txt_exsetup = "Express Setup";
var re_menu_txt_vlans = "VLANs";
var re_menu_txt_snmp = "SNMP";
var re_menu_txt_snmplog = "Syslog";
var re_menu_txt_ethchan = "EtherChannels";
var re_menu_txt_userpass = "Users and Passwords";
var re_menu_txt_restartreload = "Restart / Reset";
var re_menu_txt_monitor = "Monitor";
var re_menu_txt_trends = "Trends";
var re_menu_txt_portstatus = "Port Status";
var re_menu_txt_portstatistics = "Port Statistics";
var re_menu_txt_alertlog = "Alert Log";
var re_menu_txt_diag = "Diagnostics";
var re_menu_txt_softupgrade = "Software Upgrade";
var re_menu_txt_netassist = "Network Assistant";
var re_menu_txt_maintenance = "Maintenance";
var re_menu_txt_intro = "Introduction";
var re_menu_txt_legend = "Legend";
var re_menu_txt_support = "Support";
var re_menu_txt_telnet = "Telnet";
var re_menu_txt_sdflashcard = "SD Flash Card";

//new strings
var re_menu_txt_controllerDM = "Controller Device Manager";

//Added on Aug 4 for Xmen2
var re_menu_txt_dhcp = "DHCP";
var re_menu_txt_ptp = "PTP";

