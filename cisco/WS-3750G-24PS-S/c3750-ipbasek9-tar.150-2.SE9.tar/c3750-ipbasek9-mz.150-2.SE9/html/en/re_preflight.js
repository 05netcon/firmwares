/*
 *------------------------------------------------------------------
 * preflight resource file
 * Copyright (c) 2006, 2015 by cisco Systems, Inc.
 *------------------------------------------------------------------
*/

var re_preFlt_Ttl1 = "Troubleshooting Operating System Support";
var re_preFlt_Ttl2 = "Troubleshooting Internet Browsers";
var re_preFlt_Ttl3 = "Troubleshooting Internet Browser Support";
var re_preFlt_Ttl4 = "Troubleshooting JavaScript";
var re_preFlt_txt1 = "Operating System";
var re_preFlt_txt2 = "The operating system (OS type, version) is not supported.";
var re_preFlt_txt3 = "These operating systems are supported:";
var re_preFlt_txt4 = "Windows XP, 2000";
var re_preFlt_txt5 = "Click {here} to return to the Startup Report.";
var re_preFlt_txt6 = "JavaScript is not enabled. JavaScript must be enabled before the Device Manager will start.";
var re_preFlt_txt7 = "Enabling JavaScript in Netscape";
var re_preFlt_txt8 = "Choose {Edit > Preferences} to open the Preferences window.";
var re_preFlt_txt9 = "Click {Advanced} under Category to display the Advanced preferences.";
var re_preFlt_txt10 = "In the Advanced area, check {Enable JavaScript}, then click OK.";
var re_preFlt_txt11 = "Click {here} to return";
var re_preFlt_txt12 = "Enabling JavaScript in Internet Explorer";
var re_preFlt_txt13 = "Choose {Tools > Internet Options.}";
var re_preFlt_txt14 = "Click the {Security} tab.";
var re_preFlt_txt15 = "Click {Custom Level}. The Security Settings window opens.";
var re_preFlt_txt16 = "Scroll down to Scripting and click {Enable} under Active scripting.";
var re_preFlt_txt17 = "Click {OK} and then click {Yes} in the Warning dialog box.";
var re_preFlt_txt18 = "Click {OK} to close the Internet Options window.";
var re_preFlt_txt20 = "Internet Browser";
var re_preFlt_txt21 = "The Internet browser ({0}) is not supported";
var re_preFlt_txt22 = "These Internet browsers are supported:"
var re_preFlt_txt23 = "Internet Explorer 5.5 and 6.0";
var re_preFlt_txt24 = "Netscape 7.1";
var re_preFlt_txt25 = "JavaScript";
var re_preFlt_txt26 = "JavaScript has not been enabled.";
var re_preFlt_txt27 = "The device manger will not launch until JavaScript is enabled.";
var re_preFlt_txt28 = "Click {here} for more information.";
var re_preFlt_txt29 = "The Internet browser status is unknown.";
var re_preFlt_txt30 = "Operating System";
var re_preFlt_txt31 = "The operating system status is unknown.";
var re_preFlt_txt32 = "Setup Report";
var re_preFlt_txt33 = "Startup Report";
var re_preFlt_txt34 = "The device manager will not run with the Internet browser {0}";
var re_preFlt_txt35 = "Please upgrade your browser.";
var re_preFlt_txt36 = "The device manager does not support the Internet browser";
var re_preFlt_txt37 = "Click continue to launch with the unsupported browser:";
var re_preFlt_txt38 = "Click {here} for more info.";
var re_preFlt_txt39 = "The Internet browser is supported.";
var re_preFlt_txt40 = "The device manager does not support the operating system {0}.";
var re_preFlt_txt41 = "Click continue to launch with the unsupported system:";
var re_preFlt_txt42 = "The operating system is supported.";
var re_preFlt_txt43 = "Read Write Access";
var re_preFlt_txt44 = "The device manager does not support read-only access for this switch.";
var re_preFlt_txt45 = "Note: The device manager is being accessed in read-write mode.";
var re_preFlt_txt46 = "Step 1";
var re_preFlt_txt47 = "Step 2";
var re_preFlt_txt48 = "Step 3";
var re_preFlt_txt49 = "Step 4";
var re_preFlt_txt50 = "Step 5";
var re_preFlt_txt51 = "Step 6";
var re_preFlt_txt52 = "Step 7";

//Newly added Strings
var re_preFlt_txt53 = "JavaScript has been enabled.";
var re_preFlt_txt54 = "The read-write access mode is unknown.";
var dt = new Date();
var re_preFlt_txt55 = "Copyright (c) : 2004-" + dt.getFullYear() + " by Cisco Systems, Inc.";
var re_preFlt_txt56 = "Continue";

 
 
