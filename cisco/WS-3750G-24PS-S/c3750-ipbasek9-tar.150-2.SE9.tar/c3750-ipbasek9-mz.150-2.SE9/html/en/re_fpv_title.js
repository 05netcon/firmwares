/*
 *------------------------------------------------------------------
 * FPV, topframe resource file
 * Copyright (c) 2006-2009 by cisco Systems, Inc.
 *------------------------------------------------------------------
*/

var re_fpv_txt_status = "Status";
var re_fpv_txt_duplex = "Duplex";
var re_fpv_txt_speed = "Speed";
var re_fpv_txt_power = "Power";
var re_fpv_txt_poe = "PoE";
var re_fpv_txt_view = "View";
var re_fpv_txt_nextrefresh1 = "Next refresh in {0} second";
var re_fpv_txt_nextrefresh2 = "Next refresh in {0} seconds";
var re_fpv_txt_refreshing = "Refreshing...";
var re_fpv_txt_refreshpause = "Refreshing Paused";
var re_fpv_txt_movepointer = "Move the pointer over the ports for more information.";
var re_fpv_Tltp_port = "Port";
var re_fpv_Tltp_type = "Type";
var re_fpv_Tltp_descr = "Description";
var re_fpv_Tltp_uptime = "Uptime";
var re_fpv_Tltp_poe = "PoE";
var re_fpv_Tltp_noalert = "No Alerts";
var re_fpv_Tltp_severity = "Severity";
var re_fpv_Tltp_event = "Event";
var re_fpv_Tltp_time = "Time";
var re_fpv_Tltp_viewallalert = "View all Alerts";
var re_Ttl_txt_catseriesdevmanager = "Catalyst {0} Series Device Manager";
var re_Ttl_txt_catseriesexsetup = "Catalyst {0} Series Express Setup";
var re_Ttl_txt_catexsetup =  "Catalyst Express Setup";
var re_Ttl_txt_catdevmanager = "Catalyst Device Manager";
var re_Ttl_txt_registernow = "Register Now";
var re_Ttl_txt_devmanager = "Device Manager";
var re_SSL_txt_session = "Session";
var re_SSL_txt_normalmode = "Normal Mode";
var re_SSL_txt_securemode = "Secure Mode";
var re_SSL_txt_standard = "Standard";
var re_SSL_txt_secured = "Secured";
var re_SSL_txt_userpref_WngMsg = "Do you want to make {0} as the default mode?";

//non-macchiato
var re_fpv_txt_switch = "Switch";
var re_fpv_txt_rps = "RPS";
var re_fpv_txt_stack = "Stack";
var re_fpv_txt_iobay = "I/O Bay";
var re_fpv_txt_member = "Member";
var re_fpv_txt_master = "Master";
var re_fpv_Tltp_inline = "Inline Power";
var re_Ttl_txt_esm = "EtherSwitch Service Module Device Manager";
var re_Ttl_txt_cbs3030 = "Catalyst Blade Switch 3030 Device Manager";
var re_Ttl_txt_cbs3020 = "Catalyst Blade Switch 3020 Device Manager";

//Newly added Strings
var re_Ttl_txt_esm_2 = "EtherSwitch Service Module";
var re_Ttl_txt_cbs3030_2 = "Catalyst Blade Switch 3030";
var re_Ttl_txt_cbs3020_2 = "Catalyst Blade Switch 3020";
var re_Ttl_txt_catalyst = "Catalyst";
var re_Ttl_txt_softrecover = "Software Recovery";
var re_Ttl_txt_catseries = "Catalyst {0} Series";
var re_Ttl_txt_exsetup = "Express Setup";
var re_Ttl_txt_cbs3110="Catalyst Blade Switch 3110";
var re_Ttl_txt_cbs3120="Catalyst Blade Switch 3120";
var re_Ttl_txt_cbs3130="Catalyst Blade Switch 3130";
var re_Ttl_txt_cbs3032="Catalyst Blade Switch 3032";
var re_Ttl_txt_cbs3012="Catalyst Blade Switch 3012";
var re_Ttl_txt_cbs3120="Catalyst Blade Switch 3125";
//New String added - 03/02/2006
var re_fpv_Tltp_different_mode = "Click this button to select a different Mode";
var re_fpv_txt_Lanugage = "Language";

//Newly added strings (for Falchion)
var re_Ttl_txt_cbs3040="Catalyst Blade Switch 3040";

//Strings added for pixar SKUs
var re_fpv_Tltp_fru = "FRU";
var re_fpv_Tltp_pid = "PID";
var re_fpv_Tltp_fru_information = "FRU Information";
var re_fpv_Tltp_System_Power = "System Power";
var re_fpv_Tltp_PoE_Power = "PoE Power";
var re_fpv_Tltp_Sidinfo = "SID Information";
var re_fpv_Tltp_type = "Type";
var re_fpv_Tltp_System_Power = "System Power";
var re_fpv_Tltp_PoE_Power = "PoE Power";
var re_fpv_Tltp_serial = "Serial Number";
var re_fpv_Tltp_Port = "Port";
var re_fpv_Tltp_IPAddress = "IP Address";
var re_fpv_Tltp_Status = "Status";
var re_fpv_Tltp_EtherManagePort = "Ethernet Management Port";

//Newly added string for EagleEye
var re_Ttl_txt_esm_ee="Enhanced EtherSwitch Service Module";