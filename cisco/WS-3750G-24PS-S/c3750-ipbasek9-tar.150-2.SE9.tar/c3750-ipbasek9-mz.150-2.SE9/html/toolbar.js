/*
 *------------------------------------------------------------------
 * toolbar.js
 *
 * Copyright (c) 2003-2007 by cisco Systems, Inc.
 * All rights reserved.
 *------------------------------------------------------------------
 */

// constants used for aligning the toolbar icons.
var LEFT = 1;
var RIGHT = 2;
var imagesArray = new Array();
var tb_logo_off = preloadImage("/images/logo.gif");
var toolbarGradient3px = preloadImage("/images/toolbarGradient3px.gif");
var toolbarButtonDownLeft = preloadImage("/images/toolbarButtonDownLeft.gif");
var toolbarButtonDownRight = preloadImage("/images/toolbarButtonDownRight.gif");
var toolbar_button_right = preloadImage("/images/toolbar_button_right.gif");
var toolbar_button_left = preloadImage("/images/toolbar_button_left.gif");
var toolbar_button_tile = preloadImage("/images/toolbar_button_tile.gif");
var toolbarButtonDownTile = preloadImage("/images/toolbarButtonDownTile.gif");
var toolbarGradient = preloadImage("/images/toolbarGradient.gif");
var toolbar_back = preloadImage("/images/toolbar_back.gif");
var toolbar_forward = preloadImage("/images/toolbar_forward.gif");
var toolbar_help = preloadImage("/images/toolbar_help.gif");
var toolbar_legend = preloadImage("/images/toolbar_legend.gif");
var toolbar_print = preloadImage("/images/toolbar_print.gif");
var toolbar_refresh = preloadImage("/images/toolbar_refresh.gif");
var toolbar_smartports = preloadImage("/images/toolbar_smartports.gif");
var toolbar_swupgrade = preloadImage("/images/toolbar_swupgrade.gif");

function Icon(name, tip, fn, url, align) {
	this.name = name;
	this.tooltip = tip;
	this.action = fn;
	this.url = url;
	this.align = align;
	this.id = 0;
	this.draw = _drawIcon;
}

function handleTbClick(id) {
	if(toolbar.frozen) {
		alert(toolbar.freezeReason);
		return;
	}
	if((id != null) && (toolbar.icons[id].action)) {
		toolbar.icons[id].action();
	}
}

function getImage(name){
	switch (name){
		case "back":
		      return toolbar_back.src;
		case "forward":
		      return toolbar_forward.src;
		case "help":
		      return toolbar_help.src;
		case "legend":
		      return toolbar_legend.src;
		case "print":
		      return toolbar_print.src;
		case "refresh":
		      return toolbar_refresh.src;
		case "smartports":
		      return toolbar_smartports.src;
		case "swupgrade":
		      return toolbar_swupgrade.src;
	}
	
}

function _drawIcon() {
	var width;
	var classname = 'cuesToolbarIconleft';
	var str = new StringBuffer();
	var image = getImage(this.name);
	str.append("<td border='0' cellpadding='0' cellspacing='0'>");
	str.append("<table id='tb"+this.id+"' border='0' cellpadding='0' cellspacing='0' onMouseOver='makeButton(&quot;tb"+this.id+"&quot;);' onmouseout='clearButton(&quot;tb"+this.id+"&quot;);' onMouseDown='makeButtonDown(&quot;tb"+this.id+"&quot;);' onClick='handleTbClick(" + this.id + ");'>");
	str.append("<tr>");
	str.append("<td width='3' border='1'><img name='tb"+this.id+"left' src='"+toolbarGradient3px.src+"' width='3' height='38' alt=''></td>");
	switch (this.name){
		case "back":
		case "forward":
			width=15;
			classname = 'cuesToolbarIconright';
			break;			
		case "help":
			width=16;
			break;
		case "legend":
			width=17;
			break;
		default:
			width=24;
			break;
	}
	str.append("<td nowrap class='cuesToolbarCell' id='tb"+this.id+"center' ><img class='"+classname+"'  src='"+image+"'  width='"+width+"' height='24' border='0' alt=''>"+this.tooltip+"</td>");
	str.append("<td width='3'><img name='tb"+this.id+"right' src='"+toolbarGradient3px.src+"' width='3' height='38' alt='' ></td>");
	str.append("</tr>");
	str.append("</table>");
	str.append("</td>");
	return str.toString();
}

function Toolbar() {
	this.icons = new Array();
	this.addIcon = _addTbIcon;
	this.draw = _drawToolbar;
	this.leftIcons = 0;
	this.freeze = _freezeToolbar;
	this.unFreeze = _unFreezeToolbar;
	this.frozen = false;
	this.freezeReason = null;
}

function _freezeToolbar(reason) {
	if(reason == null)
		return;
	this.freezeReason = reason;
	this.frozen = true;
}

function _unFreezeToolbar() {
	this.freezeReason = null;
	this.frozen = false;
}

function _addTbIcon(icon) {
	icon.id = this.icons.length;
	this.icons[this.icons.length] = icon;
	if(icon.align == LEFT) this.leftIcons++;
}

function spacer() {
	var str = "<td width='5'><img width='5' src='images/spacer.gif'></img></td>"
	return str;
}

function drawLogo() {
	var str = new StringBuffer();
	str.append("<td width='70' nowrap>");
	str.append("<a href='http://www.cisco.com' target='_cisco' id='cisco_url'><img src='" + tb_logo_off.src + "' height='34' title='' onClick='' style='border:none'></img></a>");
	str.append("</td>");
	return str;
}

var toolbarObject = null;
function _drawToolbar() {
	var str = new StringBuffer();
	str.append("<table border='0' cellspacing='0' cellpadding='0' height='34' width=100% id='toolTable'><tr>");
	for (var i=0; i<this.icons.length; i++) {
		str.append(this.icons[i].draw());
		if (i == (this.icons.length-1)) {
			str.append("<td width='100%'>&nbsp;</td>");
		}
	}
	str.append(drawLogo());
	str.append("</tr></table>");
	return str;
}

function makeButton(id) {
	document.getElementById(id).style.backgroundImage = "url("+toolbar_button_tile.src+")";
	document[id+'left'].src=toolbar_button_left.src;
	document[id+'right'].src=toolbar_button_right.src;
	document.getElementById(id+'center').style.color = "#000000";
}

function makeButtonDown(id) {
	document.getElementById(id).style.backgroundImage = "url("+toolbarButtonDownTile.src+")";
	document[id+'left'].src=toolbarButtonDownLeft.src;
	document[id+'right'].src=toolbarButtonDownRight.src;
	document.getElementById(id+'center').style.color = "#FFFFFF";
}

function clearButton(id) {
	document.getElementById(id).style.backgroundImage = "url("+toolbarGradient.src+")";
	document[id+'left'].src=toolbarGradient3px.src;
	document[id+'right'].src=toolbarGradient3px.src;
	document.getElementById(id+'center').style.color = "#000000";
}
function StringBuffer() {
	this.buffer = [];
} 

StringBuffer.prototype.append = function(string) { 
	this.buffer.push(string); 
	return this; 
}

StringBuffer.prototype.toString = function(){ 
	return this.buffer.join(""); 
}

function preloadImage(imagename){
	if ( imagesArray[imagename] == null ) {
		var img = new Image();
		img.src = imagename;
		imagesArray[imagename] = img;
	}
	return imagesArray[imagename];
}
