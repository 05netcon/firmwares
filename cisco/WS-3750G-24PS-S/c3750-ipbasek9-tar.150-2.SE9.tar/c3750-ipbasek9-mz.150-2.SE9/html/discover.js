<!-- Copyright (c) 2005-2011, 2013, 2015 by Cisco Systems, Inc. -->
// discover.js for Cat3750 devices and mirage devices.
//Bullseye devices
/* Mr. Incredible Catalyst 3750 X series
 24 data WS-C3750X-24
 48 data WS-C3750X-48
 24 PoE+ WS-C3750X-24P
 48 PoE+ WS-C3750X-48P
*/
function BULLSEYE24P(int_status, media_type) {
	var dev = new top.device();

	dev.noofports = 26;
	dev.x=0;
	dev.y=0;
	dev.image = "images/c3780_24_4_poe.gif";

	drawLedsForPowerSwitch(dev);
	drawACOK_DCOKLEDs(dev);	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	var xPortGroupGap = 8;
	var xPortStartPos = 320;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 24 FastEthernet ports in 2 groups of 12 each.
	for(i=0; i<24; i++) {       
		if(i%2 == 0) {
			yPortCoord = 17;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 33;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		if(i==11 || i == 23) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    	}
	var intNames = new Array();
	var portInd = 24;
	for (i=0; i< int_status.length; i++)
	{
		intNames[i] = int_status[i][0];
	}
	var interfaces = "#"+intNames.join('#')+"#";
	if (interfaces.indexOf("0/25") != -1)
	{
		// Add the 2 sfp ports
		xPortCoord = 597;
		xPortGap = 1;
		portWidth = 21;
		for(i=portInd; i<portInd+2; i++) 
		{       
			yPortCoord = 13;		
			port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
			port.index = i;
			port.x = xPortCoord;
			port.y = yPortCoord;
			port.id = "port_" + i;
			xPortCoord += (portWidth + xPortGap);
			dev.addPort(port);
		}
		portInd+=2;
		addLabel(dev,25,26);
	}

	if (interfaces.indexOf("0/27") != -1)
	{
		// Add the 2 sfp ports
		xPortCoord = 597;
		xPortGap = 1;
		portWidth = 21;
		for(i=portInd; i<portInd+2; i++) 
		{       
			yPortCoord = 37;		
			port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
			port.index = i;
			port.x = xPortCoord;
			port.y = yPortCoord;
			port.id = "port_" + i;
			xPortCoord += (portWidth + xPortGap);
			dev.addPort(port);
		}
		portInd+=2;
		addLabel(dev,27,28);
	}
	if (interfaces.indexOf("0/25") == -1)
	{
		// Add the 1 10G X2 module
		xPortCoord = 597;
		yPortCoord = 13;		
		port = new top.tenGbSFPport(int_status[portInd][6], portImages); // pass the module type plugged-in the SFP slot
		port.index = portInd;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + portInd;
		dev.addPort(port);
		addLabel(dev,1);
		portInd+=1;
	}
	if (interfaces.indexOf("0/27") == -1)
	{
		// Add the 1 10G X2 module
		xPortCoord = 597;
		yPortCoord = 37;		
		port = new top.tenGbSFPport(int_status[portInd][6], portImages); // pass the module type plugged-in the SFP slot
		port.index = portInd;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + portInd;
		addLabel(dev,2);
		dev.addPort(port);
	}

	dev.modeAliases = new Array ("STATUS", "DUPLEX", "SPEED", "STACK", "PoE");	
	return dev;
}

function BULLSEYE24(int_status, media_type) {
	var dev = new top.device();

	dev.noofports = 26;
	dev.x=0;
	dev.y=0;
	dev.image = "images/c3780_24_4_no_poe.gif";

	drawLeds(dev);
        drawACOK_DCOKLEDs(dev);	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	var xPortGroupGap = 8;
	var xPortStartPos = 320;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 24 FastEthernet ports in 2 groups of 12 each.
	for(i=0; i<24; i++) {       
		if(i%2 == 0) {
			yPortCoord = 17;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 33;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		if(i==11 || i == 23) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    	}
	var intNames = new Array();
	var portInd = 24;
	for (i=0; i< int_status.length; i++)
	{
		intNames[i] = int_status[i][0];
	}
	var interfaces = "#"+intNames.join('#')+"#";
	if (interfaces.indexOf("0/25") != -1)
	{
		// Add the 2 sfp ports
		xPortCoord = 597;
		xPortGap = 1;
		portWidth = 21;
		for(i=portInd; i<portInd+2; i++) 
		{       
			yPortCoord = 13;		
			port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
			port.index = i;
			port.x = xPortCoord;
			port.y = yPortCoord;
			port.id = "port_" + i;
			xPortCoord += (portWidth + xPortGap);
			dev.addPort(port);
		}
		portInd+=2;
		addLabel(dev,25,26);
	}

	if (interfaces.indexOf("0/27") != -1)
	{
		// Add the 2 sfp ports
		xPortCoord = 597;
		xPortGap = 1;
		portWidth = 21;
		for(i=portInd; i<portInd+2; i++) 
		{       
			yPortCoord = 37;		
			port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
			port.index = i;
			port.x = xPortCoord;
			port.y = yPortCoord;
			port.id = "port_" + i;
			xPortCoord += (portWidth + xPortGap);
			dev.addPort(port);
		}
		portInd+=2;
		addLabel(dev,27,28);

	}
	if (interfaces.indexOf("0/25") == -1)
	{
		// Add the 1 10G X2 module
		xPortCoord = 597;
		yPortCoord = 13;		
		port = new top.tenGbSFPport(int_status[portInd][6], portImages); // pass the module type plugged-in the SFP slot
		port.index = portInd;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + portInd;
		dev.addPort(port);
		addLabel(dev,1);
		portInd+=1;
	}
	if (interfaces.indexOf("0/27") == -1)
	{
		// Add the 1 10G X2 module
		xPortCoord = 597;
		yPortCoord = 37;		
		port = new top.tenGbSFPport(int_status[portInd][6], portImages); // pass the module type plugged-in the SFP slot
		port.index = portInd;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + portInd;
		dev.addPort(port);
		addLabel(dev,2);
	}

	dev.modeAliases = new Array ("STATUS", "DUPLEX", "SPEED", "STACK");	
	return dev;
}


function BULLSEYE48P(int_status, media_type) {
	var dev = new top.device();

	dev.noofports = 26;
	dev.x=0;
	dev.y=0;
	dev.image = "images/c3780_48_4_poe.gif";

	drawLedsForPowerSwitch(dev);
        drawACOK_DCOKLEDs(dev);	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	var xPortGroupGap = 8;
	var xPortStartPos = 66;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 24 FastEthernet ports in 4 groups of 12 each.
	for(i=0; i<48; i++) {       
		if(i%2 == 0) {
			yPortCoord = 17;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 33;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		if(i==11 || i == 23 || i == 35 ) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    	}
	var intNames = new Array();
	var portInd = 48;
	for (i=0; i< int_status.length; i++)
	{
		intNames[i] = int_status[i][0];
	}
	var interfaces = "#"+intNames.join('#')+"#";
	if (interfaces.indexOf("0/49") != -1)
	{
		// Add the 2 sfp ports
		xPortCoord = 597;
		xPortGap = 1;
		portWidth = 21;
		for(i=portInd; i<portInd+2; i++) 
		{       
			yPortCoord = 13;		
			port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
			port.index = i;
			port.x = xPortCoord;
			port.y = yPortCoord;
			port.id = "port_" + i;
			xPortCoord += (portWidth + xPortGap);
			dev.addPort(port);
		}
		portInd+=2;
		addLabel(dev,49,50);

	}

	if (interfaces.indexOf("0/51") != -1)
	{
		// Add the 2 sfp ports
		xPortCoord = 597;
		xPortGap = 1;
		portWidth = 21;
		for(i=portInd; i<portInd+2; i++) 
		{       
			yPortCoord = 37;		
			port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
			port.index = i;
			port.x = xPortCoord;
			port.y = yPortCoord;
			port.id = "port_" + i;
			xPortCoord += (portWidth + xPortGap);
			dev.addPort(port);
		}
		portInd+=2;
		addLabel(dev,51,52);
	}
	if (interfaces.indexOf("0/49") == -1)
	{
		// Add the 1 10G X2 module
		xPortCoord = 597;
		yPortCoord = 13;		
		port = new top.tenGbSFPport(int_status[portInd][6], portImages); // pass the module type plugged-in the SFP slot
		port.index = portInd;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + portInd;
		dev.addPort(port);
		addLabel(dev,1);
		portInd+=1;
	}
	if (interfaces.indexOf("0/51") == -1)
	{
		// Add the 1 10G X2 module
		xPortCoord = 597;
		yPortCoord = 37;		
		port = new top.tenGbSFPport(int_status[portInd][6], portImages); // pass the module type plugged-in the SFP slot
		port.index = portInd;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + portInd;
		dev.addPort(port);
		addLabel(dev,2);
	}

	dev.modeAliases = new Array ("STATUS", "DUPLEX", "SPEED", "STACK", "PoE");	
	return dev;
}
function SLINKY12(int_status, media_type){
var dev = new top.device();

	dev.noofports = 14;
	dev.x=0;
	dev.y=0;
	dev.image = "images/c3750e_12sd.gif";
	dev.type = "WS-C3750E-12SD";
	drawLedsforSlinky(dev);
    drawACOKLEDs(dev);	

	// Create the ports
	var port;
	var portWidth = 21;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	var xPortGroupGap = 14;
	var xPortStartPos = 200;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	for(i=0; i<12; i++) {       
		
		yPortCoord = 30;
		port = new top.SFPport(int_status[i][6]); 
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		xPortCoord += (portWidth + xPortGap);
		if (i==3 || i==7) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }
	var intNames = new Array();
	var portInd = 12;
	for (i=0; i< int_status.length; i++)
	{
		intNames[i] = int_status[i][0];
	}
	var interfaces = "#"+intNames.join('#')+"#";
	if (interfaces.indexOf("0/13") != -1)
	{
		// Add the 2 sfp ports
		xPortCoord = 597;
		xPortGap = 1;
		portWidth = 21;
		for(i=portInd; i<portInd+2; i++) 
		{       
			yPortCoord = 13;		
			port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
			port.index = i;
			port.x = xPortCoord;
			port.y = yPortCoord;
			port.id = "port_" + i;
			xPortCoord += (portWidth + xPortGap);
			dev.addPort(port);
		}
		portInd+=2;
		addLabel(dev,13,14);
	}

	if (interfaces.indexOf("0/15") != -1)
	{
		// Add the 2 sfp ports
		xPortCoord = 597;
		xPortGap = 1;
		portWidth = 21;
		for(i=portInd; i<portInd+2; i++) 
		{       
			yPortCoord = 37;		
			port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
			port.index = i;
			port.x = xPortCoord;
			port.y = yPortCoord;
			port.id = "port_" + i;
			xPortCoord += (portWidth + xPortGap);
			dev.addPort(port);
		}
		portInd+=2;
		addLabel(dev,15,16);

	}
	if (interfaces.indexOf("0/13") == -1)
	{
		// Add the 1 10G X2 module
		xPortCoord = 597;
		yPortCoord = 13;		
		port = new top.tenGbSFPport(int_status[portInd][6], portImages); // pass the module type plugged-in the SFP slot
		port.index = portInd;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + portInd;
		dev.addPort(port);
		addLabel(dev,1);
		portInd+=1;
	}
	if (interfaces.indexOf("0/15") == -1)
	{
		// Add the 1 10G X2 module
		xPortCoord = 597;
		yPortCoord = 37;		
		port = new top.tenGbSFPport(int_status[portInd][6], portImages); // pass the module type plugged-in the SFP slot
		port.index = portInd;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + portInd;
		dev.addPort(port);
		addLabel(dev,2);
	}
	dev.modeAliases = new Array ("STATUS", "DUPLEX", "SPEED", "STACK");	
	return dev;
}
function BULLSEYE48(int_status, media_type) {
	var dev = new top.device();

	dev.noofports = 26;
	dev.x=0;
	dev.y=0;
	dev.image = "images/c3780_48_4_no_poe.gif";

	drawLeds(dev);
        drawACOK_DCOKLEDs(dev);	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	var xPortGroupGap = 8;
	var xPortStartPos = 66;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 24 FastEthernet ports in 4 groups of 12 each.
	for(i=0; i<48; i++) {       
		if(i%2 == 0) {
			yPortCoord = 17;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 33;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		if(i==11 || i == 23 || i == 35 ) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    	}
	var intNames = new Array();
	var portInd = 48;
	for (i=0; i< int_status.length; i++)
	{
		intNames[i] = int_status[i][0];
	}
	var interfaces = "#"+intNames.join('#')+"#";
	if (interfaces.indexOf("0/49") != -1)
	{
		// Add the 2 sfp ports
		xPortCoord = 597;
		xPortGap = 1;
		portWidth = 21;
		for(i=portInd; i<portInd+2; i++) 
		{       
			yPortCoord = 13;		
			port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
			port.index = i;
			port.x = xPortCoord;
			port.y = yPortCoord;
			port.id = "port_" + i;
			xPortCoord += (portWidth + xPortGap);
			dev.addPort(port);
		}
		portInd+=2;		
		addLabel(dev,49,50);
	}

	if (interfaces.indexOf("0/51") != -1)
	{
		// Add the 2 sfp ports
		xPortCoord = 597;
		xPortGap = 1;
		portWidth = 21;
		for(i=portInd; i<portInd+2; i++) 
		{       
			yPortCoord = 37;		
			port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
			port.index = i;
			port.x = xPortCoord;
			port.y = yPortCoord;
			port.id = "port_" + i;
			xPortCoord += (portWidth + xPortGap);
			dev.addPort(port);
		}
		portInd+=2;
		addLabel(dev,51,52);
	}
	if (interfaces.indexOf("0/49") == -1)
	{
		// Add the 1 10G X2 module
		xPortCoord = 597;
		yPortCoord = 13;		
		port = new top.tenGbSFPport(int_status[portInd][6], portImages); // pass the module type plugged-in the SFP slot
		port.index = portInd;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + portInd;
		dev.addPort(port);
		addLabel(dev,1);
		portInd+=1;
	}
	if (interfaces.indexOf("0/51") == -1)
	{
		// Add the 1 10G X2 module
		xPortCoord = 597;
		yPortCoord = 37;		
		port = new top.tenGbSFPport(int_status[portInd][6], portImages); // pass the module type plugged-in the SFP slot
		port.index = portInd;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + portInd;
		dev.addPort(port);
		addLabel(dev,2);
	}

	dev.modeAliases = new Array ("STATUS", "DUPLEX", "SPEED", "STACK");	
	return dev;
}

// Mirage models.

// NME-XD-48ES-2S-P, NME-X-23ES-1G-P
// NME-XD-24ES-1S-P, NME-16ES-1G-P
// NME-XD-48ES-2S, NME-X-23ES-1G
// NME-XD-24ES-1S, NME-16ES-1G

function NMEXD24ES2ST(int_status, media_type) {
//24 FastEthernet Ports
//2 Gig Ports (Gi1/0/2 is internal).
	
	var dev = new top.device();

	dev.noofports = 26; // 25 + 1 internal.
	dev.x=0;
	dev.y=0;
	dev.image = "images/nmexd24es2st.gif";

	drawLedsForMirage(dev, 634, 66, 7, 2);
	
	// Create the Mode Btn
	var modeBtn = new top.modebtn("images/nme_mode.gif");
	modeBtn.x = 616;
	modeBtn.y = 54;
	modeBtn.id = "mode_btn";
	modeBtn.device = dev;
	dev.modebtn = modeBtn;		

	// Create System LEDs
	var ledImages = top.ledImages();
	var tempLed = new top.led(ledImages);
	tempLed.x = 605;
	tempLed.y = 66;
	tempLed.id = "system_led";
	tempLed.device = dev;
	dev.sysleds["SYSTEM"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 594;
	tempLed.y = 66;
	tempLed.id = "master_led";
	tempLed.device = dev;
	dev.sysleds["MASTER"] = tempLed;
		
	tempLed = new top.led(ledImages);
	tempLed.x = 583;
	tempLed.y = 66;
	tempLed.id = "status_led";
	tempLed.device = dev;
	dev.sysleds["STATUS"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 572;
	tempLed.y = 66;
	tempLed.id = "duplex_led";
	tempLed.device = dev;
	dev.sysleds["DUPLEX"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 561;
	tempLed.y = 66;
	tempLed.id = "speed_led";
	tempLed.device = dev;
	dev.sysleds["SPEED"] = tempLed;
	
	tempLed = new top.led(ledImages);
	tempLed.x = 550;
	tempLed.y = 66;
	tempLed.id = "stack_led";
	tempLed.device = dev;
	dev.sysleds["STACK"] = tempLed;
	
	tempLed = new top.led(ledImages);
	tempLed.x = 539;
	tempLed.y = 66;
	tempLed.id = "power_led";
	tempLed.device = dev;
	dev.sysleds["POWER"] = tempLed;

	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 3;
	var xPortGroupGap = 17;
	var xPortStartPos = 292;
	var xPortCoord = xPortStartPos;
	var yPortCoord = 22;

	// Add the 24 FastEthernet ports in two groups of 12 each
	// from right to left
	for(var i=0; i<24; i++) {
		if(i%2 == 0) {
			yPortCoord = 22;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 40;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord -= (portWidth + xPortGap);	
		}
		if(i == 11) {
			xPortCoord -= (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	// Add the 1st GBIC port - Gi1/0/1, Gi1/0/2 is internal
	xPortCoord = 326;
	yPortCoord = 54;
	var i = 24;
	port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
	port.index = i;
	port.x = xPortCoord;
	port.y = yPortCoord;
	port.id = "port_" + i;

	dev.addPort(port);
	dev.modeAliases = new Array ("STATUS", "DUPLEX", "SPEED", "STACK", "PoE");	
	return dev;
}


function NMEXD48ES2GE(int_status, media_type) {
//48 FastEthernet Ports.
//4 Gig Ports (Gi1/0/3 and Gi 1/0/4 are internal).
	
	var dev = new top.device();

	dev.noofports = 52; // 50 + 2 internal.
	dev.x=0;
	dev.y=0;
	dev.image = "images/nmexd48es2ge.gif";

	drawLedsForMirage(dev, 634, 71, 7, 2);
	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 3;
	var xPortGroupGap = 13;
	var xPortStartPos = 559;
	var xPortCoord = xPortStartPos;
	var yPortCoord = 22;

	// Add the 48 FastEthernet ports in three groups of 16 each from
	// right to left
	for(var i=0; i<48; i++) {       
		if(i%2 == 0) {
			yPortCoord = 22;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 40;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord -= (portWidth + xPortGap);	
		}
		if(i == 15 || i == 31) {
			xPortCoord -= (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	// Add the 2 GBIC ports - Gi1/0/1, Gi1/0/2
	// Gi1/0/3 and Gi1/0/4 are internal
	xPortCoord = 617;
	xPortGap = 8;
	yPortCoord = 49;
	portWidth = 21;
	for(i=48; i<50; i++) {
		port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 == 0) {
			xPortCoord -= (portWidth + xPortGap);
		}
		dev.addPort(port);
	}
	
	dev.modeAliases = new Array ("STATUS", "DUPLEX", "SPEED", "STACK", "PoE");	
	return dev;
}

function NMEX24ES1GE(int_status, media_type) {
// 23 FastEthernet Ports (Starts with Fa1/0/2 and ends with Fa1/0/24).
// 2 Gig Ports (Gi1/0/2 is internal).
	var dev = new top.device();

	dev.noofports = 25; // 24 + 1 internal.
	dev.x=137;
	dev.y=0;
	dev.image = "images/nmex24es1ge.gif";

	drawLedsForMirage(dev, 353, 56, 4, 3);
	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 3;
	var xPortGroupGap = 17;
	var xPortStartPos = 308;
	var xPortCoord = xPortStartPos;
	var yPortCoord = 22;

	// Add the 23 FastEthernet ports in two groups of 11 and 12
	// from right to left. First port in the first group is Gi1/0/1
	for(var i=0; i<23; i++) {       
		if(i%2 != 0) {
			yPortCoord = 22;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 40;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 == 0) {
			xPortCoord -= (portWidth + xPortGap);	
		}
		if(i == 10) {
			xPortCoord -= (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	// Add the 1st GBIC port - Gi1/0/1, Gi1/0/2 is internal
	xPortCoord = 308;
	yPortCoord = 22;
	var i = 23;
	port = new top.rj45port(portInvImages);
	port.index = i;
	port.x = xPortCoord;
	port.y = yPortCoord;
	port.id = "port_" + i;

	dev.addPort(port);
	dev.modeAliases = new Array ("STATUS", "DUPLEX", "SPEED", "STACK", "PoE");	
	return dev;
}

function NME16ES1GE(int_status, media_type) {
// 16 Fast Ethernet ports
// 2 Gig Ports (Gi1/0/2 is internal).
	var dev = new top.device();

	dev.noofports = 18;
	dev.x=147;
	dev.y=0;
	dev.image = "images/nme16es1ge.gif";
	
	drawLedsForMirage(dev, 36, 61, 4, 3);

	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 3;
	var xPortGroupGap = 0;
	var xPortStartPos = 246;
	var xPortCoord = xPortStartPos;
	var yPortCoord = 22;

	// Add the 16 FastEthernet ports from right to left
	for(var i=0; i<16; i++) {       
		if(i%2 == 0) {
			yPortCoord = 22;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 40;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord -= (portWidth + xPortGap);	
		}
		dev.addPort(port);
    }

	// Add the 1st GBIC port - Gi1/0/1, Gi1/0/2 is internal
	xPortCoord = 303;
	yPortCoord = 39;
	var i = 16;
	port = new top.rj45port(portInvImages);
	port.index = i;
	port.x = xPortCoord;
	port.y = yPortCoord;
	port.id = "port_" + i;
	dev.addPort(port);

	dev.modeAliases = new Array ("STATUS", "DUPLEX", "SPEED", "STACK", "PoE");	
	return dev;
}

function NMEXD24ES2ST_NO_PWR(int_status, media_type) {
//24 FastEthernet Ports
//2 Gig Ports (Gi1/0/2 is internal).
//No inline power version
	
	var dev = new top.device();

	dev.noofports = 26; // 25 + 1 internal.
	dev.x=0;
	dev.y=0;
	dev.image = "images/nmexd24es2st_no_pwr.gif";

	drawLedsForMirage(dev, 634, 66, 7, 2);
	
	// Create the Mode Btn
	var modeBtn = new top.modebtn("images/nme_mode.gif");
	modeBtn.x = 616;
	modeBtn.y = 54;
	modeBtn.id = "mode_btn";
	modeBtn.device = dev;
	dev.modebtn = modeBtn;		

	// Create System LEDs
	var ledImages = top.ledImages();
	var tempLed = new top.led(ledImages);
	tempLed.x = 605;
	tempLed.y = 66;
	tempLed.id = "system_led";
	tempLed.device = dev;
	dev.sysleds["SYSTEM"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 594;
	tempLed.y = 66;
	tempLed.id = "master_led";
	tempLed.device = dev;
	dev.sysleds["MASTER"] = tempLed;
		
	tempLed = new top.led(ledImages);
	tempLed.x = 583;
	tempLed.y = 66;
	tempLed.id = "status_led";
	tempLed.device = dev;
	dev.sysleds["STATUS"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 572;
	tempLed.y = 66;
	tempLed.id = "duplex_led";
	tempLed.device = dev;
	dev.sysleds["DUPLEX"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 561;
	tempLed.y = 66;
	tempLed.id = "speed_led";
	tempLed.device = dev;
	dev.sysleds["SPEED"] = tempLed;
	
	tempLed = new top.led(ledImages);
	tempLed.x = 550;
	tempLed.y = 66;
	tempLed.id = "stack_led";
	tempLed.device = dev;
	dev.sysleds["STACK"] = tempLed;
	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 3;
	var xPortGroupGap = 17;
	var xPortStartPos = 292;
	var xPortCoord = xPortStartPos;
	var yPortCoord = 22;

	// Add the 24 FastEthernet ports in two groups of 12 each
	// from right to left
	for(var i=0; i<24; i++) {
		if(i%2 == 0) {
			yPortCoord = 22;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 40;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord -= (portWidth + xPortGap);	
		}
		if(i == 11) {
			xPortCoord -= (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	// Add the 1st GBIC port - Gi1/0/1, Gi1/0/2 is internal
	xPortCoord = 326;
	yPortCoord = 54;
	var i = 24;
	port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
	port.index = i;
	port.x = xPortCoord;
	port.y = yPortCoord;
	port.id = "port_" + i;

	dev.addPort(port);
	dev.modeAliases = new Array ("STATUS", "DUPLEX", "SPEED", "STACK");	
	return dev;
}


function NMEXD48ES2GE_NO_PWR(int_status, media_type) {
//48 FastEthernet Ports.
//4 Gig Ports (Gi1/0/3 and Gi 1/0/4 are internal).
//No inline power version
	
	var dev = new top.device();

	dev.noofports = 52; // 50 + 2 internal.
	dev.x=0;
	dev.y=0;
	dev.image = "images/nmexd48es2ge_no_pwr.gif";

	drawLedsForMirage(dev, 634, 71, 7, 2);
	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 3;
	var xPortGroupGap = 13;
	var xPortStartPos = 559;
	var xPortCoord = xPortStartPos;
	var yPortCoord = 22;

	// Add the 48 FastEthernet ports in three groups of 16 each from
	// right to left
	for(var i=0; i<48; i++) {       
		if(i%2 == 0) {
			yPortCoord = 22;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 40;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord -= (portWidth + xPortGap);	
		}
		if(i == 15 || i == 31) {
			xPortCoord -= (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	// Add the 2 GBIC ports - Gi1/0/1, Gi1/0/2
	// Gi1/0/3 and Gi1/0/4 are internal
	xPortCoord = 617;
	xPortGap = 8;
	yPortCoord = 49;
	portWidth = 21;
	for(i=48; i<50; i++) {
		port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 == 0) {
			xPortCoord -= (portWidth + xPortGap);
		}
		dev.addPort(port);
	}
	
	dev.modeAliases = new Array ("STATUS", "DUPLEX", "SPEED", "STACK");	
	return dev;
}

function NMEX24ES1GE_NO_PWR(int_status, media_type) {
// 23 FastEthernet Ports (Starts with Fa1/0/2 and ends with Fa1/0/24).
// 2 Gig Ports (Gi1/0/2 is internal).
// No inline power version
	var dev = new top.device();

	dev.noofports = 25; // 24 + 1 internal.
	dev.x=137;
	dev.y=0;
	dev.image = "images/nmex24es1ge_no_pwr.gif";

	drawLedsForMirage(dev, 353, 56, 4, 3);
	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 3;
	var xPortGroupGap = 17;
	var xPortStartPos = 308;
	var xPortCoord = xPortStartPos;
	var yPortCoord = 22;

	// Add the 23 FastEthernet ports in two groups of 11 and 12
	// from right to left. First port in the first group is Gi1/0/1
	for(var i=0; i<23; i++) {       
		if(i%2 != 0) {
			yPortCoord = 22;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 40;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 == 0) {
			xPortCoord -= (portWidth + xPortGap);	
		}
		if(i == 10) {
			xPortCoord -= (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	// Add the 1st GBIC port - Gi1/0/1, Gi1/0/2 is internal
	xPortCoord = 308;
	yPortCoord = 22;
	var i = 23;
	port = new top.rj45port(portInvImages);
	port.index = i;
	port.x = xPortCoord;
	port.y = yPortCoord;
	port.id = "port_" + i;

	dev.addPort(port);
	dev.modeAliases = new Array ("STATUS", "DUPLEX", "SPEED", "STACK");	
	return dev;
}

function NME16ES1GE_NO_PWR(int_status, media_type) {
// 16 Fast Ethernet ports
// 2 Gig Ports (Gi1/0/2 is internal).
//No inline power version

	var dev = new top.device();

	dev.noofports = 18;
	dev.x=147;
	dev.y=0;
	dev.image = "images/nme16es1ge_no_pwr.gif";
	
	drawLedsForMirage(dev, 36, 61, 4, 3);

	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 3;
	var xPortGroupGap = 0;
	var xPortStartPos = 246;
	var xPortCoord = xPortStartPos;
	var yPortCoord = 22;

	// Add the 16 FastEthernet ports from right to left
	for(var i=0; i<16; i++) {       
		if(i%2 == 0) {
			yPortCoord = 22;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 40;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord -= (portWidth + xPortGap);	
		}
		dev.addPort(port);
    }

	// Add the 1st GBIC port - Gi1/0/1, Gi1/0/2 is internal
	xPortCoord = 303;
	yPortCoord = 39;
	var i = 16;
	port = new top.rj45port(portInvImages);
	port.index = i;
	port.x = xPortCoord;
	port.y = yPortCoord;
	port.id = "port_" + i;
	dev.addPort(port);

	dev.modeAliases = new Array ("STATUS", "DUPLEX", "SPEED", "STACK");	
	return dev;
}

function drawLedsForMirage(dev, x, y, width, height) {
	var ledImages = top.ledImages();
	var tempLed = new top.led(ledImages);
	tempLed.x = x;
	tempLed.y = y;
	tempLed.width = width;
	tempLed.height = height;
	tempLed.id = "en_led";
	tempLed.device = dev;
	dev.sysleds["EN"] = tempLed;
}

//////////////////////// c3750 devices start ////////////////////////////////

// c3750 models.

// WS-C3750-24TS, WS-C3750-48TS, WS-C3750-24P, WS-C3750-48P,
// WS-C3750G-12S, WS-C3750G-24T, WS-C3750G-24TS
// WS-C3750G-16TD, WS-C3750G-48PS, WS-C3750G-48TS, WS-C3750G-24PS,
// WS-C3750G-24TS-1U, WS-C3750-24FS, WS-C3750G-12S-D

function WSC375024FS(int_status, media_type) {
	var dev = new top.device();

	dev.noofports = 26;
	dev.x=0;
	dev.y=0;
	dev.image = "images/c375024FX_2.gif";

	drawLeds(dev);

	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.fxportImages();
	var xPortGap = 1;
	var xPortGroupGap = 14;
	var xPortStartPos = 71;
	var xPortCoord = xPortStartPos;
	var yPortCoord = 51;

	// Add the 24 FastEthernet ports in 3 groups of 8 each.
	for(i=0; i<24; i++) {       
		port = new top.fxport(portImages);
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i ==7 || i == 15 ) {
			xPortCoord += ( portWidth + xPortGroupGap);
		}
		else {
			xPortCoord += (portWidth + xPortGap);	
		}
		dev.addPort(port);
    }

	// Add the 2 GBIC ports.
	xPortCoord = 591;
	xPortGap = 11;
	yPortCoord = 50;
	portWidth = 21;
	for(i=24; i<26; i++) {       
		port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		xPortCoord += (portWidth + xPortGap);
		dev.addPort(port);
	}	
	
	return dev;
}


function WSC375024TS(int_status, media_type) {
	var dev = new top.device();

	dev.noofports = 26;
	dev.x=0;
	dev.y=0;
	dev.image = "images/c375024_2.gif";

	drawLeds(dev);

	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	var xPortGroupGap = 30;
	var xPortStartPos = 110;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 24 FastEthernet ports in 2 groups of 12 each.
	for(i=0; i<24; i++) {       
		if(i%2 == 0) {
			yPortCoord = 25;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 41;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		if(i==11 || i == 23) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	// Add the 2 GBIC ports.
	xPortCoord = 469;
	xPortGap = 45;
	for(i=24; i<26; i++) {       
		yPortCoord = 39;		
		port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		xPortCoord += (portWidth + xPortGap);
		dev.addPort(port);
	}	
	
	return dev;
}


function WSC375048TS(int_status, media_type) {
	var dev = new top.device();
	dev.noofports = 52;
	dev.x=0;
	dev.y=0;
	dev.image = "images/c375048_4.gif";	

    drawLeds(dev);	

	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	var xPortGroupGap = 11;
	var xPortStartPos = 72;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 48 FastEthernet ports in 4 groups of 12 each.
	for(i=0; i<48; i++) {       
		if(i%2 == 0) {
			yPortCoord = 26;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 42;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		if(i==15 || i == 31) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	// Add the 4 SFP ports.
	xPortCoord = 589;
	xPortGap = 12;
	yPortCoord = 25;
	portWidth = 21;
	for(i=48; i<52; i++) {
		port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 == 0) {
			yPortCoord = 47;			
		} else {
			yPortCoord = 25;
			xPortCoord += (portWidth + xPortGap);
		}

		dev.addPort(port);
	}	

	return dev;
}


function WSC375024P(int_status, media_type) {
	var dev = new top.device();

	dev.noofports = 26;
	dev.x=0;
	dev.y=0;
	dev.image = "images/c375024_2p.gif";

	drawLedsForPowerSwitch(dev);
	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	var xPortGroupGap = 30;
	var xPortStartPos = 110;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 24 FastEthernet ports in 2 groups of 12 each.
	for(i=0; i<24; i++) {       
		if(i%2 == 0) {
			yPortCoord = 25;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 41;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		if(i==11 || i == 23) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	// Add the 2 GBIC ports.
	xPortCoord = 469;
	xPortGap = 45;
	for(i=24; i<26; i++) {       
		yPortCoord = 39;		
		port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		xPortCoord += (portWidth + xPortGap);
		dev.addPort(port);
	}	

	dev.modeAliases = new Array ("STATUS", "DUPLEX", "SPEED", "STACK", "PoE");	
	return dev;
}


function WSC3750G12S(int_status, media_type) {
	var dev = new top.device();

	dev.noofports = 12;
	dev.x=0;
	dev.y=0;
	dev.image = "images/c3750g_12s.gif";

    drawLeds(dev);
	
	// Create the ports
	var port;
	var portWidth = 21;
	var xPortGap = 1;
	var xPortGroupGap = 14;
	var xPortStartPos = 319;
	var xPortCoord = xPortStartPos;
	var yPortCoord = 40;

	// Add the 12 GBIC ports in 3 groups of 4 each.
	for(i=0; i<12; i++) {    
		port = new top.SFPport(int_status[i][6]); // pass the module type plugged-in the SFP slot
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.index = i;
		port.id = "port_" + i;
		xPortCoord += (portWidth + xPortGap);
		if (i==3 || i==7) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}

		dev.addPort(port);
	}	
	
	return dev;
}

function WSC375048P(int_status, media_type) {
	var dev = new top.device();

	dev.noofports = 52;
	dev.x=0;
	dev.y=0;
	dev.image = "images/c375048_4p.gif";

    drawLedsForPowerSwitch(dev);	
	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	var xPortGroupGap = 11;
	var xPortStartPos = 72;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 48 FastEthernet ports in 4 groups of 12 each.
	for(i=0; i<48; i++) {       
		if(i%2 == 0) {
			yPortCoord = 26;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 42;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		if(i==15 || i == 31) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	// Add the 4 SFP ports.
	xPortCoord = 587;
	xPortGap = 12;
	yPortCoord = 25;
	portWidth = 21;
	for(i=48; i<52; i++) {
		port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 == 0) {
			yPortCoord = 46;			
		} else {
			yPortCoord = 25;
			xPortCoord += (portWidth + xPortGap);
		}

		dev.addPort(port);
	}	

	dev.modeAliases = new Array ("STATUS", "DUPLEX", "SPEED", "STACK", "PoE");	
	return dev;
}



function WSC3750G24T(int_status, media_type) {
	var dev = new top.device();

	dev.noofports = 24;
	dev.x=0;
	dev.y=0;
	dev.image = "images/c3750g_24_0.gif";

    drawLeds(dev);
	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	var xPortGroupGap = 84;
	var xPortStartPos = 159;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 24 FastEthernet ports in 2 groups of 12 each.
	for(i=0; i<24; i++) {       
		if(i%2 == 0) {
			yPortCoord = 25;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 41;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		if(i==11 || i == 23) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	return dev;
}



function WSC3750G24TS(int_status, media_type) {
	var dev = new top.device();

	dev.noofports = 28;
	dev.x=0;
	dev.y=0;
	dev.image = "images/c3750g_24_4.gif";

	// Create the Mode Btn
	var modeBtn = new top.modebtn("images/c375024_2_mode.gif");
	modeBtn.x = 33; 
	modeBtn.y = 83;
	modeBtn.id = "mode_btn";
	modeBtn.device = dev;
	dev.modebtn = modeBtn;		

	// Create System LEDs
	var ledImages = top.ledImages();
	var tempLed = new top.led(ledImages);
	tempLed.x = 11; 
	tempLed.y = 41; 
	tempLed.id = "system_led";
	tempLed.device = dev;
	dev.sysleds["SYSTEM"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 11; 
	tempLed.y = 47; 
	tempLed.id = "rps_led";
	tempLed.device = dev;
	dev.sysleds["RPS"] = tempLed;
	
	tempLed = new top.led(ledImages);
	tempLed.x = 11; 
	tempLed.y = 53; 
	tempLed.id = "master_led";
	tempLed.device = dev;
	dev.sysleds["MASTER"] = tempLed;
	
	tempLed = new top.led(ledImages);
	tempLed.x = 11; 
	tempLed.y = 59; 
	tempLed.id = "status_led";
	tempLed.device = dev;
	dev.sysleds["STATUS"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 11;
	tempLed.y = 65; 
	tempLed.id = "duplex_led";
	tempLed.device = dev;
	dev.sysleds["DUPLEX"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 11; 
	tempLed.y = 71; 
	tempLed.id = "speed_led";
	tempLed.device = dev;
	dev.sysleds["SPEED"] = tempLed;
	
	tempLed = new top.led(ledImages);
	tempLed.x = 11; 
	tempLed.y = 77;
	tempLed.id = "stack_led";
	tempLed.device = dev;
	dev.sysleds["STACK"] = tempLed;
	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	var xPortGroupGap = 55;
	var xPortStartPos = 128; 
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 24 FastEthernet ports in 2 groups of 12 each.
	for(i=0; i<24; i++) {       
		if(i%2 == 0) {
			yPortCoord = 40; 
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 56; 
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		if(i==11 || i == 23) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	// Add the 4 GBIC ports.
	xPortCoord = 498;
	xPortGap = 1;
	portWidth = 21;
	for(i=24; i<28; i++) {       
		yPortCoord = 55; 		
		port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		xPortCoord += (portWidth + xPortGap);
		dev.addPort(port);
	}	
	
	return dev;
}



function WSC3750G16TD(int_status, media_type) {
	var dev = new top.device();

	dev.noofports = 17;
	dev.x=0;
	dev.y=0;
	dev.image = "images/c3750g_16td.gif";

    drawLeds(dev);

	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	
	var xPortStartPos = 165;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 24 FastEthernet ports in 2 groups of 12 each.
	for(i=0; i<16; i++) {       
		if(i%2 == 0) {
			yPortCoord = 25;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 41;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		dev.addPort(port);
    }

	// Add the 1 10 Gig port.
	xPortCoord = 569;
	i=16;	     
	yPortCoord = 49;
	port = new top.tenGigport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
	port.index = i;   
	port.x = xPortCoord;
	port.y = yPortCoord;
	port.id = "port_" + i;
	dev.addPort(port);	
	
	return dev;
}



function WSC3750G24PS(int_status, media_type) {
	var dev = new top.device();

	dev.noofports = 28;
	dev.x=0;
	dev.y=0;
	dev.image = "images/c3750g24_4p.gif";

	drawLedsForPowerSwitch(dev);
	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	var xPortGroupGap = 33;
	var xPortStartPos = 288;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 24 FastEthernet ports in 2 groups of 12 each.
	for(i=0; i<24; i++) {       
		if(i%2 == 0) { 
			yPortCoord = 28;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 44;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		if(i==11 || i == 23) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	// Add the 4 SFP ports.
	xPortCoord = 584;
	xPortGap = 16;
	yPortCoord = 26;
	portWidth = 21;
	for(i=24; i<28; i++) {
		port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 == 0) {
			yPortCoord = 48;			
		} else {
			yPortCoord = 26;
			xPortCoord += (portWidth + xPortGap);
		  }
                dev.addPort(port);
         }

	dev.modeAliases = new Array ("STATUS", "DUPLEX", "SPEED", "STACK", "PoE");	
	return dev;
}

function WSC3750G24TS1U(int_status, media_type) {
	var dev = new top.device();

	dev.noofports = 28;
	dev.x=0;
	dev.y=0;
	dev.image = "images/c3750g24_4.gif";

    drawLeds(dev);
	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	var xPortGroupGap = 33;
	var xPortStartPos = 288;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 24 FastEthernet ports in 2 groups of 12 each.
	for(i=0; i<24; i++) {       
		if(i%2 == 0) {
			yPortCoord = 28;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 44;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		if(i==11 || i == 23) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	// Add the 4 SFP ports.
	xPortCoord = 584;
	xPortGap = 16;
	yPortCoord = 26;
	portWidth = 21;
	for(i=24; i<28; i++) {
		port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 == 0) {
			yPortCoord = 48;			
		} else {
			yPortCoord = 26;
			xPortCoord += (portWidth + xPortGap);
		  }
                dev.addPort(port);
         }

	dev.modeAliases = new Array ("STATUS", "DUPLEX", "SPEED", "STACK", "PoE");	
	return dev;

}

function WSC3750G48TS(int_status, media_type) {
	var dev = new top.device();
	dev.noofports = 52;
	dev.x=0;
	dev.y=0;
	dev.image = "images/c3750g48_4.gif";	

        drawLeds(dev);	

	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	var xPortGroupGap = 11;
	var xPortStartPos = 72;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 48 FastEthernet ports in 4 groups of 12 each.
	for(i=0; i<48; i++) {       
		if(i%2 == 0) {
			yPortCoord = 27;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 43;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		if(i==15 || i == 31) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	// Add the 4 SFP ports.
	xPortCoord = 587;
	xPortGap = 14;
	yPortCoord = 27;
	portWidth = 21;
	for(i=48; i<52; i++) {
		port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 == 0) {
			yPortCoord = 49;			
		} else {
			yPortCoord = 27;
			xPortCoord += (portWidth + xPortGap);
		}

		dev.addPort(port);
	}	

	return dev;
}

function WSC3750G48P(int_status, media_type) {
	var dev = new top.device();

	dev.noofports = 52;
	dev.x=0;
	dev.y=0;
	dev.image = "images/c3750g48_4p.gif";

    drawLedsForPowerSwitch(dev);	
	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	var xPortGroupGap = 11;
	var xPortStartPos = 72;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 48 FastEthernet ports in 4 groups of 12 each.
	for(i=0; i<48; i++) {       
		if(i%2 == 0) {
			yPortCoord = 28;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 44;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		if(i==15 || i == 31) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	// Add the 4 SFP ports.
	xPortCoord = 585;
	xPortGap = 15;
	yPortCoord = 27;
	portWidth = 21;
	for(i=48; i<52; i++) {
		port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 == 0) {
			yPortCoord = 49;			
		} else {
			yPortCoord = 27;
			xPortCoord += (portWidth + xPortGap);
		}

		dev.addPort(port);
	}	

	dev.modeAliases = new Array ("STATUS", "DUPLEX", "SPEED", "STACK", "PoE");	
	return dev;
}

function WSC3750G24_2_2(int_status, media_type) 
{
	var dev = new top.device();

	dev.noofports = 28;
	dev.x=0;
	dev.y=0;
	dev.image = "images/c3750g24_2_2.gif";
	dev.scrollYCord = 45;
	drawLedsForWSC3750G24_2_2(dev);
	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	var xPortGroupGap = 33;
	var xPortStartPos = 234;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 24 FastEthernet ports in 2 groups of 12 each.
	for(i=0; i<24; i++) 
	{       
		if(i%2 == 0) {
			yPortCoord = 48;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 64;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		if(i==11 || i == 23) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    	}
	// Add the 2 SFP ports.
	xPortCoord = 557;
	xPortGap = 2;
	yPortCoord = 71;
	portWidth = 21;
	for(i=24; i<26; i++) 
	{
		port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
                dev.addPort(port);
		xPortCoord += (portWidth + xPortGap);
         }

	// Add the 2 internal ports.
	xPortCoord = 560;
	xPortGap = 2;
	yPortCoord = 45;
	portWidth = 18;
	portImages = top.internalportImages();
	for(i=26; i<28; i++) 
	{  


                port = new top.internalport(portImages);     
                port.width = 18;
                port.height = 12;
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		dev.addPort(port);
		xPortCoord += (portWidth + xPortGap);
	}

	dev.modeAliases = new Array ("STATUS", "DUPLEX", "SPEED", "STACK", "PoE");	
	return dev;

}
function drawLeds(dev) {

	// Create the Mode Btn
	var modeBtn = new top.modebtn("images/c375024_2_mode.gif");
	modeBtn.x = 35;
	modeBtn.y = 66;
	modeBtn.height = 10;
	modeBtn.width = 19;
	modeBtn.id = "mode_btn";
	modeBtn.device = dev;
	dev.modebtn = modeBtn;		

	// Create System LEDs
	var ledImages = top.ledImages();
	var tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 24;
	tempLed.id = "system_led";
	tempLed.device = dev;
	dev.sysleds["SYSTEM"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 30;
	tempLed.id = "rps_led";
	tempLed.device = dev;
	dev.sysleds["RPS"] = tempLed;
	
	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 36;
	tempLed.id = "master_led";
	tempLed.device = dev;
	dev.sysleds["MASTER"] = tempLed;
	
	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 42;
	tempLed.id = "status_led";
	tempLed.device = dev;
	dev.sysleds["STATUS"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 48;
	tempLed.id = "duplex_led";
	tempLed.device = dev;
	dev.sysleds["DUPLEX"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 54;
	tempLed.id = "speed_led";
	tempLed.device = dev;
	dev.sysleds["SPEED"] = tempLed;
	
	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 60;
	tempLed.id = "stack_led";
	tempLed.device = dev;
	dev.sysleds["STACK"] = tempLed;
}


function drawLedsForPowerSwitch(dev) {

	// Create the Mode Btn
	var modeBtn = new top.modebtn("images/c375024_2_mode.gif");
	modeBtn.x = 35;
	modeBtn.y = 67;
	modeBtn.id = "mode_btn";
	modeBtn.device = dev;
	dev.modebtn = modeBtn;		

	// Create System LEDs
	var ledImages = top.ledImages();
	var tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 22;
	tempLed.id = "system_led";
	tempLed.device = dev;
	dev.sysleds["SYSTEM"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 28;
	tempLed.id = "rps_led";
	tempLed.device = dev;
	dev.sysleds["RPS"] = tempLed;
	
	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 34;
	tempLed.id = "master_led";
	tempLed.device = dev;
	dev.sysleds["MASTER"] = tempLed;
		
	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 40;
	tempLed.id = "status_led";
	tempLed.device = dev;
	dev.sysleds["STATUS"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 46;
	tempLed.id = "duplex_led";
	tempLed.device = dev;
	dev.sysleds["DUPLEX"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 52;
	tempLed.id = "speed_led";
	tempLed.device = dev;
	dev.sysleds["SPEED"] = tempLed;
	
	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 58;
	tempLed.id = "stack_led";
	tempLed.device = dev;
	dev.sysleds["STACK"] = tempLed;
	
	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 64;
	tempLed.id = "power_led";
	tempLed.device = dev;
	dev.sysleds["POWER"] = tempLed;
}


function drawLedsForWSC3750G24_2_2(dev) {

	// Create the Mode Btn
	var modeBtn = new top.modebtn("images/c375024_2_mode.gif");
	modeBtn.x = 35;
	modeBtn.y = 87;
	modeBtn.id = "mode_btn";
	modeBtn.device = dev;
	dev.modebtn = modeBtn;		

	// Create System LEDs
	var ledImages = top.ledImages();
	var tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 43;
	tempLed.id = "system_led";
	tempLed.device = dev;
	dev.sysleds["SYSTEM"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 49;
	tempLed.id = "rps_led";
	tempLed.device = dev;
	dev.sysleds["RPS"] = tempLed;
	
	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 55;
	tempLed.id = "master_led";
	tempLed.device = dev;
	dev.sysleds["MASTER"] = tempLed;
		
	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 61;
	tempLed.id = "status_led";
	tempLed.device = dev;
	dev.sysleds["STATUS"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 67;
	tempLed.id = "duplex_led";
	tempLed.device = dev;
	dev.sysleds["DUPLEX"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 73;
	tempLed.id = "speed_led";
	tempLed.device = dev;
	dev.sysleds["SPEED"] = tempLed;
	
	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 79;
	tempLed.id = "stack_led";
	tempLed.device = dev;
	dev.sysleds["STACK"] = tempLed;
	
	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 85;
	tempLed.id = "power_led";
	tempLed.device = dev;
	dev.sysleds["POWER"] = tempLed;
}
function drawLedsforSlinky(dev){
// Create the Mode Btn
	var modeBtn = new top.modebtn("images/C3750E_mode_btn.gif");
	modeBtn.x = 36;
	modeBtn.y = 69;
	modeBtn.height = 8;
	modeBtn.width = 19;
	modeBtn.id = "mode_btn";
	modeBtn.device = dev;
	dev.modebtn = modeBtn;		

	// Create System LEDs
	var ledImages = top.ledImages();
	var tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 22;
	tempLed.id = "system_led";
	tempLed.device = dev;
	dev.sysleds["SYSTEM"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 28;
	tempLed.id = "dc_ok";
	tempLed.device = dev;
	dev.sysleds["DCOK"] = tempLed;
	
	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 34;
	tempLed.id = "fan";
	tempLed.device = dev;
	dev.sysleds["FAN"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 40;
	tempLed.id = "master_led";
	tempLed.device = dev;
	dev.sysleds["MASTER"] = tempLed;
	
	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 46;
	tempLed.id = "status_led";
	tempLed.device = dev;
	dev.sysleds["STATUS"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 52;
	tempLed.id = "duplex_led";
	tempLed.device = dev;
	dev.sysleds["DUPLEX"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 58;
	tempLed.id = "speed_led";
	tempLed.device = dev;
	dev.sysleds["SPEED"] = tempLed;
	
	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 64;
	tempLed.id = "stack_led";
	tempLed.device = dev;
	dev.sysleds["STACK"] = tempLed;
}

function drawACOK_DCOKLEDs(dev)
{
	// Create AC OK LEDs
	var ledImages = top.ledImages();
	var tempLed = new top.led(ledImages);
	tempLed.x = 68;
	tempLed.y = 67;
	tempLed.id = "ac_ok";
	tempLed.device = dev;
	tempLed.showPopup = true;
	dev.sysleds["ACOK"] = tempLed;

	// Create DC OK LEDs
	tempLed = new top.led(ledImages);
	tempLed.x = 103;
	tempLed.y = 67;
	tempLed.id = "dc_ok";
	tempLed.device = dev;
	tempLed.showPopup = true;
	dev.sysleds["DCOK"] = tempLed;

	// Create Fa0 LED
	tempLed = new top.led(ledImages);
	tempLed.x = 138;
	tempLed.y = 67;
	tempLed.id = "fa_0";
	tempLed.device = dev;
	tempLed.showPopup = true;
	dev.sysleds["FA0"] = tempLed;
}
function drawACOKLEDs(dev)
{
	// Create AC OK LEDs
	var ledImages = top.ledImages();
	var tempLed = new top.led(ledImages);
	tempLed.x = 68;
	tempLed.y = 67;
	tempLed.id = "ac_ok";
	tempLed.device = dev;
	tempLed.showPopup = true;
	dev.sysleds["ACOK"] = tempLed;

	// Create Fa0 LED
	tempLed = new top.led(ledImages);
	tempLed.x = 100;
	tempLed.y = 67;
	tempLed.id = "fa_0";
	tempLed.device = dev;
	tempLed.showPopup = true;
	dev.sysleds["FA0"] = tempLed;

}

function addLabel( dev, label1, label2 )
{
	var image1 = "images/port_label_"+label1+".gif";
	var image2= "";
	if (label2 != null ) image2= "images/port_label_"+label2+".gif";
	switch (label1)
	{
		case 1:
			// Adding the ten gb port label1
			var portlbtl = new top.portLabel(615, 6, 7, 5, image1);
			if(dev.type.indexOf("WS-C3750E-12SD") != -1){
				portlbtl = new top.portLabel(586, 19, 7, 5, image1);
			}
			portlbtl.id = "portlbtl1";
			dev.addPortLabel(portlbtl);
			break;
		case 2:
			// Adding the ten gb port label2
			var portlbtl = new top.portLabel(615, 55, 7, 5, image1);
			if(dev.type.indexOf("WS-C3750E-12SD") != -1){
				portlbtl = new top.portLabel(585, 43, 7, 5, image1);
			}
	        portlbtl.id = "portlbtl1";
			dev.addPortLabel(portlbtl);
			break;
		case 13:
				// Adding the top port label1
		        var portlbl = new top.portLabel(583, 19, 7, 5, image1);
	        	portlbl.id = "portlbl1";
		        dev.addPortLabel(portlbl);

		        // Adding the top port label2
		        var portlbl2 = new top.portLabel(647, 19, 7, 5, image2);
	        	portlbl2.id = "portlbl2";
		        dev.addPortLabel(portlbl2);
			break;
		case 15:
				// Adding the bottom port label1
		        var portlbl3 = new top.portLabel(584, 43, 7, 5, image1);
		        portlbl3.id = "portlbl3";
		        dev.addPortLabel(portlbl3);

		        // Adding the bottom port label2
		        var portlbl4 = new top.portLabel(647, 43, 7, 5, image2);
		        portlbl4.id = "portlbl4";
		        dev.addPortLabel(portlbl4);
			break;
		case 25:
		case 49:
			// Adding the top port label1
		        var portlbl = new top.portLabel(604, 6, 7, 5, image1);
	        	portlbl.id = "portlbl1";
		        dev.addPortLabel(portlbl);

		        // Adding the top port label2
		        var portlbl2 = new top.portLabel(625, 6, 7, 5, image2);
	        	portlbl2.id = "portlbl2";
		        dev.addPortLabel(portlbl2);
			break;
		case 27:
		case 51:
		        // Adding the bottom port label1
		        var portlbl3 = new top.portLabel(604, 55, 7, 5, image1);
		        portlbl3.id = "portlbl3";
		        dev.addPortLabel(portlbl3);

		        // Adding the bottom port label2
		        var portlbl4 = new top.portLabel(625, 55, 7, 5, image2);
		        portlbl4.id = "portlbl4";
		        dev.addPortLabel(portlbl4);
	}
}

function addIncredibleLabel(dev,label1)
{
	var image1;
	switch (label1)
	{	
		
		case 0:
			 image1 = "images/blank_module.gif";//Base for Blank module
			 var label_blank_module = new top.portLabel(556, 3, 102, 74, image1);
			 label_blank_module.id = "labelblankmodule";
			 dev.addPortLabel(label_blank_module); 
			 break;
		case 1://IG NM Module : G1,G2,G3,G4
			// Adding the Gigabit port label 1 (G1)
			 image1 = "images/C3KNM_1G_label.gif";// Label for Network Module;
			 var portlb_nm1g = new top.portLabel(590, 13, 39, 6, image1);
			 portlb_nm1g.id = "portlbnm1g";
			dev.addPortLabel(portlb_nm1g); 
			image1 = "images/giga_port_label_"+label1+".gif";			
			var portlbtl = new top.portLabel(567, 71, 8, 5, image1);
			portlbtl.id = "portlbtl1";
			dev.addPortLabel(portlbtl); label1++;//increment for G2;
			// Adding the Gigabit port label 2 (G2)
			 image1 = "images/giga_port_label_"+label1+".gif";
			var portlbt2 = new top.portLabel(590, 71, 8, 5, image1);
			portlbt2.id = "portlbtl2";
			dev.addPortLabel(portlbt2); label1++;
			// Adding the Gigabit port label 3 (G3)
			 image1 = "images/giga_port_label_"+label1+".gif";
			var portlbt3 = new top.portLabel(614, 71, 8, 5, image1);
			portlbt3.id = "portlbtl3";
			dev.addPortLabel(portlbt3); label1++;
			// Adding the Gigabit port label 4 (G4)
			 image1 = "images/giga_port_label_"+label1+".gif";
			var portlbt4 = new top.portLabel(639, 71, 8, 5, image1);
			portlbt4.id = "portlbtl4";
			dev.addPortLabel(portlbt4);
		break;
		case 2: //Add Te1 and Te2 ports
			 image1 = "images/C3KNM_10G_label.gif";// Label for 10G Network Module;
			 var portlb_nm10g = new top.portLabel(590, 13, 39, 6, image1);
			 portlb_nm10g.id = "portlbnm10g";
			 dev.addPortLabel(portlb_nm10g); 
			 image1 ="images/tengiga_port_color.gif";//This color to indicates 10giga port is on 2nd & 4th port
			 var portlb_nm10g_color1 = new top.portLabel(584, 45, 22, 3, image1);
			 var portlb_nm10g_color2 = new top.portLabel(633, 45, 22, 3, image1);
			 portlb_nm10g_color1.id = "portlb_nm10g_color1";
			 portlb_nm10g_color2.id = "portlb_nm10g_color2";
			 dev.addPortLabel(portlb_nm10g_color1); 
			 dev.addPortLabel(portlb_nm10g_color2); 
			 // Adding port label Te1
			var label1=1;
			image1 = "images/tengiga_port_label_"+label1+".gif";
			var portlbtl = new top.portLabel(590, 71, 10, 5, image1);
			portlbtl.id = "portlbtl1";
			dev.addPortLabel(portlbtl); label1++;
			// Adding the port label Te2
		    image1 = "images/tengiga_port_label_"+label1+".gif";
			var portlbt2 = new top.portLabel(640, 71, 10, 5, image1);
			portlbt2.id = "portlbtl2";
			dev.addPortLabel(portlbt2);
		break;
		case 3: //Add label for Te1,G3,G4
			 image1 = "images/C3KNM_10G_label.gif";// Label for 10G Network Module;
			 var portlb_nm10g = new top.portLabel(590, 13, 39, 6, image1);
			 portlb_nm10g.id = "portlbnm10g";
			 dev.addPortLabel(portlb_nm10g); 
			 image1 ="images/tengiga_port_color.gif";//This color to indicates 10giga port is on 2nd & 4th port
			 var portlb_nm10g_color1 = new top.portLabel(584, 45, 22, 3, image1);
			 var portlb_nm10g_color2 = new top.portLabel(633, 45, 22, 3, image1);
			 portlb_nm10g_color1.id = "portlb_nm10g_color1";
			 portlb_nm10g_color2.id = "portlb_nm10g_color2";
			 dev.addPortLabel(portlb_nm10g_color1); 
			 dev.addPortLabel(portlb_nm10g_color2); 
			// Adding port label Te1
			 var label1=1;
			 image1 = "images/tengiga_port_label_"+label1+".gif";
			 var portlbtl = new top.portLabel(590, 71, 10, 5, image1);
			 portlbtl.id = "portlbtl1";
			 dev.addPortLabel(portlbtl); label1=label1+2;
			 // Adding the port label G3
			var image1 = "images/giga_port_label_"+label1+".gif";
			var portlbt3 = new top.portLabel(614, 71, 8, 5, image1);
			portlbt3.id = "portlbtl3";
			dev.addPortLabel(portlbt3); label1++;
			// Adding the port label G4
			image1 = "images/giga_port_label_"+label1+".gif";
			var portlbt4 = new top.portLabel(639, 71, 8, 5, image1);
			portlbt4.id = "portlbtl4";
			dev.addPortLabel(portlbt4);
		break;
		case 4:
			//Add label for G1,G2,Te2
			 image1 = "images/C3KNM_10G_label.gif";// Label for 10G Network Module;
			 var portlb_nm10g = new top.portLabel(590, 13, 39, 6, image1);
			 portlb_nm10g.id = "portlbnm10g";
			 dev.addPortLabel(portlb_nm10g); 
			 image1 ="images/tengiga_port_color.gif";//This color to indicates 10giga port is on 2nd & 4th port
			 var portlb_nm10g_color1 = new top.portLabel(583, 45, 22, 3, image1);
			 var portlb_nm10g_color2 = new top.portLabel(633, 45, 22, 3, image1);
			 portlb_nm10g_color1.id = "portlb_nm10g_color1";
			 portlb_nm10g_color2.id = "portlb_nm10g_color2";
			 dev.addPortLabel(portlb_nm10g_color1); 
			 dev.addPortLabel(portlb_nm10g_color2);
			 // Adding port label G1
			var label1=1;
			image1 = "images/giga_port_label_"+label1+".gif";
			var portlbtl = new top.portLabel(567, 71, 8, 5, image1);
			portlbtl.id = "portlbtl1";
			dev.addPortLabel(portlbtl); label1++;
			// Adding the port label G2
		    image1 = "images/giga_port_label_"+label1+".gif";
			var portlbt2 = new top.portLabel(592, 71, 8, 5, image1);
			portlbt2.id = "portlbtl2";
			dev.addPortLabel(portlbt2);
			// Adding the port label Te2
		    image1 = "images/tengiga_port_label_"+label1+".gif";
			var portlbt2 = new top.portLabel(640, 71, 10, 5, image1);
			portlbt2.id = "portlbtl2";
			dev.addPortLabel(portlbt2);
		break;
		case 5: // 10G NM module : G1,G2,G3,G4
			 image1 = "images/C3KNM_10G_label.gif";// Label for 10G Network Module;
			 var portlb_nm10g = new top.portLabel(590, 13, 39, 6, image1);
			 portlb_nm10g.id = "portlbnm10g";
			 dev.addPortLabel(portlb_nm10g); 
			 image1 ="images/tengiga_port_color.gif";//This color to indicates 10giga port is on 2nd & 4th port
			 var portlb_nm10g_color1 = new top.portLabel(583, 45, 22, 3, image1);
			 var portlb_nm10g_color2 = new top.portLabel(631, 45, 22, 3, image1);
			 portlb_nm10g_color1.id = "portlb_nm10g_color1";
			 portlb_nm10g_color2.id = "portlb_nm10g_color2";
			 dev.addPortLabel(portlb_nm10g_color1); 
			 dev.addPortLabel(portlb_nm10g_color2); 
			// Adding port label G1
			var label1=1;
			image1 = "images/giga_port_label_"+label1+".gif";
			var portlbtl = new top.portLabel(567, 71, 8, 5, image1);
			portlbtl.id = "portlbtl1";
			dev.addPortLabel(portlbtl); label1++;
			// Adding the port label G2
		    image1 = "images/giga_port_label_"+label1+".gif";
			var portlbt2 = new top.portLabel(590, 71, 8, 5, image1);
			portlbt2.id = "portlbtl2";
			dev.addPortLabel(portlbt2); label1++;
			// Adding the port label G3
			var image1 = "images/giga_port_label_"+label1+".gif";
			var portlbt3 = new top.portLabel(614, 71, 8, 5, image1);
			portlbt3.id = "portlbtl3";
			dev.addPortLabel(portlbt3); label1++;
			// Adding the port label G4
			image1 = "images/giga_port_label_"+label1+".gif";
			var portlbt4 = new top.portLabel(639, 71, 8, 5, image1);
			portlbt4.id = "portlbtl4";
			dev.addPortLabel(portlbt4);
		break;
		
	}
}

/////////////////////////c3750 devices end //////////////////////////////////

// SheYoJee 3750F-24PS
function WSC3750F24PS(int_status, media_type) {
	var dev = new top.device();

	dev.noofports = 26;
	dev.x=0;
	dev.y=0;
	dev.image = "images/3750F_24_PWR.gif";

	drawleds_3750F_power(dev);
	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	var xPortGroupGap = 7;//22;
	var xPortStartPos = 277;//262;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 24 FastEthernet ports in 2 groups of 12 each.
	for(i=0; i<24; i++) {       
		if(i%2 == 0) {
			yPortCoord = 31;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 47;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		if(i==11 || i == 23) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	// Add the 2 GBIC ports.
	xPortCoord = 548;
	xPortGap = 26;
	for(i=24; i<26; i++) {       
		yPortCoord = 46;		
		port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		xPortCoord += (portWidth + xPortGap);
		dev.addPort(port);
	}	

	dev.modeAliases = new Array ("STATUS", "DUPLEX", "SPEED", "STACK", "PoE");	
	return dev;
}

//Sheyojee 3560_24TS
function WSC3750F24TS(int_status, media_type) {
	var dev = new top.device();

	dev.noofports = 26;
	dev.x=0;
	dev.y=0;
	dev.image = "images/3750F_24.gif";

	drawleds_3750F(dev);
	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	var xPortGroupGap = 8;
	var xPortStartPos = 276;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 24 FastEthernet ports in 2 groups of 12 each.
	for(i=0; i<24; i++) {       
		if(i%2 == 0) {
			yPortCoord = 31;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 47;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		if(i==11 || i == 23) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	// Add the 2 GBIC ports.
	xPortCoord = 548;
	xPortGap = 26;
	for(i=24; i<26; i++) {       
		yPortCoord = 46;		
		port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		xPortCoord += (portWidth + xPortGap);
		dev.addPort(port);
	}	

	dev.modeAliases = new Array ("STATUS", "DUPLEX", "SPEED", "STACK");	
	return dev;
}

function WSC3750V224FS(int_status, media_type) {
	var dev = new top.device();

	dev.noofports = 26;
	dev.x=0;
	dev.y=0;
	dev.image = "images/WSC3750V2_24FS_S.gif";

	drawleds_3750F(dev);
	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	var xPortGroupGap = 8;
	var xPortStartPos = 276;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 24 FastEthernet ports in 2 groups of 12 each.
	for(i=0; i<24; i++) {       
		if(i%2 == 0) {
			yPortCoord = 31;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 47;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		if(i==11 || i == 23) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	// Add the 2 GBIC ports.
	xPortCoord = 548;
	xPortGap = 26;
	for(i=24; i<26; i++) {       
		yPortCoord = 46;		
		port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		xPortCoord += (portWidth + xPortGap);
		dev.addPort(port);
	}	

	dev.modeAliases = new Array ("STATUS", "DUPLEX", "SPEED", "STACK");	
	return dev;
}

//SheYoJee - 3750F- 48PS
function WSC3750F48PS(int_status, media_type) {
	var dev = new top.device();

	dev.noofports = 52;
	dev.x=0;
	dev.y=0;
	dev.image = "images/3750F_48_PWR.gif";

   // drawLedsForPowerSwitch(dev);	
   drawleds_3750F_power(dev);
	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	var xPortGroupGap = 8;
	var xPortStartPos = 71;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 48 FastEthernet ports in 4 groups of 12 each.
	for(i=0; i<48; i++) {       
		if(i%2 == 0) {
			yPortCoord = 27;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 43;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		if(i==11 || i == 23 || i== 35) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	// Add the 4 SFP ports.
	xPortCoord = 589;
	xPortGap = 12;
	yPortCoord = 25;
	portWidth = 21;
	for(i=48; i<52; i++) {
		port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 == 0) {
			yPortCoord = 47;			
		} else {
			yPortCoord = 25;
			xPortCoord += (portWidth + xPortGap);
		}

		dev.addPort(port);
	}	

	dev.modeAliases = new Array ("STATUS", "DUPLEX", "SPEED", "STACK", "PoE");	
	return dev;
}

function WSC3750F48TS(int_status, media_type) {
	var dev = new top.device();

	dev.noofports = 52;
	dev.x=0;
	dev.y=0;
	dev.image = "images/3750F_48.gif";

   // drawLedsForPowerSwitch(dev);	
   drawleds_3750F(dev);
	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	var xPortGroupGap = 8;
	var xPortStartPos = 71;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 48 FastEthernet ports in 4 groups of 12 each.
	for(i=0; i<48; i++) {       
		if(i%2 == 0) {
			yPortCoord = 27;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 43;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		if(i==11 || i == 23 || i== 35) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	// Add the 4 SFP ports.
	xPortCoord = 589;
	xPortGap = 12;
	yPortCoord = 25;
	portWidth = 21;
	for(i=48; i<52; i++) {
		port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 == 0) {
			yPortCoord = 47;			
		} else {
			yPortCoord = 25;
			xPortCoord += (portWidth + xPortGap);
		}

		dev.addPort(port);
	}	

	dev.modeAliases = new Array ("STATUS", "DUPLEX", "SPEED", "STACK");	
	return dev;
}

function drawleds_3750F_power(dev) {
	var modeBtn = new top.modebtn("images/3560f_mode.gif");
	modeBtn.x = 36;//30;
	modeBtn.y = 67;//63;
	modeBtn.height = 8;
	modeBtn.width = 16;
	modeBtn.id = "mode_btn";
	modeBtn.device = dev;
	dev.modebtn = modeBtn;		

	// Create System LEDs
	var ledImages = top.ledImages();
	var tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 21;
	tempLed.id = "system_led";
	tempLed.device = dev;
	dev.sysleds["SYSTEM"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 27;
	tempLed.id = "rps_led";
	tempLed.device = dev;
	dev.sysleds["RPS"] = tempLed;
	
	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 33;
	tempLed.id = "master_led";
	tempLed.device = dev;
	dev.sysleds["MASTER"] = tempLed;
		
	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 39;
	tempLed.id = "status_led";
	tempLed.device = dev;
	dev.sysleds["STATUS"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 45;
	tempLed.id = "duplex_led";
	tempLed.device = dev;
	dev.sysleds["DUPLEX"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 51;
	tempLed.id = "speed_led";
	tempLed.device = dev;
	dev.sysleds["SPEED"] = tempLed;
	
	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 57;
	tempLed.id = "stack_led";
	tempLed.device = dev;
	dev.sysleds["STACK"] = tempLed;
	
	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 63;
	tempLed.id = "power_led";
	tempLed.device = dev;
	dev.sysleds["POWER"] = tempLed;
}
function drawleds_3750F(dev) {
    var modeBtn = new top.modebtn("images/3560f_mode.gif");
	modeBtn.x = 36;//30;
	modeBtn.y = 67;//63;
	modeBtn.height = 8;
	modeBtn.width = 16;
	modeBtn.id = "mode_btn";
	modeBtn.device = dev;
	dev.modebtn = modeBtn;		


	// Create System LEDs
	var ledImages = top.ledImages();
	var tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 21;
	tempLed.id = "system_led";
	tempLed.device = dev;
	dev.sysleds["SYSTEM"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 27;
	tempLed.id = "rps_led";
	tempLed.device = dev;
	dev.sysleds["RPS"] = tempLed;
	
	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 33;
	tempLed.id = "master_led";
	tempLed.device = dev;
	dev.sysleds["MASTER"] = tempLed;
		
	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 39;
	tempLed.id = "status_led";
	tempLed.device = dev;
	dev.sysleds["STATUS"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 45;
	tempLed.id = "duplex_led";
	tempLed.device = dev;
	dev.sysleds["DUPLEX"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 51;
	tempLed.id = "speed_led";
	tempLed.device = dev;
	dev.sysleds["SPEED"] = tempLed;
	
	tempLed = new top.led(ledImages);
	tempLed.x = 13;
	tempLed.y = 57;
	tempLed.id = "stack_led";
	tempLed.device = dev;
	dev.sysleds["STACK"] = tempLed;
	
}

//Start of Incredible

function WSC3750X24(int_status, media_type,FRULinkname,hardwareModuleActivePorts) {
	var dev = new top.device();
	var FRUModule= FRULinkname;
	dev.noofports = 30; 
	dev.x=0;
	dev.y=0;
	dev.image = "images/3750X_24.gif";

   // drawLedsForPowerSwitch(dev);	
   drawledsforIncredibles(dev);
	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	var xPortGroupGap = 15;//8;
	var xPortStartPos = 285;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 48 FastEthernet ports in 4 groups of 12 each.
	for(i=0; i<24; i++) {       
		if(i%2 == 0) {
			yPortCoord = 30;//27;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 46;//43;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		if(i==11) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	//Add Network module
	var intNames = new Array();
	var intTypes = new Array();
	for (i=0; i< int_status.length; i++)
	{
		intNames[i] = int_status[i][0];
		intTypes[i] = int_status[i][6]; // Type of Port - Incredible will have FRULink for SFP & SFP+ .SO its supporting three type of network module
	}
	
	var interfaces = "#"+intNames.join('#')+"#";

	if(FRUModule.indexOf("none") != -1) { //Total no.of ports will be 24 if it have blank module connected.
	addIncredibleLabel(dev,0);
	}
	else if(FRUModule.indexOf("1G Module") != -1) //Total number of ports will be 28 if its connected with 1G Network module	
		draw1GNetworkModule(24,560,int_status,dev,portImages);

	else if (FRUModule.indexOf("10G ST") != -1) //10G Network module FRULink. [G1,G2,G3,G4, Te1,Te2]
		draw10GNetworkModule(24,560,int_status,intTypes,dev,portImages);
		
	else if(FRUModule.indexOf("10G SM Module") != -1) {	//10G Service Module FRULink. [G2/Te1,G4/Te2]  WallE Module
		dev.image = "images/3750X_24_SM_Module.gif";
		draw10GServiceModule(24,606,int_status,intTypes,dev,portImages);
	}
	else if(FRUModule.indexOf("10GT Module") != -1) {	//10G Service Module FRULink. [G2/Te1,G4/Te2]  Gamma Jack Module
		dev.image = "images/3750X_24_10GT_Module.gif"; //Gamma Jack Module Support
		draw10GTNMModule(24,585,int_status,intTypes,dev,portImages,hardwareModuleActivePorts);
	}
	

	dev.modeAliases = new Array ("STATUS","DUPLEX","SPEED","STACK");	
	return dev;
}


function SW6750X24(int_status, media_type,FRULinkname,hardwareModuleActivePorts) {
	var dev = new top.device();
	var FRUModule= FRULinkname;
	dev.noofports = 30; 
	dev.x=0;
	dev.y=0;
	dev.image = "images/6750X_24.gif";

   // drawLedsForPowerSwitch(dev);	
   drawledsforIncredibles(dev);
	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	var xPortGroupGap = 15;//8;
	var xPortStartPos = 285;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 48 FastEthernet ports in 4 groups of 12 each.
	for(i=0; i<24; i++) {       
		if(i%2 == 0) {
			yPortCoord = 30;//27;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 46;//43;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		if(i==11) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	//Add Network module
	var intNames = new Array();
	var intTypes = new Array();
	for (i=0; i< int_status.length; i++)
	{
		intNames[i] = int_status[i][0];
		intTypes[i] = int_status[i][6]; // Type of Port - Incredible will have FRULink for SFP & SFP+ .SO its supporting three type of network module
	}
	
	var interfaces = "#"+intNames.join('#')+"#";

	if(FRUModule.indexOf("none") != -1) { //Total no.of ports will be 24 if it have blank module connected.
	addIncredibleLabel(dev,0);
	}
	else if(FRUModule.indexOf("1G Module") != -1) //Total number of ports will be 28 if its connected with 1G Network module	
		draw1GNetworkModule(24,560,int_status,dev,portImages);

	else if (FRUModule.indexOf("10G ST") != -1) //10G Network module FRULink. [G1,G2,G3,G4, Te1,Te2]
		draw10GNetworkModule(24,560,int_status,intTypes,dev,portImages);
		
	else if(FRUModule.indexOf("10G SM Module") != -1) {	//10G Service Module FRULink. [G2/Te1,G4/Te2]  WallE Module
		dev.image = "images/6750X_24_SM_Module.gif";
		draw10GServiceModule(24,606,int_status,intTypes,dev,portImages);
	}
	else if(FRUModule.indexOf("10GT Module") != -1) {	//10G Service Module FRULink. [G2/Te1,G4/Te2]  Gamma Jack Module
		dev.image = "images/6750X_24_10GT_Module.gif"; //Gamma Jack Module Support
		draw10GTNMModule(24,585,int_status,intTypes,dev,portImages,hardwareModuleActivePorts);
	}
	

	dev.modeAliases = new Array ("STATUS","DUPLEX","SPEED","STACK");	
	return dev;
}

function WSC3750X24P(int_status, media_type,FRULinkname,hardwareModuleActivePorts) {
	var dev = new top.device();
	var FRUModule= FRULinkname;
	dev.noofports = 30;
	dev.x=0;
	dev.y=0;
	dev.image = "images/3750X_24_PWR.gif";
	drawledsforIncredibles_power(dev);

	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	var xPortGroupGap = 15;//13;//30;
	var xPortStartPos = 285;//110;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 24 FastEthernet ports in 2 groups of 12 each.
	for(i=0; i<24; i++) {       
		if(i%2 == 0) {
			yPortCoord = 30;//25;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 46;//41;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		if(i==11) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	//Add Network module
	var intNames = new Array();
	var intTypes = new Array();
	for (i=0; i< int_status.length; i++)
	{
		intNames[i] = int_status[i][0];
		intTypes[i] = int_status[i][6]; // Type of Port - Incredible will have FRULink for SFP & SFP+ .SO its supporting three type of network module
	}
	
	var interfaces = "#"+intNames.join('#')+"#";

	if(FRUModule.indexOf("none") != -1) { //Total no.of ports will be 24 if it have blank module connected.
	addIncredibleLabel(dev,0);
	}
	else if(FRUModule.indexOf("1G Module") != -1) //1G Network module FRULink.[ G1,G2,G3,G4 ]
		// Add the 4 sfp ports
		draw1GNetworkModule(24,560,int_status,dev,portImages);

	else if (FRUModule.indexOf("10G ST") != -1) // 10G Network module FRULink. [G1,G2,G3,G4, Te1,Te2]
		draw10GNetworkModule(24,560,int_status,intTypes,dev,portImages);

	else if(FRUModule.indexOf("10G SM Module") != -1) {	//10G Service Module FRULink. [G2/Te1,G4/Te2]  WallE Module
		// Add the 4 sfp ports
		dev.image = "images/3750X_24_PWR_SM_Module.gif";
		draw10GServiceModule(24,606,int_status,intTypes,dev,portImages);
	} 
	else if(FRUModule.indexOf("10GT Module") != -1) {	//10G Service Module FRULink. [G2/Te1,G4/Te2]  Gamma Jack Module
		dev.image = "images/3750X_24_PWR_10GT_Module.gif"; //Gamma Jack Module Support
		draw10GTNMModule(24,585,int_status,intTypes,dev,portImages,hardwareModuleActivePorts);
	}

	dev.modeAliases = new Array ("STATUS", "DUPLEX", "SPEED", "STACK", "PoE");	
	return dev;
}

function SW6750X24P(int_status, media_type,FRULinkname,hardwareModuleActivePorts) {
	var dev = new top.device();
	var FRUModule= FRULinkname;
	dev.noofports = 30;
	dev.x=0;
	dev.y=0;
	dev.image = "images/6750X_24_PWR.gif";
	drawledsforIncredibles_power(dev);

	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	var xPortGroupGap = 15;//13;//30;
	var xPortStartPos = 285;//110;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 24 FastEthernet ports in 2 groups of 12 each.
	for(i=0; i<24; i++) {       
		if(i%2 == 0) {
			yPortCoord = 30;//25;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 46;//41;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		if(i==11) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	//Add Network module
	var intNames = new Array();
	var intTypes = new Array();
	for (i=0; i< int_status.length; i++)
	{
		intNames[i] = int_status[i][0];
		intTypes[i] = int_status[i][6]; // Type of Port - Incredible will have FRULink for SFP & SFP+ .SO its supporting three type of network module
	}
	
	var interfaces = "#"+intNames.join('#')+"#";

	if(FRUModule.indexOf("none") != -1) { //Total no.of ports will be 24 if it have blank module connected.
	addIncredibleLabel(dev,0);
	}
	else if(FRUModule.indexOf("1G Module") != -1) //1G Network module FRULink.[ G1,G2,G3,G4 ]
		// Add the 4 sfp ports
		draw1GNetworkModule(24,560,int_status,dev,portImages);

	else if (FRUModule.indexOf("10G ST") != -1) // 10G Network module FRULink. [G1,G2,G3,G4, Te1,Te2]
		draw10GNetworkModule(24,560,int_status,intTypes,dev,portImages);

	else if(FRUModule.indexOf("10G SM Module") != -1) {	//10G Service Module FRULink. [G2/Te1,G4/Te2]  WallE Module
		// Add the 4 sfp ports
		dev.image = "images/6750X_24_PWR_SM_Module.gif";
		draw10GServiceModule(24,606,int_status,intTypes,dev,portImages);
	} 
	else if(FRUModule.indexOf("10GT Module") != -1) {	//10G Service Module FRULink. [G2/Te1,G4/Te2]  Gamma Jack Module
		dev.image = "images/6750X_24_PWR_10GT_Module.gif"; //Gamma Jack Module Support
		draw10GTNMModule(24,585,int_status,intTypes,dev,portImages,hardwareModuleActivePorts);
	}

	dev.modeAliases = new Array ("STATUS", "DUPLEX", "SPEED", "STACK", "PoE");	
	return dev;
}


function WSC3750X24U(int_status, media_type) {
	var dev = new top.device();
	//var FRUModule= FRULinkname;
	dev.noofports = 30;
	dev.x=0;
	dev.y=0;
	dev.image = "images/3750X_24_UPOE.gif";
	
	drawledsforIncredibles_power(dev);

	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	var xPortGroupGap = 15;//13;//30;
	var xPortStartPos = 285;//110;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 24 FastEthernet ports in 2 groups of 12 each.
	for(i=0; i<24; i++) {       
		if(i%2 == 0) {
			yPortCoord = 30;//25;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 46;//41;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		if(i==11) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }
	addIncredibleLabel(dev,0);

	//Add Network module
	/*var intNames = new Array();
	var intTypes = new Array();
	for (i=0; i< int_status.length; i++)
	{
		intNames[i] = int_status[i][0];
		intTypes[i] = int_status[i][6]; // Type of Port - Incredible will have FRULink for SFP & SFP+ .SO its supporting three type of network module
	}
	
	var interfaces = "#"+intNames.join('#')+"#";

	if(FRUModule.indexOf("none") != -1) { //Total no.of ports will be 24 if it have blank module connected.
	addIncredibleLabel(dev,0);
	}
	else if(FRUModule.indexOf("1G Module") != -1) //1G Network module FRULink.[ G1,G2,G3,G4 ]
		// Add the 4 sfp ports
		draw1GNetworkModule(24,560,int_status,dev,portImages);

	else if (FRUModule.indexOf("10G ST") != -1) // 10G Network module FRULink. [G1,G2,G3,G4, Te1,Te2]
		draw10GNetworkModule(24,560,int_status,intTypes,dev,portImages);

	else if(FRUModule.indexOf("10G SM Module") != -1) {	//10G Service Module FRULink. [G2/Te1,G4/Te2]  WallE Module
		// Add the 4 sfp ports
		dev.image = "images/3750X_24_PWR_SM_Module.gif";
		draw10GServiceModule(24,606,int_status,intTypes,dev,portImages);
	} 
	else if(FRUModule.indexOf("10GT Module") != -1) {	//10G Service Module FRULink. [G2/Te1,G4/Te2]  Gamma Jack Module
		dev.image = "images/3750X_24_PWR_10GT_Module.gif"; //Gamma Jack Module Support
		draw10GTNMModule(24,585,int_status,intTypes,dev,portImages,hardwareModuleActivePorts);
	}*/

	dev.modeAliases = new Array ("STATUS", "DUPLEX", "SPEED", "STACK", "UPoE");	
	return dev;
}


function WSC3750X48(int_status, media_type,FRULinkname,hardwareModuleActivePorts) {
	var dev = new top.device();
	var FRUModule= FRULinkname;
	dev.noofports = 54;
	dev.x=0;
	dev.y=0;
	dev.image = "images/3750X_48.gif";

    drawledsforIncredibles(dev);
	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	var xPortGroupGap = 15;//8;
	var xPortStartPos = 17;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 48 FastEthernet ports in 4 groups of 12 each.
	for(i=0; i<48; i++) {       
		if(i%2 == 0) {
			yPortCoord = 30;//27;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 46;//43;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		if(i==11 || i == 23 || i== 35) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	var intNames = new Array();
	var intTypes = new Array();
	for (i=0; i< int_status.length; i++)
	{
		intNames[i] = int_status[i][0];
		intTypes[i] = int_status[i][6]; // Type of Port - Incredible will have FRULink for SFP & SFP+ .Its supports 3 types of network module
	}
	
	var interfaces = "#"+intNames.join('#')+"#";
	
	if(FRUModule.indexOf("none") != -1) { 
		addIncredibleLabel(dev,0); 
	} 
	else if(FRUModule.indexOf("1G Module") != -1) 	//1G Network module FRULink.[G1,G2,G3,G4]
		// Add the 4 sfp ports
		draw1GNetworkModule(48,560,int_status,dev,portImages);//
	
	else if (FRUModule.indexOf("10G ST") != -1)  // 10G Network module FRULink. [G1,G2/Te1,G3,G4/Te2]
		draw10GNetworkModule(48,560,int_status,intTypes,dev,portImages);
	
	else if(FRUModule.indexOf("10G SM Module") != -1) {	//10G Service Module FRULink. [G2/Te1,G4/Te2]  WallE Module
		// Add the 4 sfp ports
		dev.image = "images/3750X_48_SM_Module.gif";
		draw10GServiceModule(48,606,int_status,intTypes,dev,portImages);
	}
	else if(FRUModule.indexOf("10GT Module") != -1) {	//10G Service Module FRULink. [G2/Te1,G4/Te2]  Gamma Jack Module
		dev.image = "images/3750X_48_10GT_Module.gif"; //Gamma Jack Module Support
		draw10GTNMModule(48,585,int_status,intTypes,dev,portImages,hardwareModuleActivePorts);
	}

	dev.modeAliases = new Array ("STATUS", "DUPLEX", "SPEED", "STACK");	
	return dev;
}

function SW6750X48(int_status, media_type,FRULinkname,hardwareModuleActivePorts) {
	var dev = new top.device();
	var FRUModule= FRULinkname;
	dev.noofports = 54;
	dev.x=0;
	dev.y=0;
	dev.image = "images/6750X_48.gif";

    drawledsforIncredibles(dev);
	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	var xPortGroupGap = 15;//8;
	var xPortStartPos = 17;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 48 FastEthernet ports in 4 groups of 12 each.
	for(i=0; i<48; i++) {       
		if(i%2 == 0) {
			yPortCoord = 30;//27;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 46;//43;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		if(i==11 || i == 23 || i== 35) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	var intNames = new Array();
	var intTypes = new Array();
	for (i=0; i< int_status.length; i++)
	{
		intNames[i] = int_status[i][0];
		intTypes[i] = int_status[i][6]; // Type of Port - Incredible will have FRULink for SFP & SFP+ .Its supports 3 types of network module
	}
	
	var interfaces = "#"+intNames.join('#')+"#";
	
	if(FRUModule.indexOf("none") != -1) { 
		addIncredibleLabel(dev,0); 
	} 
	else if(FRUModule.indexOf("1G Module") != -1) 	//1G Network module FRULink.[G1,G2,G3,G4]
		// Add the 4 sfp ports
		draw1GNetworkModule(48,560,int_status,dev,portImages);//
	
	else if (FRUModule.indexOf("10G ST") != -1)  // 10G Network module FRULink. [G1,G2/Te1,G3,G4/Te2]
		draw10GNetworkModule(48,560,int_status,intTypes,dev,portImages);
	
	else if(FRUModule.indexOf("10G SM Module") != -1) {	//10G Service Module FRULink. [G2/Te1,G4/Te2]  WallE Module
		// Add the 4 sfp ports
		dev.image = "images/6750X_48_SM_Module.gif";
		draw10GServiceModule(48,606,int_status,intTypes,dev,portImages);
	}
	else if(FRUModule.indexOf("10GT Module") != -1) {	//10G Service Module FRULink. [G2/Te1,G4/Te2]  Gamma Jack Module
		dev.image = "images/6750X_48_10GT_Module.gif"; //Gamma Jack Module Support
		draw10GTNMModule(48,585,int_status,intTypes,dev,portImages,hardwareModuleActivePorts);
	}
	dev.modeAliases = new Array ("STATUS", "DUPLEX", "SPEED", "STACK");	
	return dev;
}

function WSC3750X48P(int_status, media_type,FRULinkname,hardwareModuleActivePorts) {
	var dev = new top.device();
	var FRUModule= FRULinkname;
	dev.noofports = 54; 
	dev.x=0;
	dev.y=0;
	dev.image = "images/3750X_48_PWR.gif";

   // draw system LEDs
   drawledsforIncredibles_power(dev);
	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	var xPortGroupGap = 15;//8;
	var xPortStartPos = 17;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 48 FastEthernet ports in 4 groups of 12 each.
	for(i=0; i<48; i++) {       
		if(i%2 == 0) {
			yPortCoord = 30;//27;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 46;//43;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		if(i==11 || i == 23 || i== 35) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	var intNames = new Array();
	var intTypes = new Array();
	for (i=0; i< int_status.length; i++)
	{
		intNames[i] = int_status[i][0];
		intTypes[i] = int_status[i][6]; // Type of Port - Incredible will have FRULink for SFP & SFP+ .Its supports 3 types of network module. Add different type of modules by checking which port is connected.
	}
	
	var interfaces = "#"+intNames.join('#')+"#";
	
	if(FRUModule.indexOf("none") != -1) { 
		addIncredibleLabel(dev,0); 
	}
	else if(FRUModule.indexOf("1G Module") != -1) 	//1G Network module FRULink.[G1,G2,G3,G4]
		draw1GNetworkModule(48,560,int_status,dev,portImages);//
	
	else if (FRUModule.indexOf("10G ST") != -1)  // 10G Network module FRULink. [G1,G2,G3,G4, Te1,Te2]
		draw10GNetworkModule(48,560,int_status,intTypes,dev,portImages);
		
	else if(FRUModule.indexOf("10G SM Module") != -1) {	//10G Service Module FRULink. [G2/Te1,G4/Te2]  WallE Module
		dev.image = "images/3750X_48_PWR_SM_Module.gif";
		draw10GServiceModule(48,606,int_status,intTypes,dev,portImages);
	}else if(FRUModule.indexOf("10GT Module") != -1) {	//10G Service Module FRULink. [G2/Te1,G4/Te2]  Gamma Jack Module
		dev.image = "images/3750X_48_PWR_10GT_Module.gif"; //Gamma Jack Module Support
		draw10GTNMModule(48,585,int_status,intTypes,dev,portImages,hardwareModuleActivePorts);
	}

	dev.modeAliases = new Array ("STATUS","DUPLEX","SPEED","STACK", "PoE");	
	return dev;
}

function SW6750X48P(int_status, media_type,FRULinkname,hardwareModuleActivePorts) {
	var dev = new top.device();
	var FRUModule= FRULinkname;
	dev.noofports = 54; 
	dev.x=0;
	dev.y=0;
	dev.image = "images/6750X_48_PWR.gif";

   // draw system LEDs
   drawledsforIncredibles_power(dev);
	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	var xPortGroupGap = 15;//8;
	var xPortStartPos = 17;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 48 FastEthernet ports in 4 groups of 12 each.
	for(i=0; i<48; i++) {       
		if(i%2 == 0) {
			yPortCoord = 30;//27;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 46;//43;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		if(i==11 || i == 23 || i== 35) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	var intNames = new Array();
	var intTypes = new Array();
	for (i=0; i< int_status.length; i++)
	{
		intNames[i] = int_status[i][0];
		intTypes[i] = int_status[i][6]; // Type of Port - Incredible will have FRULink for SFP & SFP+ .Its supports 3 types of network module. Add different type of modules by checking which port is connected.
	}
	
	var interfaces = "#"+intNames.join('#')+"#";
	
	if(FRUModule.indexOf("none") != -1) { 
		addIncredibleLabel(dev,0); 
	}
	else if(FRUModule.indexOf("1G Module") != -1) 	//1G Network module FRULink.[G1,G2,G3,G4]
		draw1GNetworkModule(48,560,int_status,dev,portImages);//
	
	else if (FRUModule.indexOf("10G ST") != -1)  // 10G Network module FRULink. [G1,G2,G3,G4, Te1,Te2]
		draw10GNetworkModule(48,560,int_status,intTypes,dev,portImages);
		
	else if(FRUModule.indexOf("10G SM Module") != -1) {	//10G Service Module FRULink. [G2/Te1,G4/Te2]  WallE Module
		dev.image = "images/6750X_48_PWR_SM_Module.gif";
		draw10GServiceModule(48,606,int_status,intTypes,dev,portImages);
	}else if(FRUModule.indexOf("10GT Module") != -1) {	//10G Service Module FRULink. [G2/Te1,G4/Te2]  Gamma Jack Module
		dev.image = "images/6750X_48_PWR_10GT_Module.gif"; //Gamma Jack Module Support
		draw10GTNMModule(48,585,int_status,intTypes,dev,portImages,hardwareModuleActivePorts);
	}

	dev.modeAliases = new Array ("STATUS","DUPLEX","SPEED","STACK", "PoE");	
	return dev;
}


function WSC3750X48U(int_status, media_type) {
	var dev = new top.device();
	//var FRUModule= FRULinkname;
	dev.noofports = 54; 
	dev.x=0;
	dev.y=0;
	dev.image = "images/3750X_48_UPOE.gif";

   // draw system LEDs
   drawledsforIncredibles_power(dev);
	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.rj45portImages();
	var portInvImages = top.rj45portInvImages();
	var xPortGap = 1;
	var xPortGroupGap = 15;//8;
	var xPortStartPos = 17;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 48 FastEthernet ports in 4 groups of 12 each.
	for(i=0; i<48; i++) {       
		if(i%2 == 0) {
			yPortCoord = 30;//27;
			port = new top.rj45portInv(portInvImages);
		} else {
			yPortCoord = 46;//43;
			port = new top.rj45port(portImages);
		}
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		if(i==11 || i == 23 || i== 35) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }
	addIncredibleLabel(dev,0);

	/*var intNames = new Array();
	var intTypes = new Array();
	for (i=0; i< int_status.length; i++)
	{
		intNames[i] = int_status[i][0];
		intTypes[i] = int_status[i][6]; // Type of Port - Incredible will have FRULink for SFP & SFP+ .Its supports 3 types of network module. Add different type of modules by checking which port is connected.
	}
	
	var interfaces = "#"+intNames.join('#')+"#";
	
	if(FRUModule.indexOf("none") != -1) { 
		addIncredibleLabel(dev,0); 
	}
	else if(FRUModule.indexOf("1G Module") != -1) 	//1G Network module FRULink.[G1,G2,G3,G4]
		draw1GNetworkModule(48,560,int_status,dev,portImages);//
	
	else if (FRUModule.indexOf("10G ST") != -1)  // 10G Network module FRULink. [G1,G2,G3,G4, Te1,Te2]
		draw10GNetworkModule(48,560,int_status,intTypes,dev,portImages);
		
	else if(FRUModule.indexOf("10G SM Module") != -1) {	//10G Service Module FRULink. [G2/Te1,G4/Te2]  WallE Module
		dev.image = "images/3750X_48_PWR_SM_Module.gif";
		draw10GServiceModule(48,606,int_status,intTypes,dev,portImages);
	}else if(FRUModule.indexOf("10GT Module") != -1) {	//10G Service Module FRULink. [G2/Te1,G4/Te2]  Gamma Jack Module
		dev.image = "images/3750X_48_PWR_10GT_Module.gif"; //Gamma Jack Module Support
		draw10GTNMModule(48,585,int_status,intTypes,dev,portImages,hardwareModuleActivePorts);
	}*/

	dev.modeAliases = new Array ("STATUS","DUPLEX","SPEED","STACK", "UPoE");	
	return dev;
}

function WSC3750V224FX(int_status, media_type) {
	var dev = new top.device();

	dev.noofports = 26;
	dev.x=0;
	dev.y=0;
	dev.image = "images/3750_24_fx.gif";

	drawleds_3750FX(dev);
	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.fxportImages();
	var portInvImages = top.fxportInvImages();
	var xPortGap = 2;
	var xPortGroupGap = 78;//8;
	var xPortStartPos = 133;//276;
	var xPortCoord = xPortStartPos;
	var yPortCoord;

	// Add the 24 FastEthernet ports in 2 groups of 12 each.
	for(i=0; i<24; i++) {       
		if(i%2 == 0) {
			yPortCoord = 28;
			port = new top.fxport(portInvImages);
		} else {
			yPortCoord = 44;//47;
			port = new top.fxport(portImages);
		}
		
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		if(i%2 != 0) {
			xPortCoord += (portWidth + xPortGap);
		}
		if(i==7 || i == 15 || i == 23) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	// Add the 2 SFP ports.
	xPortCoord = 607;//548;
	xPortGap = 8;//26;

	for(i=24; i<26; i++) {       
		yPortCoord = 40;		
		port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		xPortCoord += (portWidth + xPortGap);
		dev.addPort(port);
	}	

	dev.modeAliases = new Array ("STATUS", "DUPLEX", "SPEED", "STACK");	
	return dev;
}

//Start of Syndrome
function WSC3750X24S(int_status, media_type,FRULinkname,hardwareModuleActivePorts) {
	var dev = new top.device();
	var FRUModule= FRULinkname;
	dev.noofports = 30; 
	dev.x=0;
	dev.y=0;
	dev.image = "images/3750X_24S.gif";

   // drawLedsForPowerSwitch(dev);	
   drawledsforSyndrome(dev);
	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.SFP_SXImages();
	var xPortGap = 1;
	var xPortGroupGap = 8;
	var xPortStartPos =42;
	var xPortCoord = xPortStartPos;
	var yPortCoord = 50;

	// Add the 24 SFP ports in 4 groups of 6 each.
	for(i=0; i<24; i++) {       
		port = new top.SFPport(int_status[i][6], portImages);//
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		xPortCoord += (portWidth + xPortGap);
		if(i==5 || i==11 || i==17) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	var intNames = new Array();
	var intTypes = new Array();
	for (i=0; i< int_status.length; i++)
	{
		intNames[i] = int_status[i][0];
		intTypes[i] = int_status[i][6]; // Type of Port - Incredible will have FRULink for SFP & SFP+ .Its supports 3 types of network module. Add different type of modules by checking which port is connected.
	}
	
	var interfaces = "#"+intNames.join('#')+"#";


	 xPortCoord =561;//42;// 285;
	 yPortCoord = 51;
	 portWidth = 23;
	 xPortGap=1;
	if(FRUModule.indexOf("none") != -1) { 
		addIncredibleLabel(dev,0); 
	}
	else if(FRUModule.indexOf("1G Module") != -1) {
	for(i=24; i<28; i++) {       
		port = new top.SFPport(int_status[i][6], portImages);
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		xPortCoord += (portWidth + xPortGap);
		dev.addPort(port);
		}
	addIncredibleLabel(dev,1); // add G1,G2,G3,G4 label
	}
	else if (FRUModule.indexOf("10G ST") != -1) { 
		var portInd = 24;
		xPortCoord = 561;
		xPortGap = 1;
		portWidth = 23;
		yPortCoord = 50;
		if(intTypes[28] != "Not Present" || intTypes[29] != "Not Present") //Te1 and Te2 
		{
			if (intTypes[24] != "Not Present" || intTypes[25] != "Not Present")	
				{	
				for(i=portInd; i<portInd+3; i++) //G1,G2,Te2
					{    
						if(i == 26){
						port = new top.SFPplusport(int_status[i+3][6], portImages);// pass the module type plugged-in the SFP slot
						}
						else 
						port = new top.SFPport(int_status[i][6], portImages);
						port.index = i;
						port.id = "port_" + i;
						port.x = xPortCoord;
						port.y = yPortCoord;
						if(i == 25) xPortGap=25;//5;
						xPortCoord += portWidth + xPortGap;
						dev.addPort(port);
			
					}
			addIncredibleLabel(dev,4);
			}
			else if (intTypes[28] != "Not Present" && (intTypes[26] != "Not Present" 
				|| intTypes[27] != "Not Present"))		// Te1 and G3, G4
				{	
				xPortCoord = 562;
				for(i=portInd; i<portInd+3; i++) // Te1,G3,G4 
					{    
					if(i == 24) {
					xPortCoord = 585;//562;
					portWidth=23;//43;
					port = new top.SFPplusport(int_status[i+4][6], portImages); // pass the module type plugged-in the SFP slot
					port.index = i;
					port.id = "port_" + i;
					port.x = xPortCoord;
					port.y = yPortCoord;			
					xPortCoord += portWidth + xPortGap;
					}
					else {
					port = new top.SFPport(int_status[i+1][6], portImages);
					portWidth=23;
					xPortGap = 1;
					port.index = i;
					port.id = "port_" + i;
					port.x = xPortCoord;
					port.y = yPortCoord;			
					xPortCoord += portWidth + xPortGap; 
					}
					dev.addPort(port);
				}
				addIncredibleLabel(dev,3);
			}
			else 
				{ //For Te1,Te2
					xPortCoord = 585;//560;
					for(i=portInd; i<portInd+2; i++){			
					//portWidth = 43;
					xPortGap = 25;//5;
					port = new top.SFPplusport(int_status[i+4][6], portImages); 
					port.index = i;
				//	port.width=23;
					port.id = "port_" + i;
					port.x = xPortCoord;
					port.y = yPortCoord;			
					xPortCoord += portWidth + xPortGap;
					dev.addPort(port);
				}
				addIncredibleLabel(dev,2);//Te1 and Te2 Label
			}
		}
		else
		{
			for(i=portInd; i<portInd+4; i++) //G1,G2,G3,G4
			{    
				port = new top.SFPport(int_status[i][6], portImages);
				port.index = i;
				port.id = "port_" + i;
				port.x = xPortCoord;
				port.y = yPortCoord;			
				xPortCoord += portWidth + xPortGap;
				dev.addPort(port);
			}		
				
		addIncredibleLabel(dev,5);// add G1,G2,G3,G4 label for 10G NM Module
		}
	}
	else if(FRUModule.indexOf("10G SM Module") != -1) {	//10G Service Module FRULink. [G2/Te1,G4/Te2]  WallE Module
		dev.image = "images/3750X_24S_SM_Module.gif";
		draw10GServiceModule(24,606,int_status,intTypes,dev,portImages);
	}
	else if(FRUModule.indexOf("10GT Module") != -1) {	//10G Service Module FRULink. [G2/Te1,G4/Te2]  Gamma Jack Module
		dev.image = "images/3750X_24S_10GT_Module.gif"; //Gamma Jack Module Support
		draw10GTNMModule(24,585,int_status,intTypes,dev,portImages,hardwareModuleActivePorts);
	}
	dev.modeAliases = new Array ("STATUS","DUPLEX","SPEED","STACK");	
	return dev;
	
}

function SW6750X24S(int_status, media_type,FRULinkname,hardwareModuleActivePorts) {
	var dev = new top.device();
	var FRUModule= FRULinkname;
	dev.noofports = 30; 
	dev.x=0;
	dev.y=0;
	dev.image = "images/6750X_24S.gif";

   // drawLedsForPowerSwitch(dev);	
   drawledsforSyndrome(dev);
	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.SFP_SXImages();
	var xPortGap = 1;
	var xPortGroupGap = 8;
	var xPortStartPos =42;
	var xPortCoord = xPortStartPos;
	var yPortCoord = 50;

	// Add the 24 SFP ports in 4 groups of 6 each.
	for(i=0; i<24; i++) {       
		port = new top.SFPport(int_status[i][6], portImages);//
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		xPortCoord += (portWidth + xPortGap);
		if(i==5 || i==11 || i==17) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	var intNames = new Array();
	var intTypes = new Array();
	for (i=0; i< int_status.length; i++)
	{
		intNames[i] = int_status[i][0];
		intTypes[i] = int_status[i][6]; // Type of Port - Incredible will have FRULink for SFP & SFP+ .Its supports 3 types of network module. Add different type of modules by checking which port is connected.
	}
	
	var interfaces = "#"+intNames.join('#')+"#";


	 xPortCoord =561;//42;// 285;
	 yPortCoord = 51;
	 portWidth = 23;
	 xPortGap=1;
	if(FRUModule.indexOf("none") != -1) { 
		addIncredibleLabel(dev,0); 
	}
	else if(FRUModule.indexOf("1G Module") != -1) {
	for(i=24; i<28; i++) {       
		port = new top.SFPport(int_status[i][6], portImages);
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		xPortCoord += (portWidth + xPortGap);
		dev.addPort(port);
		}
	addIncredibleLabel(dev,1); // add G1,G2,G3,G4 label
	}
	else if (FRUModule.indexOf("10G ST") != -1) { 
		var portInd = 24;
		xPortCoord = 561;
		xPortGap = 1;
		portWidth = 23;
		yPortCoord = 50;
		if(intTypes[28] != "Not Present" || intTypes[29] != "Not Present") //Te1 and Te2 
		{
			if (intTypes[24] != "Not Present" || intTypes[25] != "Not Present")	
				{	
				for(i=portInd; i<portInd+3; i++) //G1,G2,Te2
					{    
						if(i == 26){
						port = new top.SFPplusport(int_status[i+3][6], portImages);// pass the module type plugged-in the SFP slot
						}
						else 
						port = new top.SFPport(int_status[i][6], portImages);
						port.index = i;
						port.id = "port_" + i;
						port.x = xPortCoord;
						port.y = yPortCoord;
						if(i == 25) xPortGap=25;//5;
						xPortCoord += portWidth + xPortGap;
						dev.addPort(port);
			
					}
			addIncredibleLabel(dev,4);
			}
			else if (intTypes[28] != "Not Present" && (intTypes[26] != "Not Present" 
				|| intTypes[27] != "Not Present"))		// Te1 and G3, G4
				{	
				xPortCoord = 562;
				for(i=portInd; i<portInd+3; i++) // Te1,G3,G4 
					{    
					if(i == 24) {
					xPortCoord = 585;//562;
					portWidth=23;//43;
					port = new top.SFPplusport(int_status[i+4][6], portImages); // pass the module type plugged-in the SFP slot
					port.index = i;
					port.id = "port_" + i;
					port.x = xPortCoord;
					port.y = yPortCoord;			
					xPortCoord += portWidth + xPortGap;
					}
					else {
					port = new top.SFPport(int_status[i+1][6], portImages);
					portWidth=23;
					xPortGap = 1;
					port.index = i;
					port.id = "port_" + i;
					port.x = xPortCoord;
					port.y = yPortCoord;			
					xPortCoord += portWidth + xPortGap; 
					}
					dev.addPort(port);
				}
				addIncredibleLabel(dev,3);
			}
			else 
				{ //For Te1,Te2
					xPortCoord = 585;//560;
					for(i=portInd; i<portInd+2; i++){			
					//portWidth = 43;
					xPortGap = 25;//5;
					port = new top.SFPplusport(int_status[i+4][6], portImages); 
					port.index = i;
				//	port.width=23;
					port.id = "port_" + i;
					port.x = xPortCoord;
					port.y = yPortCoord;			
					xPortCoord += portWidth + xPortGap;
					dev.addPort(port);
				}
				addIncredibleLabel(dev,2);//Te1 and Te2 Label
			}
		}
		else
		{
			for(i=portInd; i<portInd+4; i++) //G1,G2,G3,G4
			{    
				port = new top.SFPport(int_status[i][6], portImages);
				port.index = i;
				port.id = "port_" + i;
				port.x = xPortCoord;
				port.y = yPortCoord;			
				xPortCoord += portWidth + xPortGap;
				dev.addPort(port);
			}		
				
		addIncredibleLabel(dev,5);// add G1,G2,G3,G4 label for 10G NM Module
		}
	}
	else if(FRUModule.indexOf("10G SM Module") != -1) {	//10G Service Module FRULink. [G2/Te1,G4/Te2]  WallE Module
		dev.image = "images/6750X_24S_SM_Module.gif";
		draw10GServiceModule(24,606,int_status,intTypes,dev,portImages);
	}
	else if(FRUModule.indexOf("10GT Module") != -1) {	//10G Service Module FRULink. [G2/Te1,G4/Te2]  Gamma Jack Module
		dev.image = "images/6750X_24S_10GT_Module.gif"; //Gamma Jack Module Support
		draw10GTNMModule(24,585,int_status,intTypes,dev,portImages,hardwareModuleActivePorts);
	}
	dev.modeAliases = new Array ("STATUS","DUPLEX","SPEED","STACK");	
	return dev;
	
}


function SW6750X12S(int_status, media_type,FRULinkname,hardwareModuleActivePorts) {
	var dev = new top.device();
	var FRUModule= FRULinkname;
	dev.noofports = 30; 
	dev.x=0;
	dev.y=0;
	dev.image = "images/6750X_12S.gif";

   // drawLedsForPowerSwitch(dev);	
   drawledsforSyndrome(dev);
	
	// Create the ports
	var port;
	var portWidth = 19;
	var portImages = top.SFP_SXImages();
	var xPortGap = 1;
	var xPortGroupGap = 8;
	var xPortStartPos =298;//42;
	var xPortCoord = xPortStartPos;
	var yPortCoord = 50;

	// Add the 12 SFP ports in 2 groups of 6 each.
	for(i=0; i<12; i++) {       
		port = new top.SFPport(int_status[i][6], portImages);
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		xPortCoord += (portWidth + xPortGap);
		if(i==5) {
			xPortCoord += (xPortGroupGap - xPortGap);
		}
		dev.addPort(port);
    }

	var intNames = new Array();
	var intTypes = new Array();
	for (i=0; i< int_status.length; i++)
	{
		intNames[i] = int_status[i][0];
		intTypes[i] = int_status[i][6]; // Type of Port - Incredible will have FRULink for SFP & SFP+ .Its supports 3 types of network module. Add different type of modules by checking which port is connected.
	}
	
	var interfaces = "#"+intNames.join('#')+"#";


	 xPortCoord =561;//42;// 285;
	 yPortCoord = 51;
	 portWidth = 23;
	 xPortGap=1;
	if(FRUModule.indexOf("none") != -1) { 
		addIncredibleLabel(dev,0); 
	}
	else if(FRUModule.indexOf("1G Module") != -1) {
	for(i=12; i<16; i++) {       
		port = new top.SFPport(int_status[i][6], portImages);
		port.index = i;
		port.x = xPortCoord;
		port.y = yPortCoord;
		port.id = "port_" + i;
		xPortCoord += (portWidth + xPortGap);
		dev.addPort(port);
		}
	addIncredibleLabel(dev,1); // add G1,G2,G3,G4 label
	}
	else if (FRUModule.indexOf("10G ST") != -1) {
		var portInd = 12;
		xPortCoord = 561;
		xPortGap = 1;
		portWidth = 23; 
		yPortCoord = 50;
		if(intTypes[16] != "Not Present" || intTypes[17] != "Not Present") //Te1 and Te2 
		{
			if (intTypes[12] != "Not Present" || intTypes[13] != "Not Present")	
				{	
				for(i=portInd; i<portInd+3; i++) //G1,G2,Te2
					{    
						if(i == 14){
						port = new top.SFPplusport(int_status[i+3][6], portImages);// pass the module type plugged-in the SFP slot
					//	port.width=23;
						}
						else 
						port = new top.SFPport(int_status[i][6], portImages);
						port.index = i;
						port.id = "port_" + i;
						port.x = xPortCoord;
						port.y = yPortCoord;
						if(i == 13) xPortGap=25;//5;
						xPortCoord += portWidth + xPortGap;
						dev.addPort(port);
			
					}
			addIncredibleLabel(dev,4);
			}
			else if (intTypes[16] != "Not Present" && (intTypes[14] != "Not Present" 
				|| intTypes[15] != "Not Present"))		// Te1 and G3, G4
				{	
				xPortCoord = 562;
				for(i=portInd; i<portInd+3; i++) // Te1,G3,G4 
					{    
					if(i == 12) {
					xPortCoord = 585;//562;
					portWidth=23;//43;
					port = new top.SFPplusport(int_status[i+4][6], portImages); // pass the module type plugged-in the SFP slot
				//	port.width=23;
					port.index = i;
					port.id = "port_" + i;
					port.x = xPortCoord;
					port.y = yPortCoord;			
					xPortCoord += portWidth + xPortGap;
					}
					else {
					port = new top.SFPport(int_status[i+1][6], portImages);
					portWidth=23;
					xPortGap = 1;
					port.index = i;
					port.id = "port_" + i;
					port.x = xPortCoord;
					port.y = yPortCoord;			
					xPortCoord += portWidth + xPortGap; 
					}
					dev.addPort(port);
				}
				addIncredibleLabel(dev,3);
			}
			else 
				{ //For Te1,Te2
					xPortCoord = 585;//560;
					for(i=portInd; i<portInd+2; i++){			
					//portWidth = 43;
					xPortGap = 25;//5;
					port = new top.SFPplusport(int_status[i+4][6], portImages); 
					port.index = i;
				//	port.width=23;
					port.id = "port_" + i;
					port.x = xPortCoord;
					port.y = yPortCoord;			
					xPortCoord += portWidth + xPortGap;
					dev.addPort(port);
				}
				addIncredibleLabel(dev,2);//Te1 and Te2 Label
			}
		}
		else
		{
			for(i=portInd; i<portInd+4; i++) //G1,G2,G3,G4
			{    
				port = new top.SFPport(int_status[i][6], portImages);
				port.index = i;
				port.id = "port_" + i;
				port.x = xPortCoord;
				port.y = yPortCoord;			
				xPortCoord += portWidth + xPortGap;
				dev.addPort(port);
			}		
				
		addIncredibleLabel(dev,5);// add G1,G2,G3,G4 label for 10G NM Module
		}
	}
	else if(FRUModule.indexOf("10G SM Module") != -1) {	//10G Service Module FRULink. [G2/Te1,G4/Te2]  WallE Module
		dev.image = "images/6750X_12S_SM_Module.gif";
		draw10GServiceModule(12,606,int_status,intTypes,dev,portImages);
	}
	else if(FRUModule.indexOf("10GT Module") != -1) {	//10G Service Module FRULink. [G2/Te1,G4/Te2]  Gamma Jack Module
		dev.image = "images/6750X_12S_10GT_Module.gif"; //Gamma Jack Module Support
		draw10GTNMModule(12,585,int_status,intTypes,dev,portImages,hardwareModuleActivePorts);
	}

	dev.modeAliases = new Array ("STATUS","DUPLEX","SPEED","STACK");	
	return dev;
}


function drawledsforIncredibles(dev) {
	//create mode button
    var modeBtn = new top.modebtn("images/C3560E_PD_mode.gif");
	modeBtn.x = 28;//36;//30;
	modeBtn.y = 6;//10;//67;//63;
	modeBtn.height = 9;//8;
	modeBtn.width = 11;//16;
	modeBtn.id = "mode_btn";
	modeBtn.device = dev;
	dev.modebtn = modeBtn;		

	//USB Console - enable LED 
	var ledImages = top.ledImages();
	var tempLed = new top.led(ledImages);
	tempLed.x = 74;//13;
	tempLed.y = 13;//21;
	tempLed.id = "usb_console_led";
	tempLed.device = dev;
	dev.sysleds["USB CONSOLE"] = tempLed;
	
	// Stack Power LED - [S-PWR]
	var tempLed = new top.led(ledImages);
	tempLed.x = 103;//13;
	tempLed.y = 13;//21;
	tempLed.id = "spwr_led";
	tempLed.device = dev;
	dev.sysleds["STACK POWER"] = tempLed;

	// Create System LEDs
	var ledImages = top.ledImages();
	var tempLed = new top.led(ledImages);
	tempLed.x = 74;//13;
	tempLed.y = 6;//21;
	tempLed.id = "system_led";
	tempLed.device = dev;
	dev.sysleds["SYSTEM"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 103;
	tempLed.y = 6;//27;
	tempLed.id = "rps_led"; //XPS
	tempLed.device = dev; 
//	dev.sysleds["XPS"] = tempLed; //Replaced XPS by RPS - temp check
	dev.sysleds["RPS"] = tempLed;
	
	tempLed = new top.led(ledImages);
	tempLed.x = 142;//13;
	tempLed.y = 6;//39;
	tempLed.id = "status_led";
	tempLed.device = dev;
	dev.sysleds["STATUS"] = tempLed;

	
	tempLed = new top.led(ledImages);
	tempLed.x = 172;//13;
	tempLed.y = 6;//51;
	tempLed.id = "speed_led";
	tempLed.device = dev;
	dev.sysleds["SPEED"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 206;//13;
	tempLed.y = 6;
	tempLed.id = "duplex_led";
	tempLed.device = dev;
	dev.sysleds["DUPLEX"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 103;//13;
	tempLed.y = 13;//33;
	tempLed.id = "spwr_led";
	tempLed.device = dev;
	dev.sysleds["S-PWR"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 142;//13;
	tempLed.y = 13;//33;
	tempLed.id = "master_led";
	tempLed.device = dev;
	dev.sysleds["MASTER"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 172;//13;
	tempLed.y = 13;//57;
	tempLed.id = "stack_led";
	tempLed.device = dev;
	dev.sysleds["STACK"] = tempLed;
	
}
function drawledsforSyndrome(dev) {
	//create mode button
    var modeBtn = new top.modebtn("images/C3560E_PD_mode.gif");
	modeBtn.x = 43;//28;//36;//30;
	modeBtn.y = 4;//10;//67;//63;
	modeBtn.height = 9;//8;
	modeBtn.width = 11;//16;
	modeBtn.id = "mode_btn";
	modeBtn.device = dev;
	dev.modebtn = modeBtn;		

	//USB Console - enable LED 
	var ledImages = top.ledImages();
	var tempLed = new top.led(ledImages);
	tempLed.x = 90;//74;//13;
	tempLed.y = 13;//13;//21;
	tempLed.id = "usb_console_led";
	tempLed.device = dev;
	dev.sysleds["USB CONSOLE"] = tempLed;
	
	// Stack Power LED - [S-PWR]
	var tempLed = new top.led(ledImages);
	tempLed.x = 119;//103;//13;
	tempLed.y = 13;//13;//21;
	tempLed.id = "spwr_led";
	tempLed.device = dev;
	dev.sysleds["STACK POWER"] = tempLed;

	// Create System LEDs
	var ledImages = top.ledImages();
	var tempLed = new top.led(ledImages);
	tempLed.x = 90;
	tempLed.y = 6;
	tempLed.id = "system_led";
	tempLed.device = dev;
	dev.sysleds["SYSTEM"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 119;
	tempLed.y = 6;
	tempLed.id = "rps_led"; //XPS
	tempLed.device = dev; 
	dev.sysleds["RPS"] = tempLed;
	
	tempLed = new top.led(ledImages);
	tempLed.x = 158;//
	tempLed.y = 6;
	tempLed.id = "status_led";
	tempLed.device = dev;
	dev.sysleds["STATUS"] = tempLed;

	
	tempLed = new top.led(ledImages);
	tempLed.x = 188;
	tempLed.y = 6;
	tempLed.id = "speed_led";
	tempLed.device = dev;
	dev.sysleds["SPEED"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 222;
	tempLed.y = 6;
	tempLed.id = "duplex_led";
	tempLed.device = dev;
	dev.sysleds["DUPLEX"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 120;
	tempLed.y = 13;
	tempLed.id = "spwr_led";
	tempLed.device = dev;
	dev.sysleds["S-PWR"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 158;
	tempLed.y = 13;
	tempLed.id = "master_led";
	tempLed.device = dev;
	dev.sysleds["MASTER"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 188;
	tempLed.y = 13;
	tempLed.id = "stack_led";
	tempLed.device = dev;
	dev.sysleds["STACK"] = tempLed;
	
}
function drawledsforIncredibles_power(dev) {

	//create mode button
    var modeBtn = new top.modebtn("images/C3560E_PD_mode.gif");
	modeBtn.x = 28;
	modeBtn.y = 6;
	modeBtn.height = 9;//8;
	modeBtn.width = 11;//16;
	modeBtn.id = "mode_btn";
	modeBtn.device = dev;
	dev.modebtn = modeBtn;		

	//USB Console - enable LED 
	var ledImages = top.ledImages();
	var tempLed = new top.led(ledImages);
	tempLed.x = 74;//13;
	tempLed.y = 13;//21;
	tempLed.id = "usb_console_led";
	tempLed.device = dev;
	dev.sysleds["USB CONSOLE"] = tempLed;
	
	// Stack Power LED - [S-PWR]
	var tempLed = new top.led(ledImages);
	tempLed.x = 103;//13;
	tempLed.y = 13;//21;
	tempLed.id = "spwr_led";
	tempLed.device = dev;
	dev.sysleds["STACK POWER"] = tempLed;

	// Create System LEDs
	//var ledImages = top.ledImages();
	var tempLed = new top.led(ledImages);
	tempLed.x = 74;//13;
	tempLed.y = 6;//21;
	tempLed.id = "system_led";
	tempLed.device = dev;
	dev.sysleds["SYSTEM"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 103;
	tempLed.y = 6;//27;
	tempLed.id = "rps_led"; //XPS
	tempLed.device = dev;
	dev.sysleds["RPS"] = tempLed; // replaced XPS by RPS temp 
	
	tempLed = new top.led(ledImages);
	tempLed.x = 142;//13;
	tempLed.y = 6;//39;
	tempLed.id = "status_led";
	tempLed.device = dev;
	dev.sysleds["STATUS"] = tempLed;

	
	tempLed = new top.led(ledImages);
	tempLed.x = 172;//13;
	tempLed.y = 6;//51;
	tempLed.id = "speed_led";
	tempLed.device = dev;
	dev.sysleds["SPEED"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 206;//13;
	tempLed.y = 6;
	tempLed.id = "duplex_led";
	tempLed.device = dev;
	dev.sysleds["DUPLEX"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 103;//13;
	tempLed.y = 13;//33;
	tempLed.id = "spwr_led";
	tempLed.device = dev;
	dev.sysleds["S-PWR"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 142;//13;
	tempLed.y = 13;//33;
	tempLed.id = "master_led";
	tempLed.device = dev;
	dev.sysleds["MASTER"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 172;//13;
	tempLed.y = 13;//57;
	tempLed.id = "stack_led";
	tempLed.device = dev;
	dev.sysleds["STACK"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 206;//13;
	tempLed.y = 13;
	tempLed.id = "power_led";
	tempLed.device = dev;
	dev.sysleds["POWER"] = tempLed;
	
}
function drawleds_3750FX(dev) {
    var modeBtn = new top.modebtn("images/3750fx_mode.gif");
	modeBtn.x = 36;//30;
	modeBtn.y = 67;//63;
	modeBtn.height = 8;
	modeBtn.width = 16;
	modeBtn.id = "mode_btn";
	modeBtn.device = dev;
	dev.modebtn = modeBtn;		


	// Create System LEDs
	var ledImages = top.ledImages();
	var tempLed = new top.led(ledImages);
	tempLed.x = 12;//13;
	tempLed.y = 22;//21;
	tempLed.id = "system_led";
	tempLed.device = dev;
	dev.sysleds["SYSTEM"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 12;//13;
	tempLed.y = 28;//27;
	tempLed.id = "rps_led";
	tempLed.device = dev;
	dev.sysleds["RPS"] = tempLed;
	
	tempLed = new top.led(ledImages);
	tempLed.x = 12;//13;
	tempLed.y = 34;
	tempLed.id = "master_led";
	tempLed.device = dev;
	dev.sysleds["MASTER"] = tempLed;
		
	tempLed = new top.led(ledImages);
	tempLed.x = 12;//13;
	tempLed.y = 40;
	tempLed.id = "status_led";
	tempLed.device = dev;
	dev.sysleds["STATUS"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 12;
	tempLed.y = 46;
	tempLed.id = "duplex_led";
	tempLed.device = dev;
	dev.sysleds["DUPLEX"] = tempLed;

	tempLed = new top.led(ledImages);
	tempLed.x = 12;
	tempLed.y = 52;
	tempLed.id = "speed_led";
	tempLed.device = dev;
	dev.sysleds["SPEED"] = tempLed;
	
	tempLed = new top.led(ledImages);
	tempLed.x = 12;
	tempLed.y = 58;
	tempLed.id = "stack_led";
	tempLed.device = dev;
	dev.sysleds["STACK"] = tempLed;
	
}
function createDevice(int_status, media_type, deviceType,FRULinkname,hardwareModuleActivePorts) {

	var device = null;
	if(deviceType == null)
		return device;	
	if(deviceType == "WS-C3750X-24U" ){                                               
			device = new WSC3750X24U(int_status, media_type);     // Start of Mr.Incredibles UPOE
		   device.family = "3750-X";
	}
	else if(deviceType == "NME-XD-48ES-2S-P") {
		device = new NMEXD48ES2GE(int_status, media_type);
		device.family = "EtherSwitch Service Module";
	} else if(deviceType == "NME-X-23ES-1G-P") {
		device = new NMEX24ES1GE(int_status, media_type);
		device.family = "EtherSwitch Service Module";
	} else if(deviceType == "NME-XD-24ES-1S-P") {
		device = new NMEXD24ES2ST(int_status, media_type);
		device.family = "EtherSwitch Service Module";
	} else if(deviceType == "NME-16ES-1G-P") {
		device = new NME16ES1GE(int_status, media_type);
		device.family = "EtherSwitch Service Module";
	} else if(deviceType == "NME-XD-48ES-2S") {
		device = new NMEXD48ES2GE_NO_PWR(int_status, media_type);
		device.family = "EtherSwitch Service Module";
	} else if(deviceType == "NME-XD-24ES-1S") {
		device = new NMEXD24ES2ST_NO_PWR(int_status, media_type);
		device.family = "EtherSwitch Service Module";
	} else if(deviceType == "NME-X-23ES-1G") {
		device = new NMEX24ES1GE_NO_PWR(int_status, media_type);
		device.family = "EtherSwitch Service Module";
	} else if(deviceType == "NME-16ES-1G") {
		device = new NME16ES1GE_NO_PWR(int_status, media_type);
		device.family = "EtherSwitch Service Module";
	} else if(deviceType == "WS-C3750-24FS") {
                device = new WSC375024FS(int_status, media_type);
				device.family = "3750";
        } else if(deviceType == "WS-C3750-24P") {
                device = new WSC375024P(int_status, media_type);
				device.family = "3750";
        } else if(deviceType == "WS-C3750G-12S" || deviceType == "WS-C3750G-12S-D") {
                device = new WSC3750G12S(int_status, media_type);
				device.family = "3750";
        } else if(deviceType == "WS-C3750-48P") {
                device = new WSC375048P(int_status, media_type);
				device.family = "3750";
        } else if(deviceType == "WS-C3750G-24T") {
                device = new WSC3750G24T(int_status, media_type);
				device.family = "3750";
        } else if(deviceType == "WS-C3750G-24TS") {
                device = new WSC3750G24TS(int_status, media_type);
				device.family = "3750";
        } else if(deviceType == "WS-C3750G-16TD") {
                device = new WSC3750G16TD(int_status, media_type);
				device.family = "3750";
        } else if(deviceType.indexOf ("WS-C3750-48") != -1) {
                device = new WSC375048TS(int_status, media_type);
				device.family = "3750";
        } else if(deviceType.indexOf ("WS-C3750-24") != -1) {
                device = new WSC375024TS(int_status, media_type);
				device.family = "3750";
        } else if(deviceType == "WS-C3750G-24PS") {
                device = new WSC3750G24PS(int_status, media_type);
				device.family = "3750";
        } else if(deviceType == "WS-C3750G-24TS-1U") {
                device = new WSC3750G24TS1U(int_status, media_type);
				device.family = "3750";
        } else if(deviceType == "WS-C3750G-48PS") {
                device = new WSC3750G48P(int_status, media_type);
				device.family = "3750";
        } else if(deviceType == "WS-C3750G-48TS") {
                device = new WSC3750G48TS(int_status, media_type);
				device.family = "3750";
        } else if(deviceType == "WS-C3750G-24PS-W24" || 
                  deviceType == "WS-C3750G-24PS-W12" || 
                  deviceType == "WS-C3750G-24WS-S24" || 
                  deviceType == "WS-C3750G-24WS-S12" ||
                  deviceType == "WS-C3750G-24WS-S25" ||
                  deviceType == "WS-C3750G-24WS-S50") {
                device = new WSC3750G24_2_2(int_status, media_type);
				device.family = "3750";
        } else if(deviceType == "WS-C3750E-24PD") {
		device = new BULLSEYE24P(int_status, media_type);
		device.family = "3750-E";
	} else if(deviceType == "WS-C3750E-24TD") {
		device = new BULLSEYE24(int_status, media_type);
                device.family = "3750-E";
	} else if(deviceType == "WS-C3750E-48PD") {
		device = new BULLSEYE48P(int_status, media_type);
                device.family = "3750-E";
	} else if(deviceType == "WS-C3750E-48TD") {
		device = new BULLSEYE48(int_status, media_type);
                device.family = "3750-E";
	}else if(deviceType.indexOf("WS-C3750E-12SD") != -1){
			device = new SLINKY12(int_status, media_type);
              device.family = "3750-E";
	}else if(deviceType.indexOf("WS-C3750V2-24PS") != -1){
			device = new WSC3750F24PS(int_status, media_type);
			device.family = "3750-V2";
	}else if(deviceType.indexOf("WS-C3750V2-24TS") != -1){
			device = new WSC3750F24TS(int_status, media_type);
			device.family = "3750-V2";
	}else if(deviceType.indexOf("WS-C3750V2-48PS") != -1){
			device = new WSC3750F48PS(int_status, media_type);
			device.family = "3750-V2";
	}else if(deviceType.indexOf("WS-C3750V2-48TS") != -1){
			device = new WSC3750F48TS(int_status, media_type);
			device.family = "3750-V2";
	}else if(deviceType.indexOf("WS-C3750X-24P") != -1){// Start of Mr.Incredibles  
			device = new WSC3750X24P(int_status, media_type,FRULinkname,hardwareModuleActivePorts);
		   device.family = "3750-X";
	}else if(deviceType.indexOf("SW-6750X-24P") != -1){// Start of Mr.Incredibles  
			device = new SW6750X24P(int_status, media_type,FRULinkname,hardwareModuleActivePorts);
		   device.family = "6750-X";
	}else if(deviceType.indexOf("WS-C3750X-24S") != -1){// Syndrome 24
			device = new WSC3750X24S(int_status, media_type,FRULinkname,hardwareModuleActivePorts);
			device.family = "3750-X";
	}else if(deviceType.indexOf("SW-6750X-24S") != -1){// Syndrome 24
			device = new SW6750X24S(int_status, media_type,FRULinkname,hardwareModuleActivePorts);
			device.family = "6750-X";
	}else if(deviceType.indexOf("WS-C3750X-12S") != -1){// Syndrome 12
			device = new WSC3750X12S(int_status, media_type,FRULinkname,hardwareModuleActivePorts);
			device.family = "3750-X";
	}else if(deviceType.indexOf("WS-C3750X-24") != -1){
			device = new WSC3750X24(int_status, media_type,FRULinkname,hardwareModuleActivePorts);
			device.family = "3750-X";
	}else if(deviceType == "WS-C3750X-48U" ){
			device = new WSC3750X48U(int_status, media_type);
			device.family = "3750-X";
	}else if(deviceType.indexOf("WS-C3750X-48P") != -1){
			device = new WSC3750X48P(int_status, media_type,FRULinkname,hardwareModuleActivePorts);
			device.family = "3750-X";
	}else if(deviceType.indexOf("SW-6750X-48P") != -1){
			device = new SW6750X48P(int_status, media_type,FRULinkname,hardwareModuleActivePorts);
			device.family = "6750-X";
	}else if(deviceType.indexOf("WS-C3750X-48") != -1){ 
			device = new WSC3750X48(int_status, media_type,FRULinkname,hardwareModuleActivePorts);
			device.family = "3750-X";
	}else if(deviceType.indexOf("SW-6750X-48") != -1){ 
			device = new SW6750X48(int_status, media_type,FRULinkname,hardwareModuleActivePorts); 
			device.family = "6750-X";
	}else if(deviceType.indexOf("SW-6750X-24") != -1){
			device = new SW6750X24(int_status, media_type,FRULinkname,hardwareModuleActivePorts);
			device.family = "6750-X";
	}else if(deviceType.indexOf("SW-6750X-12S") != -1){// Syndrome 12
			device = new SW6750X12S(int_status, media_type,FRULinkname,hardwareModuleActivePorts);
			device.family = "6750-X";
	}else if(deviceType.indexOf("WS-C3750V2-24FX") != -1){
			device = new WSC3750V224FX(int_status, media_type);
			device.family = "3750-V2";
	}else if(deviceType.indexOf("WS-C3750V2-24FS") != -1){
			device = new WSC3750V224FS(int_status, media_type);
			device.family = "3750-V2";
	}


	if(device != null) {
		device.type = deviceType;
	}

	return device;
}

function draw1GNetworkModule(portIndex,xPortStartPos,int_status,dev,portImages) {
	var port;
	var	portInd = portIndex;
	var	xPortCoord = xPortStartPos;
	var	xPortGap = 1;
	var	portWidth = 23;
		for(i=portInd; i<portInd+4; i++) 
		{       
			yPortCoord = 50;//13;		
			port = new top.SFPport(int_status[i][6], portImages); // pass the module type plugged-in the SFP slot
			port.index = i;
			port.x = xPortCoord;
			port.y = yPortCoord;
			port.id = "port_" + i;
			xPortCoord += (portWidth + xPortGap);
			dev.addPort(port);
		
		}
			addIncredibleLabel(dev,1);  // add G1,G2,G3,G4 label			
}

function draw10GNetworkModule(portIndex,xPortStartPos,int_status,intTypes,dev,portImages) {// 10G Network module FRULink. [G1,G2,G3,G4, Te1,Te2]
		var port;
		var portInd = portIndex;
		var xPortCoord = xPortStartPos;
		var xPortGap = 1;
		var portWidth = 23;
		var yPortCoord = 50;
		if(intTypes[portInd+4] != "Not Present" || intTypes[portInd+5] != "Not Present") //Te1 and Te2 
		{
			if (intTypes[portInd] != "Not Present" || intTypes[portInd+1] != "Not Present")	
				{	
				for(i=portInd; i<portInd+3; i++) //G1,G2,Te2
					{    
						if(i == portInd+2){
						port = new top.SFPplusport(int_status[i+3][6], portImages);// pass the module type plugged-in the SFP slot
						}
						else 
						port = new top.SFPport(int_status[i][6], portImages);
						port.index = i;
						port.id = "port_" + i;
						port.x = xPortCoord;
						port.y = yPortCoord;
						if(i == portInd+1) xPortGap=25;//5;
						xPortCoord += portWidth + xPortGap;
						dev.addPort(port);
			
					}
			addIncredibleLabel(dev,4);
			}
			else if (intTypes[portInd+4] != "Not Present" && (intTypes[portInd+2] != "Not Present" 
				|| intTypes[portInd+3] != "Not Present"))		// Te1 and G3, G4
				{	
				xPortCoord = 562;
				for(i=portInd; i<portInd+3; i++) // Te1,G3,G4 
					{    
					if(i == portInd) {
					xPortCoord = 585;//562;
					portWidth=23;//43;
					port = new top.SFPplusport(int_status[i+4][6], portImages); // pass the module type plugged-in the SFP slot
					port.index = i;
					port.id = "port_" + i;
					port.x = xPortCoord;
					port.y = yPortCoord;			
					xPortCoord += portWidth + xPortGap;
					}
					else {
					port = new top.SFPport(int_status[i+1][6], portImages);
					portWidth=23;
					xPortGap = 1;
					port.index = i;
					port.id = "port_" + i;
					port.x = xPortCoord;
					port.y = yPortCoord;			
					xPortCoord += portWidth + xPortGap; 
					}
					dev.addPort(port);
				}
				addIncredibleLabel(dev,3);
			}
			else 
				{ //For Te1,Te2
					xPortCoord = 585;//560;
					for(i=portInd; i<portInd+2; i++){			
					//portWidth = 43;
					xPortGap = 25;//5;
					port = new top.SFPplusport(int_status[i+4][6], portImages); 
					port.index = i;
					port.id = "port_" + i;
					port.x = xPortCoord;
					port.y = yPortCoord;			
					xPortCoord += portWidth + xPortGap;
					dev.addPort(port);
				}
				addIncredibleLabel(dev,2);//Te1 and Te2 Label
			}
		}
		else
		{
			for(i=portInd; i<portInd+4; i++) //G1,G2,G3,G4
			{    
				port = new top.SFPport(int_status[i][6], portImages);
				port.index = i;
				port.id = "port_" + i;
				port.x = xPortCoord;
				port.y = yPortCoord;			
				xPortCoord += portWidth + xPortGap;
				dev.addPort(port);
			}		
				
		addIncredibleLabel(dev,5);// add G1,G2,G3,G4 label for 10G NM Module
		}
	}

function draw10GServiceModule(portIndex,xPortStartPos,int_status,intTypes,dev,portImages){
		var port;
		var portInd = portIndex;
		var xPortCoord = xPortStartPos;
		var	yPortCoord = 47;
		var xPortGap = 1;
		var portWidth = 23;
			
		for (var i=portInd;i<portInd+2;i++)
		{ 
	
			if (intTypes[i] != "Not Present")
			port = new top.SFPport(int_status[i][6], portImages); // 1G 
			else 
			port = new top.SFPplusport(int_status[i+2][6], portImages); // 10G 
			port.index = i;
			port.id = "port_" + i;
			port.x = xPortCoord;
			port.y = yPortCoord;			
			xPortCoord += portWidth + xPortGap;
			dev.addPort(port);
		}

}
function draw10GTNMModule(portIndex,xPortStartPos,int_status,intTypes,dev,portImages,hardwareModuleActivePorts){
        var port;
		var portInd = portIndex;
		var xPortCoord = xPortStartPos;
		var	yPortCoord = 51;
		var xPortGap = 1;
		var portWidth = 23;
		for (var i=portInd;i<portInd+2;i++){
		   if(hardwareModuleActivePorts[i-portInd].indexOf("Gi")!=-1)
						port = new top.SFPport(int_status[i][6], portImages); // 1G 
				else
						port = new top.SFPplusport(int_status[i][6], portImages); // 10G 
				port.index = i;
				port.id = "port_" + i;
				port.x = xPortCoord;
				port.y = yPortCoord;			
				xPortCoord += portWidth + xPortGap;
				dev.addPort(port);
		}
 }



