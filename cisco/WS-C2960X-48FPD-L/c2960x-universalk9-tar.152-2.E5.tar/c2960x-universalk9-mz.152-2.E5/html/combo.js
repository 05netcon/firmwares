<!-- Copyright (c) 2004-2005, 2012 by Cisco Systems, Inc. -->

/*
 *------------------------------------------------------------------
 * combo.js
 *------------------------------------------------------------------
*/
 
///////////////global variables///////////////
var IE = false;
var netscape = false;
var eventsArr = new eventObj();

var arrowImage = new Image(16, 17);
arrowImage.src = "images/comboArrow.gif";
var pressedArrowImage = new Image(16, 17);
pressedArrowImage.src = "images/comboPressedArrow.gif";

///////////////global functions///////////////
if(!document.all && document.getElementById) netscape = true;
else if(document.all) IE = true;

function collapseCombo() {
	for(var i= 0; i < eventsArr.eventsCount; i++)
	{
		document.getElementById(eventsArr.objects[i]).childNodes[1].style.display = "none";
	}
}

document.onclick = collapseCombo;
window.onblur = collapseCombo;

///////////////object constructors///////////////
function combo(_id) {
	this.id = _id;
	this.width = 100;
	this.height = 100;
	this.itemCount = 0;
	this.headTable = "";
	this.itemsTable = "";
	this.initialSelection = true;
	this.items = new Array();
	this.addItem = _addItem;
	this.createCombo = _createCombo;
	this.onSelectionChange = "";
	this.setSelectionChange = _setSelectionChange;
	this.getSelectedIndex = _getSelectedIndex;
	this.setSelectedIndex = _setSelectedIndex;
	this.getValue = _getValue;
	this.hideItems = _hideItems;
}

function option(_image, _text, _value, _class, _selectable) {
	this.image = new Image();
	this.image.src = _image;
	this.image.width = 16;
	this.image.height = 17;
	this.text = _text;
	this.value = _value;
	this.selectable = _selectable;
	this.styleClass = _class;
	this.iconUrl = _image;
	
}

function eventObj() {
	this.eventsCount = 0;
	this.objects = new Array();
	this.eventNames = new Array();
	this.events = new Array();
	this.registerEvent = _registerEvent;
	this.getEvent = _getEvent;
}

///////////////object methods///////////////
function _addItem(_image, _text, _value, _class, _selectable, _dynamicIconLable) {
	this.items[this.itemCount] = new option(_image, _text, _value, _class, _selectable, _dynamicIconLable);
	this.itemCount++;
}

function _createCombo() {
	if(this.itemCount == 0)
		return;
	
	var comboText = "";
	comboText += "<div id='" + this.id + "' selectedIndex='0' style='width:" + this.width + ";'>";
	comboText += "<table cellspacing='0' cellpadding='1' style='border:2px inset buttonhighlight;width:" + this.width + ";background:#FFFFFF;'>";
	comboText += "<tr>";
	comboText += "<td class='"+ this.items[0].styleClass + "' style='padding-left:2px;cursor:default;' onclick='event.cancelBubble = true;displayItems(\"" + this.id + "\", true)' unselectable='on'>";
	if(this.initialSelection) {
		comboText += "<img src='" + this.items[0].image.src + "' height='" + this.items[0].image.height + "' width='" + this.items[0].image.width + "' align='absmiddle'>";
		comboText += "&nbsp;";
		comboText += this.items[0].text;
	}
	else {
		comboText += "<img src='images/pixel.gif' width='" + (this.width-30) + "px' height='17px' align='absmiddle'>";
	}
	comboText += "</td>";
	comboText += "<td align='right'>";
	comboText += "<img src='images/comboArrow.gif' height='17px' width='16px' onMouseDown='this.src=\"images/comboPressedArrow.gif\"' onMouseUp='this.src=\"images/comboArrow.gif\"' onClick='event.cancelBubble = true;displayItems(\"" + this.id + "\", true)'>";
	comboText += "</td>";
	comboText += "</tr>";
	comboText += "</table>";
	comboText += "<div style='position:absolute;overflow:auto;display:none;background:#FFFFFF;border:1px solid windowtext;height:" + this.height + ";width:" + this.width + ";padding:0;'>";
	comboText += "<table cellspacing='0' cellpadding='1' style=''>";
	for(var i = 0; i < this.items.length; i++)
	{
		comboText += "<tr>";
		comboText += "<td style='width:" + this.width + ";cursor:default;' class='"+ this.items[i].styleClass + "' onmouseover='itemMouseOver(this)' onmouseout='itemMouseOut(this)' onclick='itemClick(this, \"" + this.id + "\", " + i + ", true)' selectable='" + this.items[i].selectable + "'>";
		if(this.items[i].iconUrl != "")
			comboText += "<img src='" + this.items[i].image.src + "' height='" + this.items[i].image.height + "' width='" + this.items[i].image.width + "' align='absmiddle'>";
		comboText += "&nbsp;";
		comboText += this.items[i].text;
		
		//comboText += "<img width='16px' height='0px'>";
		comboText += "</td>";
		comboText += "</tr>";
	}
		comboText += "<tr style='display:none;visibility:hidden;'>";
		comboText += "<td style='width:" + this.width + ";cursor:default;' onmouseover='itemMouseOver(this)' onmouseout='itemMouseOut(this)' onclick='itemClick(this, \"" + this.id + "\", " + i + ", true)' selectable='true'>";
		comboText += "<img src='images/pixel.gif' width='" + (this.width-30) + "px' height='17px' align='absmiddle'>";
		comboText += "&nbsp;";
		//comboText += this.items[i].text;
		//comboText += "<img width='16px' height='0px'>";
		comboText += "</td>";
		comboText += "</tr>";
		
	comboText += "</table>";
	comboText += "</div>";
	comboText += "</div>";
	
	return comboText;
	/*var headTableObj = document.createElement("TABLE");
	headTableObj.style.cellSpacing = 0;
	headTableObj.style.cellPadding = 1;
	headTableObj.style.border = "2px inset buttonhighlight";
	this.headTable = headTableObj;
	
	var itemsTableObj = document.createElement("TABLE");
	itemsTableObj.style.cellSpacing = 0;
	itemsTableObj.style.cellPadding = 1;
	itemsTableObj.style.border = "1px solid windowtext";
	itemsTableObj.style.position = "absolute";
	itemsTableObj.style.display = "none";
	itemsTableObj.style.background = "#FFFFFF";
	this.itemsTable = itemsTableObj;
	
	for(var i = 0; i < this.items.length; i++)
	{
		var itemRow = document.createElement("TR");
		var itemCell = document.createElement("TD");
		itemCell.onmouseover = itemCellMouseOver;
		itemCell.onmouseout = itemCellMouseOut;
		itemCell.className = this.items[i].styleClass;
		itemCell.appendChild(this.items[i].image);
		itemCell.appendChild(this.items[i].text);
		
		itemRow.appendChild(itemCell);
		itemsTableObj.appendChild(itemRow);
	}*/
}

function _setSelectionChange(_function) {
	eventsArr.registerEvent(this.id, "onselectionchange", _function);
	//document.getElementById(this.id).onselectionchange = _function;
}

function _getSelectedIndex() {
	if(document.getElementById(this.id))
		return document.getElementById(this.id).selectedIndex;
	else
		return null;
}

function _setSelectedIndex(_index) {
	if(document.getElementById(this.id) && !isNaN(parseInt(_index)))
	{
		//document.getElementById(this.id).childNodes[1].childNodes[0].rows[_index].cells[0].click();
		if(_index == -1) {
			var tmpIndex = document.getElementById(this.id).childNodes[1].childNodes[0].rows.length;
			itemClick(document.getElementById(this.id).childNodes[1].childNodes[0].rows[tmpIndex-1].cells[0], this.id, _index, false);
		}
		else {
			itemClick(document.getElementById(this.id).childNodes[1].childNodes[0].rows[_index].cells[0], this.id, _index, false);
		}
	}
}

function _getValue() {
	if(document.getElementById(this.id).selectedIndex == -1) {
		return null;
	}
	if(document.getElementById(this.id))
		return this.items[document.getElementById(this.id).selectedIndex].value;
	else
		return null;
}

function _hideItems() {
	if(document.getElementById(this.id))
		document.getElementById(this.id).childNodes[1].style.display = "none";
}

function _registerEvent(_id, _event, _function) {
	this.objects[this.eventsCount] = _id;
	this.events[this.eventsCount] = _function;
	this.eventNames[this.eventsCount] = _event;
	this.eventsCount++;
}

function _getEvent(_id, _event) {
	for(var i= 0; i < this.eventsCount; i++)
	{
		if(this.objects[i] == _id && this.eventNames[i] == _event)
			return this.events[i];
	}
	return "";
}

///////////////object events///////////////
function displayItems(_combo, _flag) {
	if(document.getElementById(_combo).selectedItem == null || document.getElementById(_combo).selectedItem == "")
	{
		document.getElementById(_combo).selectedItem = document.getElementById(_combo).childNodes[1].childNodes[0].rows[0].cells[0];
		document.getElementById(_combo).selectedIndex = 0;
	}
	if(!_flag || document.getElementById(_combo).childNodes[1].style.display == "block")
		document.getElementById(_combo).childNodes[1].style.display = "none";
	else
	{
		document.getElementById(_combo).childNodes[1].style.display = "block";
		document.getElementById(_combo).childNodes[1].style.position = "absolute";
		//document.getElementById(_combo).selectedItem.scrollIntoView(true);
		itemMouseOver(document.getElementById(_combo).selectedItem);
	}
}

var _prevObj = "";
function itemMouseOver(_obj) {
	if(_prevObj)
	{
		_prevObj.style.background = "#FFFFFF";
		_prevObj.style.color = "";
	}
	_obj.style.background = "highlight";
	_obj.style.color = "#FFFFFF";
	_prevObj = _obj;
}

function itemMouseOut(_obj) {
	_obj.style.background = "#FFFFFF";
	_obj.style.color = "";
}

function itemClick(_obj, _combo, _index, _flag) {
	if(_obj.getAttribute("selectable") == "true")
	{
		document.getElementById(_combo).childNodes[0].rows[0].cells[0].innerHTML = _obj.innerHTML;
		document.getElementById(_combo).selectedItem = _obj;
		document.getElementById(_combo).selectedIndex = _index;
		var itemEvent = eventsArr.getEvent(_combo, "onselectionchange");
		if(itemEvent != null && itemEvent != "")
			eval(itemEvent + "()");
	}
	displayItems(_combo, _flag);
}