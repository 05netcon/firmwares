/*
 *------------------------------------------------------------------
 * helpframework.js
 *
 * Copyright (c) 2004-2005 by cisco Systems, Inc.
 * All rights reserved.
 *------------------------------------------------------------------
 */

// open the page in the contentFrame
function displayHelp(menuItem) {
	// set the url for the contentarea frame
	//contentFrame.location.href = helpTag;
	if(leftFrame.selectMenu) {
		leftFrame.selectMenu(menuItem);
	}
}

// init method which will be called when the help page 
function init() {
	// get the help tag which needs to be shown
	// if opener is not present; or its null set the helpTag as default one
	// call displayHelp with the helpTag
	var helpTag = null;
	if(window.opener) {
		helpTag = window.opener.getActiveHelpTag();
	}
	
	if(helpTag == null) {
		helpTag = "Introduction";
	}
	displayHelp(helpTag);
}