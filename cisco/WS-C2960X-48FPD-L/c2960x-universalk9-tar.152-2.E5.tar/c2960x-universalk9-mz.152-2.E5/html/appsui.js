/*
 *------------------------------------------------------------------
 * appsui.js --  Applications User Interface Utilities
 *
 * Copyright (c) 2003-2004, 2006 by cisco Systems, Inc.
 * All rights reserved.
 *------------------------------------------------------------------
 */

 var defErrMsgTitle = "Error";
 var defWngMsgTitle = "Warning";
 var defConfMsgTitle = "Attention";
 
 if(top && top.resourceFrame) {
	 defErrMsgTitle = top.resourceFrame.re_frmWrk_ErrMsgDefTtl;
	 defWngMsgTitle = top.resourceFrame.re_frmWrk_WngMsgDefTtl;
	 defConfMsgTitle = top.resourceFrame.re_frmWrk_ConfMsgDefTtl;
 }
 
function openChildWindow( appuri, windowname ) {
 
	var appwindow = window.open( appuri , windowname, "toolbar=yes,status=yes,top=10,left=10,outerWidth=790,outerHeight=500,width=790,height=500,resizable=yes");
	appwindow.focus();
}

function closeWindow() {

	top.window.close();
}

function openPopup( popupuri, windowname ) {

	var popup = window.open( popupuri , windowname, "toolbar=no,status=no,top=100,left=200,width=300,height=190,resizable=no");
	popup.focus();
}


function openWindow(appuri, windowname) {
    var appwindow = window.open( appuri , windowname);
    appwindow.focus();
}

function showError(errorMsg, prefix) {
	if(prefix) {
		prefix += ':\n\n';
	}
	else {
		prefix = defErrMsgTitle + ':\n\n';
	}
	var dispStr = prefix + errorMsg;
	alert(dispStr);
}

function showWarning(warningMsg, prefix) {
	if(prefix) {
		prefix += ':\n\n';
	}
	else {
		prefix = defWngMsgTitle + ':\n\n';
	}
	var dispStr = prefix + warningMsg;
	alert(dispStr);
}

function getConfirmation(dispStr, prefix) {
	if(prefix) {
		prefix += ':\n\n';
	}
	else {
		prefix = defConfMsgTitle + ':\n\n';
	}
	msg = prefix + dispStr;
	return confirm(msg);
}
