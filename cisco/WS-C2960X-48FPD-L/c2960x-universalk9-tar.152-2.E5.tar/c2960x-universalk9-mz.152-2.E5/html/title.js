// Copyright (c) 2003, 2004 by Cisco Systems, Inc.

// This file has to be included in all the html pages
// that will be opened in a seperate window to set the
// title. The <script> tag has to be placed after the
// <title> tag in the html file.
var TITLE = "Cisco Device Manager";
function setTitle() {
	var hostname = "";
	hostname = document.location.href.split("/")[2].split(":")[0];
	var newTitle = ((hostname != "") ? (hostname + " : ") : ("")) + TITLE;
	newTitle += ((document.title != "") ? (" - " + document.title) : (""));
	document.title = newTitle;
}
setTitle();
