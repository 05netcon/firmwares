/*
 *------------------------------------------------------------------
 * health resource file
 * Copyright (c) 2006 by cisco Systems, Inc.
 *------------------------------------------------------------------
*/
// NOTE: This file is shared by dashboard and trends page.";


//Title
var re_trend_ScrTtl="Tendances";

//Resource content for dashboard
var re_trend_ports_Lbl="Ports";
var re_trend_viewtrends_Lbl="Afficher les tendances";

//Table header
var re_trend_TblHeader1="�tat de sant� du commutateur";
var re_trend_TblHeader2="Utilisation au niveau port";
var re_trend_TblHeader3="Utilisation/erreurs des ports";
var re_trend_title_Lbl="Titre";


//Table content
var re_trend_bandutil_Lbl="Utilisation de la bande passante";
var re_trend_stkbandutil_Lbl="Empiler l'utilisation de la bande passante";
var re_trend_packeterr_Lbl="Erreur de paquet";
var re_trend_stkpacketerr_Lbl="Empiler l'erreur de paquet";
var re_trend_inpwrutil_Lbl="Utilisation de l'alimentation �lectrique par c�ble Ethernet";
var re_trend_poeutil_Lbl="Utilisation de PoE";
var re_trend_timeslot_Lbl="Intervalle de temps";
var re_trend_pwrutil_Lbl="Utilisation de l'alimentation";

var re_trend_recutil_Lbl="Utilisation de la r�ception";
var re_trend_transutil_Lbl="Utilisation de la transmission";
var re_trend_receive_Lbl="Recevoir";
var re_trend_transmit_Lbl="Transmettre";


//Tooltip
var re_trend_TltpLbl4="Utilisation";

//link
var re_trend_viewportstat_Lbl="Afficher les statistiques du port";

var re_trend_sec_Lbl="Secondes";
var re_trend_min_Lbl="Minutes";
var re_trend_hrs_Lbl="Heures";
var re_trend_day_Lbl="Jours";

var re_trend_ls_Lbl="Derni�res 60 secondes";
var re_trend_lm_Lbl="Derni�res 60 minutes";
var re_trend_lh_Lbl="Derni�res 24 heures";
var re_trend_ld_Lbl="Derniers 14 jours";

var re_trend_rfsh_Lbl="Actualiser le cycle";
var re_trend_porterr_Lbl="Erreurs de port";
var re_trend_port_Lbl="Port";

//non-macchiato
var re_trend_connport_Lbl="Port reli�";
var re_trend_noport_Txt="Aucun port n'est connect� � ce p�riph�rique";
