/*
 *------------------------------------------------------------------
 * framework resource file - includes SSL, bottom banner buttons, graph, appsui, telnet, network assistant
 * Copyright (c) 2006-2007 by cisco Systems, Inc.
 * feature code - frmWrk
 *------------------------------------------------------------------
*/

//feature pages
var re_frmWrk_WngMsg1="Vous avez cliqu� sur 'Soumettre' sans faire aucune modification dans la bo�te de dialogue.";
var re_frmWrk_WngMsg1Ttl="Informations";

//appsui
var re_frmWrk_ErrMsgDefTtl="Erreur";
var re_frmWrk_WngMsgDefTtl="Avertissement";
var re_frmWrk_ConfMsgDefTtl="Attention";

//framework
var re_frmWrk_ConfMsg1="Avertissement :\n\nIl y a des modifications non enregistr�es sur la page.\n\nCliquez sur OK pour enregistrer les modifications ou sur Annuler pour annuler les modifications et continuer.";
var re_frmWrk_ConfMsgWindowClose="Il y a des modifications non enregistr�es dans la page.";
//no handler messages
var re_frmWrk_ErrMsgNoApply="Aucun gestionnaire disponible pour Appliquer.";
var re_frmWrk_ErrMsgNoCancel="Aucun gestionnaire disponible pour Annuler.";
var re_frmWrk_ErrMsgNoNext="Aucun gestionnaire disponible pour Suivant.";
var re_frmWrk_ErrMsgNoBack="Aucun gestionnaire disponible pour Pr�c�dent.";
var re_frmWrk_ErrMsgNoFinish="Aucun gestionnaire disponible pour Terminer.";
var re_frmWrk_ErrMsgNoHelp="Aucune aide disponible.";

//xhome
var re_frmWrk_TxtFrmSupport="Ces pages utilisent des trames. Veuillez vous assurer que le navigateur supporte compl�tement les fonctions de Trames!";

//graph
var re_frmWrk_GraphLegend="L�gende";

var re_frmWrk_GraphEmpty="[graph. vide]";
var re_frmWrk_GraphTimeSlots="Intervalles de temps";

var re_frmWrk_GraphLblDay1="Dim.";
var re_frmWrk_GraphLblDay2="Lun.";
var re_frmWrk_GraphLblDay3="Mar.";
var re_frmWrk_GraphLblDay4="Merc.";
var re_frmWrk_GraphLblDay5="Jeu.";
var re_frmWrk_GraphLblDay6="Vend.";
var re_frmWrk_GraphLblDay7="Sam.";

var re_frmWrk_GraphLblMonth1="Janv.";
var re_frmWrk_GraphLblMonth2="F�v.";
var re_frmWrk_GraphLblMonth3="Mars";
var re_frmWrk_GraphLblMonth4="Avril";
var re_frmWrk_GraphLblMonth5="Mai";
var re_frmWrk_GraphLblMonth6="Juin";
var re_frmWrk_GraphLblMonth7="Juil.";
var re_frmWrk_GraphLblMonth8="Ao�t";
var re_frmWrk_GraphLblMonth9="Sept.";
var re_frmWrk_GraphLblMonth10="Oct.";
var re_frmWrk_GraphLblMonth11="Nov.";
var re_frmWrk_GraphLblMonth12="D�c.";

var re_frmWrk_GraphLblTimeAM="a.m.";
var re_frmWrk_GraphLblTimePM="p.m.";
var re_frmWrk_GraphLblTitle="Titre";

//SSL dialog
var re_frmWrk_SSLTxt1="Voulez-vous une session s�curis�e avec le commutateur?";
var re_frmWrk_SSLTxt2="Ne plus me poser cette question";
var re_frmWrk_SSLBtn1="Oui";
var re_frmWrk_SSLBtn2="Non";

//bottom frame button names
var re_frmWrk_BtnDone="Termin�";
var re_frmWrk_BtnBack="Pr�c�dent";
var re_frmWrk_BtnNext="Suivant";
var re_frmWrk_BtnFinish="Terminer";
var re_frmWrk_BtnCancel="Annuler";
var re_frmWrk_BtnRefresh="Actualiser";
var re_frmWrk_BtnHelp="Aide";
var re_frmWrk_BtnSubmit="Soumettre";

//network assistant
var re_frmWrk_CNATtl="Network Assistant";

//non-macchiato
//telnet
var re_frmWrk_TelnetTtl="Telnet";
var re_frmWrk_TelnetTxt="La console Telnet procure l'acc�s � l'interface d'environnement WIMP (CLI) du commutateur. L'environnement WIMP (CLI) est une m�thode avanc�e pour communiquer avec votre commutateur Cisco. Cette m�thode avanc�e est recommand�e que pour les experts. Une nouvelle fen�tre sera ouverte lorsque la console Telnet sera demarr�e.";
var re_frmWrk_TelnetLinkTxt1="Lancez la console Telnet";
var re_frmWrk_TelnetLinkTxt2="Telnet n'est pas activ� sur cet �quipement. Allez � {Configurateur express} pour activer Telnet.";

//new Strings

//OLH message
var re_frmWrk_OLHErrMsg1="Information:\n\nL'aide en ligne pour cette fen�tre n'est pas disponible en {0}. Pour afficher l'aide en ligne dans {0}, vous devez d'abord mettre le commutateur � jour avec le logiciel de commutation {0} de Cisco.com";

var re_restart_Ttl="Red�marrer / R�initialiser";
var re_restart_txt1="Red�marrer le commutateur avec ses param�tres actuels.";
var re_restart_txt2="R�initialiser le commutateur avec les r�glages d'usine et red�marrer ensuite le commutateur.";
var re_restart_txt3="Le p�riph�rique sera recharg� dans {0} seconde(s).";
var re_restart_txt4="Le p�riph�rique est en cours de rechargement...";
var re_restart_txt5="Le p�riph�rique a �t� recharg� avec succ�s.";
var re_restart_txt6="Le rechargement est en cours...";
var re_restart_ConfMsg1="Le p�riph�rique r�initialisera les param�tres d'usine par d�faut et supprimera ses adresses IP actuelles. Voulez-vous continuer?";
var re_toolbar_txt_refresh="Actualiser";
var re_toolbar_txt_print="Imprimer";
var re_toolbar_txt_smartports="Smartports";
var re_toolbar_txt_swupgrade="Mise � jour du logiciel";
var re_toolbar_txt_legend="L�gende";
var re_toolbar_txt_help="Aide";
var re_toolbar_txt_forward="Suivant";
var re_toolbar_txt_back="Pr�c�dent";

//network assistant
var re_frmWrk_CNATxt1="Cisco Network Assistant offre une solution centralis�e pour la gestion des commutateurs, des routeurs et des points d'acc�s sans fil Cisco pour r�seaux des petites et moyennes entreprises.";
var re_frmWrk_CNATxt2="Gestion centralis�e du r�seau";
var re_frmWrk_CNATxt3="Configuration intelligente des p�riph�riques";
var re_frmWrk_CNATxt4="Supervision et d�pannage du r�seau simplifi�s";
var re_frmWrk_CNATxt5="Fonction de recherche int�gr�e et aide en ligne";
var re_frmWrk_CNATxt6="APPRENEZ-EN PLUS et T�L�CHARGEZ GRATUITEMENT CISCO NETWORK ASSISTANT!";

//Strings newly added for Uptime display - 03/28/06
var re_Uptime_years ="ann�es";
var re_Uptime_year ="ann�e";
var re_Uptime_weeks ="semaines";
var re_Uptime_week ="semaine";
var re_Uptime_days ="jours";
var re_Uptime_day ="jour";
var re_Uptime_hours ="heures";
var re_Uptime_hour ="heure";
var re_Uptime_minutes ="minutes";
var re_Uptime_minute ="minute";

//Telnet Not supported message for Vista
var re_frmWrk_TelnetLinkTxt3 = "La fonction Telnet n�est pas disponible si votre syst�me d�exploitation est Windows Vista ou si vous utilisez Internet Explorer 7.0.";
