/*
 *------------------------------------------------------------------
 * FPV, topframe resource file
 * Copyright (c) 2006-2007, 2009, 2013 by cisco Systems, Inc.
 *------------------------------------------------------------------
*/

var re_fpv_txt_status="�tat";
var re_fpv_txt_duplex="Duplex";
var re_fpv_txt_speed="Vitesse";
var re_fpv_txt_power="Alimentation";
var re_fpv_txt_poe="PoE";
var re_fpv_txt_view="Affichage";
var re_fpv_txt_nextrefresh1="Prochaine actualisation dans {0} seconde.";
var re_fpv_txt_nextrefresh2="Prochaine actualisation dans {0} secondes.";
var re_fpv_txt_refreshing="Actualisation�";
var re_fpv_txt_refreshpause="Actualisation suspendue";
var re_fpv_txt_movepointer="Pour de plus amples renseignements, d�placez le pointeur au-dessus des ports.";
var re_fpv_Tltp_port="Port";
var re_fpv_Tltp_type="Type";
var re_fpv_Tltp_descr="Description";
var re_fpv_Tltp_uptime="Temps utilisable";
var re_fpv_Tltp_poe="PoE";
var re_fpv_Tltp_noalert="Aucune alerte";
var re_fpv_Tltp_severity="Gravit�";
var re_fpv_Tltp_event="�v�nement";
var re_fpv_Tltp_time="Dur�e";
var re_fpv_Tltp_viewallalert="Afficher toutes les alertes";
var re_Ttl_txt_catseriesdevmanager1="Gestionnaire de p�riph�rique de la gamme ITP {0}";
var re_Ttl_txt_catseriesexsetup1="Configurateur express de la gamme ITP {0}";
var re_Ttl_txt_catseriesdevmanager="Gestionnaire de p�riph�rique de la gamme Catalyst {0}";
var re_Ttl_txt_catseriesexsetup="Configurateur express de la gamme Catalyst {0}";
var re_Ttl_txt_catexsetup="Configuration Catalyst Express";
var re_Ttl_txt_catdevmanager="Gestionnaire de p�riph�rique Catalyst";
var re_Ttl_txt_registernow="Enregistrez-vous maintenant";
var re_Ttl_txt_devmanager="Gestionnaire de p�riph�rique";
var re_SSL_txt_session="Session";
var re_SSL_txt_normalmode="Mode normal";
var re_SSL_txt_securemode="Mode s�curis�";
var re_SSL_txt_standard="Standard";
var re_SSL_txt_secured="S�curis�";
var re_SSL_txt_userpref_WngMsg="Voulez-vous que {0} devienne le mode par d�faut?";

//non-macchiato
var re_fpv_txt_switch="Commutateur";
var re_fpv_txt_rps="RPS";
var re_fpv_txt_stack="Pile";
var re_fpv_txt_iobay="Baie d'entr�e-sortie";
var re_fpv_txt_member="Membre";
var re_fpv_txt_master="Principal";
var re_fpv_Tltp_inline="Alimentation �lectrique par c�ble Ethernet";
var re_Ttl_txt_esm="Gestionnaire de p�riph�rique du module de service EtherSwitch";
var re_Ttl_txt_cbs3030="Gestionnaire de p�riph�rique 3030 de commutateur � lame Catalyst";
var re_Ttl_txt_cbs3020="Gestionnaire de p�riph�rique 3020 de commutateur � lame Catalyst";

//Newly added Strings
var re_Ttl_txt_esm_2="Modue de service EtherSwitch";
var re_Ttl_txt_cbs3030_2="Commutateur � lame Catalyst 3030";
var re_Ttl_txt_cbs3020_2="Commutateur � lame Catalyst 3020";
var re_Ttl_txt_catalyst="Catalyst";
var re_Ttl_txt_softrecover="R�tablissement du logiciel";
var re_Ttl_txt_catseries1="Gamme ITP {0}";
var re_Ttl_txt_catseries="Gamme Catalyst {0}";
var re_Ttl_txt_exsetup="Configurateur express";

//additional strings - 03/06/06
var re_fpv_Tltp_different_mode  ="Cliquez sur ce bouton pour s�lectionner un Mode diff�rent";
var re_fpv_txt_Lanugage  ="Langue";

//Newly added strings (for Falchion)
var re_Ttl_txt_cbs3040="Catalyst Blade Switch 3040";

//Strings added for pixar SKUs
var re_fpv_Tltp_fru = "FRU";
var re_fpv_Tltp_pid = "PID";
var re_fpv_Tltp_fru_information = "FRU Information";
var re_fpv_Tltp_System_Power = "System Power";
var re_fpv_Tltp_PoE_Power = "PoE Power";
var re_fpv_Tltp_Sidinfo = "SID Information";
var re_fpv_Tltp_type = "Type";
var re_fpv_Tltp_System_Power = "System Power";
var re_fpv_Tltp_PoE_Power = "PoE Power";
var re_fpv_Tltp_serial = "Serial Number";
var re_fpv_Tltp_Port = "Port";
var re_fpv_Tltp_IPAddress = "IP Address";
var re_fpv_Tltp_Status = "Status";
var re_fpv_Tltp_EtherManagePort = "Ethernet Management Port";

//For Stout 11/11/09
var re_fpv_Tltp_IPAddress = "Adresse IP";
var re_fpv_Tltp_Status = "�tat";
var re_fpv_Tltp_EtherManagePort = "Port de gestion Ethernet";

