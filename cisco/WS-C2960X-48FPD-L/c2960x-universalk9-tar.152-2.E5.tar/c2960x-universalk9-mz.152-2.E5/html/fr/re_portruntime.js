/*
 *------------------------------------------------------------------
 * Resource file for port status
 * Copyright (c) 2006 by cisco Systems, Inc.
 *------------------------------------------------------------------
*/

//Title
var re_pStatus_ScrTtl="�tat des ports";

//Table headers
var re_pStatus_TblHeader1="Port";
var re_pStatus_TblHeader2="Description";
var re_pStatus_TblHeader3="�tat";
var re_pStatus_TblHeader4="VLAN";
var re_pStatus_TblHeader5="Vitesse";
var re_pStatus_TblHeader6="Duplex";
var re_pStatus_TblHeader7="PoE";
var re_pStatus_TblHeader8="Auto-MDIX";
var re_pStatus_TblHeader9="Alimentation �lectrique par c�ble Ethernet";

//Alert messages
var re_pStatus_ErrMsg1="ERREUR : le port est nul";
var re_pStatus_ErrMsg2="Port {0} introuvable";
