/*
 *------------------------------------------------------------------
 * dashboard resource file
 * Copyright (c) 2006, 2009 by cisco Systems, Inc.
 * feature code - dshBrd
 *------------------------------------------------------------------
*/

//macchiato
var re_dshBrd_Ttl="Tableau de bord";

var re_dshBrd_LblHostName="Nom d'h�te";
var re_dshBrd_LblProductID="ID du produit";
var re_dshBrd_LblIPAddress="Adresse IP";
var re_dshBrd_LblMacAddress="Adresse MAC";
var re_dshBrd_LblVersionID="ID Version";
var re_dshBrd_LblSNum="Num�ro de s�rie";
var re_dshBrd_LblSoftware="Logiciel";
var re_dshBrd_LblContact="Personne-ressource";
var re_dshBrd_LblLocation="Emplacement";
var re_dshBrd_LbBwUsed="Bande passante utilis�e";

var re_dshBrd_LblPktError="Erreur de paquet";
var re_dshBrd_LblPwrUtil="Utilisation PoE";
var re_dshBrd_LblFan="Ventilateur";
var re_dshBrd_LblTemp="Temp.";

var re_dshBrd_Txt1="OK";
var re_dshBrd_Txt6="D�fectueux";

var re_dshBrd_TltpBwUsed="Bande passante utilis�e";
var re_dshBrd_TltpPktError="Erreur de paquet";
var re_dshBrd_TltpPwrUsed="Alimentation utilis�e";
var re_dshBrd_TltpPwrRemain="Alimentation restante";
var re_dshBrd_TltpFanOk="Le VENTILATEUR est OK";
var re_dshBrd_TltpFanFaulty="Le VENTILATEUR est D�FECTUEUX";
var re_dshBrd_TltpTempOk="Temp�rature est OK";
var re_dshBrd_TltpTempFaulty="Temp�rature est D�FECTUEUSE";

var re_dshBrd_Grp1Ttl="Renseignments du commutateur";
var re_dshBrd_Grp1Tt2="�tat de sant� du commutateur";
var re_dshBrd_Grp1Tt3Mach="Utilisation/Erreurs des ports";

var re_dshBrd_Link1="Afficher les tendances";
var re_dshBrd_Link2="Afficher les statistiques du port";

var re_dshBrd_Radio1="Utilisation des ports";
var re_dshBrd_Radio2="Erreurs des ports";

var re_dshBrd_ErrMsg1="L'environnement WIMP de bande passante n'est pas support�. Veuillez mettre � jour pour une image IOS le supportant";

var re_dshBrd_GraphLegendTxt1="Recevoir";
var re_dshBrd_GraphLegendTxt2="Transmettre";
var re_dshBrd_GraphXAxis="Ports";

//non-macchiato
var re_dshBrd_LblType="Type";
var re_dshBrd_Grp1Tt3="Utilisation du port";
var re_dshBrd_LblStackBwUsed="Empiler la bande passante utilis�e";
var re_dshBrd_LblStackPktError="Erreur de paquet d'empilage";

var re_dshBrd_Txt2="Le VENTILATEUR 1 est OK";
var re_dshBrd_Txt3="Le VENTILATEUR 1 est D�FECTUEUX";
var re_dshBrd_Txt4="Le VENTILATEUR 2 est OK";
var re_dshBrd_Txt5="Le VENTILATEUR 2 est D�FECTUEUX";
var re_dshBrd_LblInlinePwrUtil="Utilisation de l'alimentation �lectrique par c�ble Ethernet";

//new strings
var re_dshBrd_Grp1Tt4="Renseignements du contr�leur";

//additional strings - 03/06/06
var re_dshBrd_TxtIPDHCP  ="N�goci� avec DHCP";
var re_dshBrd_TltpFan1Ok  ="Le VENTILATEUR 1 est OK";
var re_dshBrd_TltpFan1Faulty  ="Le VENTILATEUR 1 est D�FECTUEUX";
var re_dshBrd_TltpFan2Ok  ="Le VENTILATEUR 2 est OK";
var re_dshBrd_TltpFan2Faulty  ="Le VENTILATEUR 2 est D�FECTUEUX";
var re_dshBrd_TltpTemperatureOk  ="La temp�rature est OK";
var re_dshBrd_TltpTemperatureFaulty  ="La temp�rature est D�fectueuse";
var re_dshBrd_TltpPort  ="Port";
var re_dshBrd_TltpUtilization  ="Utilisation";

var re_dshBrd_TxtWarning = "Avertissement";

//For Stout 11/11/09
var re_dshBrd_LblEthMgmtPortIP = "Adresse IP du port{0}de gestion Ethernet";
