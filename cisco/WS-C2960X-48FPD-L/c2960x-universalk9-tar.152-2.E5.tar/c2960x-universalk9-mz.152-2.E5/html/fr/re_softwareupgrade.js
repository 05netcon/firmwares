/*
 *------------------------------------------------------------------
 * software upgrade resource file
 * Copyright (c) 2006 by cisco Systems, Inc.
 * feature code - swUpg
 *------------------------------------------------------------------
*/

//macchiato

var re_swUpg_Ttl="Mise � jour du logiciel";
var re_swUpg_Btn1="Mise � jour";

var re_swUpg_Txt1="Le commutateur utilise la version du logiciel IOS de Cisco";
var re_swUpg_Txt2="Allez sur {0} pour trouver les derni�res versions logicielles de Cisco IOS (en format tar) pour ce commutateur.";
var re_swUpg_Txt3="T�l�chargez le fichier tar sur votre PC ou sur un lecteur r�seau.";
var re_swUpg_Txt4="S�lectionnez un fichier tar � mettre � jour en utilisant le bouton Parcourir�";
var re_swUpg_Txt5="Cliquez sur Mise � jour.";

var re_swUpg_FileBrowse="Nom du fichier image";

var re_swUpg_Grp1Ttl="�tat";
var re_swUpg_TblHeader1Mach="Stade";
var re_swUpg_TblHeader2Mach="Taille du fichier";

var re_swUpg_ConfMsg1="Avertissement :\n\nVous �tes sur le point de mettre � jour le logiciel du commutateur. Ne pas utiliser ou fermer cette\session de navigateur avant la fin du processus de mise � jour. A la fin\du processus de mise � jour, fermez cette session de navigateur et affichez le\n Gestionnaire de p�riph�rique � partir d'une nouvelle session de navigateur.\n\nCliquez sur OK pour continuer le processus de mise � jour, ou sur Annuler pour interrompre \nle processus de mise � jour.";

var re_swUpg_ErrMsg1="Erreur :\n\Cliquez sur Parcourir pour atteindre le fichier image du commutateur (fichier tar) sur votre PC.";
var re_swUpg_ErrMsg2="Erreur : La mise � jour du logiciel de commutation est en cours dans une autre session";
var re_swUpg_ErrMsg3="La mise � jour du logiciel est en cours!";

var re_swUpg_Txt_Stage1Mach="Chargement du fichier tar vers le commutateur";
var re_swUpg_Txt_Stage2Mach="Fichier tar charg�";
var re_swUpg_Txt_Stage3Mach="Rechargement en attente";
var re_swUpg_Txt_Stage4Mach="�chec de la mise � jour";

var re_swUpg_Txt_ImageInstalled="La nouvelle image de logiciel est install�e. Rechargement du p�riph�rique.{0}Veuillez attendre! Ce processus peut prendre jusqu'� 5 minutes jusqu'au r�tablissement de la connexion.";
var re_swUpg_Txt_UpgInComplete="Le commutateur n'est pas encore recharg�, le gestionnaire de p�riph�rique attend la r�ponse du p�riph�rique.";
var re_swUpg_Txt_UpgComplete="Le logiciel du commutateur est � jour. Pour utiliser la plus r�cente version du logiciel, terminez votre session de gestionnaire de p�riph�rique actuelle et relancez une nouvelle session de gestionnaire de p�riph�rique.";
var re_swUpg_Txt_ArchiveStatusMsg="Le logiciel a �t� mis � jour avec succ�s. Pour utiliser le logiciel le plus r�cent, terminez votre session de gestionnaire de p�riph�rique actuelle et relancez une nouvelle session de gestionnaire de p�riph�rique.";

var re_swUpg_ErrMsg4="Erreur : La mise � jour pr�c�dente a �chou� ou a �t� interrompue. Le nettoyage n'est pas effectu�.";
var re_swUpg_ErrMsg5="Erreur : Il n'y a pas assez de m�moire dans le commutateur pour installer la nouvelle image de logiciel.";
var re_swUpg_ErrMsg6="Erreur : Le fichier n'est pas un fichier tar Cisco IOS valide.";
var re_swUpg_ErrMsg7="Erreur : Le fichier image n'est pas compatible avec ce commutateur.";
var re_swUpg_ErrMsg8="Erreur : Le fichier image est corrompu. T�l�chargez de nouveau le fichier image � partir de Cisco.com.";
var re_swUpg_ErrMsg9="Erreur : Il n'y a pas assez de m�moire dans le commutateur pour examiner la nouvelle image logicielle.";
var re_swUpg_ErrMsg10="Erreur : Le fichier n'existe pas.";
var re_swUpg_ErrMsg11="Erreur : Impossible d'extraire l'image.";
var re_swUpg_ErrMsg12="Erreur : Ind�finie";


//non-macchiato
var re_swUpg_TblHeader1="Stade";
var re_swUpg_TblHeader2="�tat";

var re_swUpg_Txt_Stage1="1. Chargement du fichier tar vers le commutateur";
var re_swUpg_Txt_Stage2="2. V�rification du fichier tar";
var re_swUpg_Txt_Stage3="3. Extraction des fichiers � partir du fichier tar.";
var re_swUpg_Txt_Stage4="4. Red�marrage du commutateur.";

var re_swUpg_Txt_RestartSwitch="Veuillez attendre! Ce processus peut prendre jusqu'� 5 minutes jusqu'au r�tablissement de la connexion.";

//additional strings - 03/06/06
var re_swUpg_TltpInProgress  ="En cours";
var re_swUpg_TltpCompleted  ="Compl�t�";
var re_swUpg_TltpFailed  ="�chou�";
var re_swUpg_Txt_Stage5Mach  ="T�l�chargement de l'image termin�";
var re_swUpg_Txt_noUpgradeinProgress="Aucune mise � jour de logiciel en cours.";
var re_swUpg_Txt_UpgradeInAnotherSession="La mise � jour du logiciel est d�j� en cours dans une autre session!";

//new strings - 03/28/06
var re_swUpg_ErrMsg13 ="Erreur : Il est impossible d'installer Cisco IOS 12.2(25)FY sur ce commutateur. Mettez le commutateur � jour � la version Cisco IOS 12.2(25)SEG ou � une version ult�rieure.";
var re_swUpg_ErrMsg14 ="Erreur : Il n'y a pas assez de m�moire sur le commutateur pour installer la nouvelle image de logiciel. L'image de logiciel actuelle a �t� enlev�e. Le commutateur recharge maintenant l'image de logiciel des r�glages d'usine par d�faut.";
var re_swUpg_Txt_UcodeBoot ="Le commutateur a recharg� l'image du logiciel des r�glages d'usine par d�faut. Terminez votre session actuelle sur le gestionnaire de p�riph�riques et d�butez une nouvelle session de gestionnaire de p�riph�riques.";

var re_swUpg_ErrMsg15 ="Erreur : Il est impossible d'installer Cisco IOS 12.2(25)FY sur ce commutateur. Mettez le commutateur � jour � la version Cisco IOS 12.2(25)SEG ou � une version ult�rieure. L'image de logiciel actuelle a �t� enlev�e. Le commutateur recharge maintenant l'image de logiciel des r�glages d'usine par d�faut.";
