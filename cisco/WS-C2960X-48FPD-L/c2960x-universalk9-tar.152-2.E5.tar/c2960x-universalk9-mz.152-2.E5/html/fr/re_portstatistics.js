/*
 *------------------------------------------------------------------
 * Resource file for port statistics
 * Copyright (c) 2006 by cisco Systems, Inc.
 *------------------------------------------------------------------
*/

//Title
var re_pStats_ScrTtl="Statistiques des ports";

//Tabs
var re_pStats_tab_Lbl1="Vue d'ensemble";
var re_pStats_tab_Lbl2="D�tails transmission";
var re_pStats_tab_Lbl3="D�tails r�ception";

//Table Headers
var re_pStats_Tblheader1="Port";
var re_pStats_Tblheader2="Transmis{0}(octets)";
var re_pStats_Tblheader3="Transmis au{0}total (pqts)";
var re_pStats_Tblheader4="Re�us{0}(octets)";
var re_pStats_Tblheader5="Re�us au{0}total (pqts)";
var re_pStats_Tblheader6="Total erreurs{0}transmission (pqts)";
var re_pStats_Tblheader7="Total erreurs{0}r�ception (pqts)";
var re_pStats_Tblheader8="Unicast{0} (pqts)";
var re_pStats_Tblheader9="Multicast{0} (pqts)";
var re_pStats_Tblheader10="Broadcast{0} (pqts)";
var re_pStats_Tblheader11="Total collisions{0}(pqts)";
var re_pStats_Tblheader12="Collisions excessives{0} (pqts)";
var re_pStats_Tblheader13="Collisions tardives{0} (pqts)";
var re_pStats_Tblheader14="Erreurs{0} FCS (pqts)";
var re_pStats_Tblheader15="Erreurs{0}alignement (pqts)";
var re_pStats_Tblheader16="Surdimensionn�{0} (pqts)";
var re_pStats_Tblheader17="Sousdimensionn�{0} (pqts)";
var re_pStats_Tblheader18="Fragments de collision{0}";

//Warning messages
var re_pStats_WngMsg="S�lectionnez une ligne et cliquez ensuite sur 'Effacer les compteurs' pour effacer les statistiques de la ligne s�lectionn�e.";

//Button labels
var re_pStats_clr_btn="Effacer les compteurs";
