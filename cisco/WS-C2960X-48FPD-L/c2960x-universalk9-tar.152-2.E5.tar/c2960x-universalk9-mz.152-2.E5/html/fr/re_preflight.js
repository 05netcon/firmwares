/*
 *------------------------------------------------------------------
 * preflight resource file
 * Copyright (c) 2006 by cisco Systems, Inc.
 *------------------------------------------------------------------
*/

var re_preFlt_Ttl1="D�pannage : syst�me d'exploitation support�";
var re_preFlt_Ttl2="D�pannage : navigateur internet support�";
var re_preFlt_Ttl3="D�pannage : navigateur internet";
var re_preFlt_Ttl4="D�pannage : JavaScript";
var re_preFlt_txt1="Syst�me d'exploitation";
var re_preFlt_txt2="Le syst�me d'exploitation (version, type OS) n'est pas support�.";
var re_preFlt_txt3="Ces syst�mes d'exploitation sont support�s :";
var re_preFlt_txt4="Windows XP, 2000";
var re_preFlt_txt5="Cliquez {ici} pour retourner au Rapport de d�marrage.";
var re_preFlt_txt6="JavaScript n'est pas activ�. JavaScript doit �tre activ� avant le d�marrage du Gestionnaire de p�riph�rique.";
var re_preFlt_txt7="Activation de JavaScript dans Netscape";
var re_preFlt_txt8="S�lectionnez {�dition > Pr�f�rences} pour ouvrir la fen�tre Pr�f�rences.";
var re_preFlt_txt9="Cliquez sur {Avanc�} sous Cat�gorie pour afficher les pr�f�rences Avanc�es.";
var re_preFlt_txt10="Dans la zone Avanc�, cochez {Activer JavaScript} et cliquez ensuite sur OK.";
var re_preFlt_txt11="Cliquez {ici} pour retourner";
var re_preFlt_txt12="Activation de JavaScript dans Internet Explorer";
var re_preFlt_txt13="S�lectionnez {Outils > Options Internet}.";
var re_preFlt_txt14="Cliquez sur l'onglet {S�curit�}.";
var re_preFlt_txt15="Cliquez sur {Niveau personnalis�}. La fen�tre Param�tres de s�curit� s'ouvre.";
var re_preFlt_txt16="D�filez vers le bas jusqu'� Script et cliquez sur {Activer} sous Script actif.";
var re_preFlt_txt17="Cliquez sur {OK} et cliquez ensuite sur {Oui} dans la bo�te de dialogue Avertissement.";
var re_preFlt_txt18="Cliquez sur {OK} pour fermer la fen�tre d'Options Internet.";
var re_preFlt_txt20="Navigateur Internet";
var re_preFlt_txt21="Le navigateur Internet {(0)} n'est pas support�.";
var re_preFlt_txt22="Ces navigateurs Internet sont support�s :";
var re_preFlt_txt23="Internet Explorer 5.5 et 6.0";
var re_preFlt_txt24="Netscape 7.1";
var re_preFlt_txt25="JavaScript";
var re_preFlt_txt26="JavaScript n'a pas �t� activ�.";
var re_preFlt_txt27="Le gestionnaire de p�riph�rique ne sera pas lanc� tant que JavaScript sera activ�.";
var re_preFlt_txt28="Cliquez {ici} pour plus d'informations.";
var re_preFlt_txt29="L'�tat du navigateur Internet {(0)} est inconnu.";
var re_preFlt_txt30="Syst�me d'exploitation";
var re_preFlt_txt31="L'�tat du syst�me d'exploitation est inconnu.";
var re_preFlt_txt32="Rapport de configuration";
var re_preFlt_txt33="Rapport de d�marrage";
var re_preFlt_txt34="Le gestionnaire de p�riph�rique ne fonctionnera pas avec le navigateur Internet {0}";
var re_preFlt_txt35="Veuillez mettre votre navigateur � jour.";
var re_preFlt_txt36="Le gestionnaire de p�riph�rique ne supporte pas le navigateur Internet";
var re_preFlt_txt37="Cliquez sur Continuer pour effectuer le lancement avec le navigateur non support� :";
var re_preFlt_txt38="Cliquez {ici} pour plus d'informations.";
var re_preFlt_txt39="Le navigateur Internet est support�.";
var re_preFlt_txt40="Le gestionnaire de p�riph�rique ne supporte pas le syst�me d'exploitation {0}.";
var re_preFlt_txt41="Cliquez sur Continuer pour effectuer le lancement avec le syst�me non support� :";
var re_preFlt_txt42="Le syst�me d'exploitation est support�.";
var re_preFlt_txt43="Consultation et mise � jour";
var re_preFlt_txt44="Le gestionnaire de p�riph�rique ne supporte pas l'acc�s en lecture seule pour ce commutateur.";
var re_preFlt_txt45="Remarque : Le gestionnaire de p�riph�rique est acc�d� en mode lecture-�criture.";
var re_preFlt_txt46="�tape 1";
var re_preFlt_txt47="�tape 2";
var re_preFlt_txt48="�tape 3";
var re_preFlt_txt49="�tape 4";
var re_preFlt_txt50="�tape 5";
var re_preFlt_txt51="�tape 6";
var re_preFlt_txt52="�tape 7";

//Newly added Strings
var re_preFlt_txt53="JavaScript a �t� activ�.";
var re_preFlt_txt54="Le mode d'acc�s lecture-�criture est inconnu.";
var re_preFlt_txt55="Tous droits r�serv�s � 2004-2006 par Cisco Systems, Inc.";
var re_preFlt_txt56="Continuer";
