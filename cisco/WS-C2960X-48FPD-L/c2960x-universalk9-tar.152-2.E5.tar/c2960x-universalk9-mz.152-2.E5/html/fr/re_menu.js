/*
 *------------------------------------------------------------------
 * menu resource file
 * Copyright (c) 2006 by cisco Systems, Inc.
 *------------------------------------------------------------------
*/

var re_menu_txt_contents="Contenu";
var re_menu_txt_dashboard="Tableau de bord";
var re_menu_txt_configure="Configurer";
var re_menu_txt_smartports="Smartports";
var re_menu_txt_portset="Param�trage des ports";
var re_menu_txt_exsetup="Configurateur express";
var re_menu_txt_vlans="VLANs";
var re_menu_txt_snmp="SNMP";
var re_menu_txt_ethchan="EtherChannels";
var re_menu_txt_userpass="Utilisateurs et mots de passe";
var re_menu_txt_restartreload="Red�marrer / R�initialiser";
var re_menu_txt_monitor="Superviser";
var re_menu_txt_trends="Tendances";
var re_menu_txt_portstatus="�tat des ports";
var re_menu_txt_portstatistics="Statistiques des ports";
var re_menu_txt_alertlog="Journal d'alertes";
var re_menu_txt_diag="Diagnostics";
var re_menu_txt_softupgrade="Mise � jour du logiciel";
var re_menu_txt_netassist="Network Assistant";
var re_menu_txt_maintenance="Entretien";
var re_menu_txt_intro="Introduction";
var re_menu_txt_legend="L�gende";
var re_menu_txt_support="Soutien";
var re_menu_txt_telnet="Telnet";

//new strings
var re_menu_txt_controllerDM="Gestionnaire de p�riph�rique du contr�leur";
