/*
 *------------------------------------------------------------------
 * express setup resource file - includes express setup (incl. smartports info page), managed and recovery mode pages
 * Copyright (c) 2006-2010 by cisco Systems, Inc.
 * feature code - xSetup
 *------------------------------------------------------------------
*/

//macchiato
var re_xSetup_Ttl="Configurateur express";

var re_xSetup_LblMgmtIntMach="Interface de gestion (VLAN)";
var re_xSetup_LblIPMode="Mode d'attribution IP";
var re_xSetup_LblIPModeStatic="Statique";
var re_xSetup_LblIPModeDHCP="DHCP";
var re_xSetup_LblIPAddress="Adresse IP";
var re_xSetup_LblSubnet="Masque de sous-r�seau";
var re_xSetup_LblDefGateway="Passerelle par d�faut";
var re_xSetup_LblUsrName="Nom d'utilisateur";
var re_xSetup_LblPwd="Mot de passe";
var re_xSetup_LblConfPwd="Confirmer le mot de passe";
var re_xSetup_LblHostName="Nom d'h�te";
var re_xSetup_LblSysDate="Date du syst�me {(JJ/MMM/AAAA)}";
var re_xSetup_LblSysTime="Heure du syst�me {(HH:MM)}";
var re_xSetup_LblTimeZone="Fuseau horaire";
var re_xSetup_LblDST="Heure avanc�e";
var re_xSetup_LblEnable="Activer";

var re_xSetup_Grp1Ttl="Param�tres du r�seau";
var re_xSetup_Grp1Tt2="Param�tres optionnels";

var re_xSetup_Txt2="Le serveur DHCP ren�gociera l'adresse IP du commutateur. Utilisez la nouvelle adresse pour lancer le gestionnaire de p�riph�rique.";

var re_xSetup_ErrMsg1="Erreur : \n\nEntrez une ID VLAN entre 1 et 1001.";
var re_xSetup_ErrMsg2="Erreur : \n\nEntrez une adresse IP pour le commutateur.";
var re_xSetup_ErrMsg4="Erreur : \n\nL'adresse IP pour le commutateur et la passerelle par d�faut doit appartenir au m�me sous-r�seau.";
var re_xSetup_ErrMsg9="Erreur : \n\nLe nom d'h�te ne peut pas contenir un ?, un espace ou une tabulation.";
var re_xSetup_ErrMsg18="Erreur : \n\nL'adresse IP�pour le commutateur et la passerelle par d�faut ne peut pas �tre la m�me.";
var re_xSetup_ErrMsg21="Erreur : \n\n\'{0)\' n'est pas une adresse IP valide. Entrez une adresse IP suivant le format x.x.x.x, dans lequel x peut �tre un chiffre entre 0 et 255.";
var re_xSetup_ErrMsg22="Erreur : \n\n{0} n'est pas une adresse IP valide.";
var re_xSetup_ErrMsg23="Erreur : \n\n\'{0}\' n'est pas une adresse IP valide pour la passerelle par d�faut.\nEntrez l'adresse IP suivant le format x.x.x.x, dans lequel x peut un chiffre entre 0 et 255.";
var re_xSetup_ErrMsg25="Erreur : \n\Entrez un num�ro de 0 � {0} dans ce champ.";
var re_xSetup_ErrMsg26="Erreur : \n\n\'{0}\' n'est pas une adresse IP valide pour la passerelle par d�faut.";

var re_xSetup_ConfMsg2="Avertissement : \n\n L'adresse IP de ce p�riph�rique sera modifi�e. Le Configurateur Express tentera\nde la connexion � ce p�riph�rique en utilisant cette nouvelle adresse IP {0}.\nSi votre adresse IP de PC n'est pas dans le m�me sous-r�seau que cette nouvelle adresse IP,\nla connexion avec ce p�riph�rique sera termin�e. Selectionnez OK pour continuer et associer la nouvelle adresse IP. Cliquez sur Annuler pour ne pas appliquer la nouvelle adresse IP.";
var re_xSetup_ConfMsg3="Avertissement : \n\nLa passerelle par d�faut n'a pas d'adresse IP. Voulez-vous continuer?";
var re_xSetup_ConfMsg6="Avertissement : \n\nL'interface de gestion {0} sera configur�e avec cette\nadresse IP {1}.\n\nVoulez-vous continuer?";
var re_xSetup_ConfMsg7="Avertissement : \n\nL'interface de gestion {0} sera configur�e avec cette\nadresse IP {1}.\n\nPour communiquer avec le commutateur, au moins un port de commutation doit\n�tre affect� au nouveau VLAN de gestion.\n\nVoulez-vous continuer?";

var re_xSetup_ConfMsg8="Avertissement : \n\nL'interface de gestion {0} sera configur�e avec\nl'adresse IP assign�e par le serveur DHCP.\n\nVoulez-vous continuer?";
var re_xSetup_ConfMsg9="Avertissement : \n\nL'interface de gestion {0} sera configur�e avec\nl'adresse IP assign�e par le serveur DHCP.\n\nPour communiquer avec le commutateur, au moins un port de commutation doit\n �tre affect� au nouveau VLAN de gestion.\n\nVoulez-vous continuer?";
var re_xSetup_ConfMsg10="Information : \n\nLe serveur DHCP ren�gociera l'adresse IP du commutateur. En cons�quence, \nl'adresse IP pourrait changer. Si l'adresse IP change, vous devez\nutiliser la nouvelle adresse pour lancer le gestionnaire de p�riph�rique.\n\nVoulez-vous continuer?";

//express setup mode info page
var re_xSetup_InfoTxt1="La configuration initiale du commutateur est termin�e.";
var re_xSetup_InfoTxt2="Avant de connecter des p�riph�riques, vous pouvez optimiser la performance en affectant des profils de ports Smartports aux ports de commutation. Les profils de ports fournissent s�curit�, fiabilit� et performance en activant les fonctions de port bas�es sur le p�riph�rique auquel le port se connecte. Vous pouvez affecter des profils de port un � la fois ou activer une configuration standard de Smartports. Pour ce commutateur, une configuration de Smartports affecterait les profils de ports suivants :";
var re_xSetup_InfoTxt3="Vous pouvez aussi affecter des profils de ports � des routeurs, t�l�phones IP et autres p�riph�riques.";
var re_xSetup_InfoTxt4="Ports 1 � 24 - Bureaux et ordinateurs";
var re_xSetup_InfoTxt5="Ports 1 et 2 haute vitesse -Commutateurs Ethernet";
var re_xSetup_InfoTxt6="Ports 1 � 24 - T�l�phones IP";
var re_xSetup_InfoTxt7="Ports 1 et 2 haute vitesse -Commutateurs Ethernet";
var re_xSetup_InfoTxt8="Ports 1 � 4 - Points d'acc�s";
var re_xSetup_InfoTxt9="Ports 5 � 24 - Bureaux et ordinateurs";
var re_xSetup_InfoTxt10="Ports 1 et 2 haute vitesse -Commutateurs Ethernet";
var re_xSetup_InfoTxt11="Ports 1 � 8 haute vitesse - Serveurs";
var re_xSetup_InfoTxt12="Ports 9 � 12 haute vitesse - Commutateurs Ethernet";

var re_xSetup_InfoChkBox1="Oui, activer les profils de port et afficher la bo�te de dialogue Smartports";
var re_xSetup_InfoChkBox2="Non merci";

var re_xSetup_InfoErrMsg1="Vous avez cliqu� sur Soumettre sans s�lectionner une option";
var re_xSetup_InfoPageTtl="Information Smartports";

//recovery mode page
var re_xSetup_RecTtl="R�tablissement du logiciel";
var re_xSetup_RecRadio1="Effacer la configuration du syst�me.";
var re_xSetup_RecRadio2="D�marrer avec l'image IOS des r�glages d'usine par d�faut .";
var re_xSetup_RecRadio3="Effacer la configuration du syst�me et D�marrer avec l'image IOS des r�glages d'usine par d�faut.";

var re_xSetup_RecConfMsg1="Ceci supprimera tous les param�tres personnalis�s du commutateur y compris l'adresse IP, mais red�marrera en utilisant la version existante du logiciel. Selectionnez OK pour continuer.";
var re_xSetup_RecConfMsg2="Ceci conservera tous les param�tres personnalis�s (y compris l'adresse IP) et red�marrera le commutateur suivant la configuration d'usine par d�faut. Cliquez sur OK pour continuer.";
var re_xSetup_RecConfMsg3="Ceci supprimera tous les param�tres personnalis�s du commutateur (y compris l'adresse IP) et red�marrera suivant la configuration d'usine par d�faut. Cliquez sur OK pour continuer.";
var re_xSetup_RecConfMsgTtl="Avertissement";

var re_xSetup_RecTxt1="Le commutateur va �tre red�marr�. Utilisez le Configurateur Express pour attribuer une adresse IP au commutateur. Consultez le guide 'Pour commencer' pour plus d'information sur les proc�dures. ";
var re_xSetup_RecTxt2="Le commutateur va �tre red�marr�. Entrez l'adresse IP du commutateur dans la fen�tre de votre navigateur internet pour afficher le gestionnaire de p�riph�rique.";

//non-macchiato
var re_xSetup_LblMgmtInt="Interface de gestion (ID VLAN)";
var re_xSetup_LblSwPwd="Mot de passe du commutateur";
var re_xSetup_LblConfirmSwPwd="Confirmer le mot de passe du commutateur";
var re_xSetup_LblTelnet="Acc�s Telnet";
var re_xSetup_LblTelnetPwd="Mot de passe Telnet";
var re_xSetup_LblConfTelnetPwd="Confirmer le mot de passe Telnet";
var re_xSetup_LblSnmp="SNMP";
var re_xSetup_LblSnmpRead="Communaut� de lecture SNMP";
var re_xSetup_LblSnmpWrite="Communaut� d'�criture SNMP";
var re_xSetup_LblSysContact="Personne-ressource du syst�me";//"Personne-ressource du systeme";
var re_xSetup_LblSysLocation="Emplacement du syst�me";
var re_xSetup_LblDisable="D�sactiver";

var re_xSetup_Txt1="Redirection vers la nouvelle adresse IP�";

var re_xSetup_ErrMsg3="Erreur :\n\nLes adresses IP 10.0.0.1 et 10.0.0.3 ne peuvent �tre utilis�es en mode Configurateur Express.";
var re_xSetup_ErrMsg5="Erreur :\n\nLe mot de passe du commutateur ne peut contenir des espaces au d�but ou � la fin.";
var re_xSetup_ErrMsg6="Erreur :\n\nLe mot de passe Telnet ne peut contenir d'espaces au d�but ou � la fin.";
var re_xSetup_ErrMsg7="Erreur :\n\nLe mot de passe du commutateur peut commencer avec un chiffre, est sensible aux majuscules et minuscules,\n et permet des espaces intercal�s. Il ne peut contenir un ? ou une tabulation.";
var re_xSetup_ErrMsg8="Erreur :\n\n Entrez le m�me mot de passe dans les champs Mot de passe du commutateur et Confirmer le mot de passe du commutateur.";
var re_xSetup_ErrMsg10="Erreur :\n\nLe nom de contact du syst�me ne peut contenir un ? ou une tabulation.";
var re_xSetup_ErrMsg11="Erreur :\n\nL'emplacement du syst�me ne peut contenir un ? ou une tabulation.";
var re_xSetup_ErrMsg12="Erreur :\n\nVous devez entrer un mot de passe Telnet si vous activez l'acc�s Telnet. Le mot de passe Telnet\ne peut contenir un ? ou une tabulation.";
var re_xSetup_ErrMsg13="Erreur :\n\nLe mot de passe Telnet peut commencer avec un chiffre, est sensible aux majuscules et minuscules, et\n permet les espaces intercal�s. Il ne peut contenir un ? ou une tabulation.";
var re_xSetup_ErrMsg14="Erreur :\n\nEntrez le m�me mot de passe dans les champs Mot de passe Telnet et Confirmer le mot de passe Telnet.";
var re_xSetup_ErrMsg15="Erreur :\n\nVous devez enter une cha�ne de communaut� dans au moins un des champs de la communaut� SNMP si vous activez SNMP.";
var re_xSetup_ErrMsg16="Erreur :\n\nEntrez une cha�ne de communaut� SNMP qui ne contient pas de ?, d'espace ou de tabulation.";
var re_xSetup_ErrMsg17="Erreur :\n\n Les cha�nes de communaut� Lecture et Ecriture SNMP ne peuvent �tre les m�mes.";
var re_xSetup_ErrMsg19="Erreur :\n\nLe mot de passe du commutateur peut contenir jusqu'� 25 caract�res alphanum�riques.";
var re_xSetup_ErrMsg20="Erreur :\n\nLe mot de passe Telnet peut contenir jusqu'� 25 caract�res alphanum�riques.";
var re_xSetup_ErrMsg24="Erreur :\n\n{0} n'est pas une adresse IP valide pour la passerelle par d�faut.";

var re_xSetup_WngMsg1="Avertissement :\n\nVous devez activer l'acc�s Telnet avant de configurer un mot de passe Telnet.";
var re_xSetup_WngMsg2="Avertissement :\n\nVous devez activer SNMP avant de configurer les cha�nes de communaut� lecture-�criture.";
var re_xSetup_WngMsg3="Avertissement :\n\nVous devez activer SNMP avant de configurer le contact/emplacement du syst�me.";

var re_xSetup_ConfMsg1="Avertissement :\n\nL'adresse IP de ce p�riph�rique sera modifi�e.\nVous pourriez perdre la connexion avec le p�riph�rique.\nVoulez-vous continuer?";
var re_xSetup_ConfMsg4="Avertissement :\n\nLe commutateur n'a pas de mot de passe. Voulez-vous continuer?";
var re_xSetup_ConfMsg5="Avertissement :\n\nL'adresse IP {0} entre en conflit avec l'adresse IP d�j�\n configur�e de la ou des interface(s) suivante(s)\n\nInterface \tAdresse IP\tNetmask\n{1}\n L'adresse IP de ou des interface(s) ci-dessus seront enlev�e(s) pour configurer \nl'adresse IP {2} sur l'interface vlan {3}.\n\nVoulez-vous continuer?";

//new strings
var re_xSetup_Grp1Tt3="Les param�tres de contr�leur sans fil";
var re_xSetup_LblCtrllerStackNumber="Nombre{\n}de piles";
var re_xSetup_LblCtrllerVlan="ID VLAN{\n}de gestion";

var re_xSetup_ErrMsg27="Erreur :\n\nEntrez une adresse IP pour le contr�leur.";
var re_xSetup_ErrMsg28="Erreur :\n\nEntrez une passerelle par d�faut pour le contr�leur.";
var re_xSetup_ErrMsg29="Erreur :\n\nL'adresse IP pour le contr�leur et la passerelle par d�faut ne peut pas �tre la m�me.";
var re_xSetup_ErrMsg30="Erreur :\n\nLes adresses IP du contr�leur et de la passerelle par d�faut doivent appartenir au m�me sous-r�seau.";
var re_xSetup_ErrMsg31="Erreur :\n\nEntrez un ID VLAN pour le contr�leur dans la plage de 1 � 1001.";
var re_xSetup_ErrMsg32="Erreur :\n\nEntrez un ID VLAN pour le contr�leur {0} dans la plage de 1 � 1001.";
var re_xSetup_ErrMsg33="Erreur :\n\nEntrez un ID VLAN pour le contr�leur {0} dans la plage de 1 � 1001.";
var re_xSetup_ErrMsg34="Erreur :\n\nEntrez une adresse IP pour le contr�leur {0}.";
//var re_xSetup_ErrMsg35="Erreur :\n\n\'{0}\' est une adresse IP non valide. Entrez une adresse IP au format x.x.x.x o� le x peut se trouver entre 0 et 255.";
var re_xSetup_ErrMsg36="Erreur :\n\n{0} est une adresse IP non valide.";
var re_xSetup_ErrMsg37="Erreur :\n\nEntrez une passerelle par d�faut pour le contr�leur {0}.";
//var re_xSetup_ErrMsg38="Erreur :\n\n\'{0}\' est une adresse IP non valide pour la passerelle par d�faut.\nEntrez une adresse IP au format x.x.x.x o� le x peut se trouver entre 0 et 255.";
var re_xSetup_ErrMsg39="Erreur :\n\nL'adresse IP pour le contr�leur {0} et la passerelle par d�faut ne peut pas �tre la m�me.";
var re_xSetup_ErrMsg40="Erreur :\n\nL'adresse IP du contr�leur {0} et de la passerelle par d�faut doivent appartenir au m�me sous-r�seau.";
//var re_xSetup_ErrMsg41="Erreur :\n\n{0} est une adresse IP de passerelle par d�faut non valide.";

var re_xSetup_ErrMsg42="Erreur :\n\nLes adresses IP dans le r�seau {0} ne peuvent �tre configur�es sur ce commutateur.";
var re_xSetup_ErrMsg43="Erreur :\n\nUn nom d'utilisateur est attribu� au commutateur, mais pas le mot de passe. Entrez un mot de passe.";
var re_xSetup_ErrMsg44="Erreur :\n\nUn mot de passe est attribu� au commutateur, mais pas le nom d'utilisateur. Entrez un nom d'utilisateur.";
var re_xSetup_ErrMsg45="Avertissement :\n\nLe commutateur n'a pas de nom d'utilisateur ni de mot de passe.\nVoulez-vous continuer?";
var re_xSetup_ErrMsg46="Erreur :\n\nLe mot de passe ne peut contenir des espaces au d�but ou � la fin.";
var re_xSetup_ErrMsg47="Erreur :\n\nEntrez un nom d'utilisateur. Le nom peut contenir jusqu'� 64 caract�res alphanum�riques.\nIl ne peut contenir un ? ou une tabulation.";
var re_xSetup_ErrMsg48="Erreur :\n\nLe mot de passe peut commencer par un chiffre, est sensible aux majuscules et minuscules et permet les espaces intercal�s.\nIl ne peut contenir un ? ou une tabulation.";
var re_xSetup_ErrMsg49="Erreur :\n\nEntrez le m�me mot de passe dans les champs Mot de passe et Confirmer le mot de passe.";
var re_xSetup_ErrMsg50="Erreur :\n\nLe mot de passe peut contenir jusqu'� 25 caract�res alphanum�riques.";
var re_xSetup_ErrMsg51="Erreur :\n\nVLAN {0} n'est pas disponible. Entrez une ID VLAN diff�rente.";
var re_xSetup_ErrMsg52="Sera n�goci� par le protocole DHCP";

//additional strings - 03/06/06
var re_xSetup_ErrMsg53  ="Le nom d'utilisateur ne peut contenir des lettres qui ne sont pas en anglais.";
var re_xSetup_ErrMsg54  ="Le mot de passe ne peut contenir des lettres qui ne sont pas en anglais.";
var re_xSetup_ErrMsg55  ="Le nom d'h�te ne peut contenir des lettres qui ne sont pas en anglais.";
var re_xSetup_ErrMsg56  ="Le mot de passe Telnet ne peut contenir des lettres qui ne sont pas en anglais.";
var re_xSetup_ErrMsg57  ="La cha�ne de communaut� SNMP ne peut contenir des lettres qui ne sont pas en anglais.";
var re_xSetup_ErrMsg58  ="La personne-ressource du syst�me ne peut contenir des lettres qui ne sont pas en anglais.";
var re_xSetup_ErrMsg59  ="L'emplacement du syst�me ne peut contenir des lettres qui ne sont pas en anglais.";

var re_xSetup_ConfMsg14 = "Avertissement :\n\nAffecter un nouveau mot de passe Telnet modifie l'ouverture de session locale ou TACACS existante. Souhaitez-vous continuer?";

//New error message for hostname and username and password fields. 11/11/09
var re_xSetup_ErrMsg76 = "Erreur�:\n\nsaisissez un nom d'utilisateur. Le nom peut compter jusqu'� 64�caract�res alphanum�riques.\nIl peut uniquement contenir les caract�res A-Z, a-z, 0-9, le trait d'union, le trait de soulignement et le point.";
var re_xSetup_ErrMsg77 = "Erreur�:\n\nle mot de passe peut commencer par un chiffre et est sensible � la casse.\nIl peut uniquement contenir les caract�res A-Z, a-z, 0-9, le trait d'union, le trait de soulignement et le point.";
var re_xSetup_ErrMsg78 = "Erreur�:\n\nle nom d'h�te peut uniquement contenir les caract�res A-Z, a-z, 0-9, le trait d'union, le trait de soulignement et le point.";
var re_xSetup_ErrMsg80 = "Erreur�:\n\n {0} n'est pas un mot de passe valide.";

//for PSIRT
var re_xSetup_ErrMsg85 = "Entrez un nom d'utilisateur. Il peut contenir jusqu'� 64 caract�res alphanum�riques. Le nom ne peut contenir un ?, un espace ou une tabulation.";
var re_xSetup_ErrMsg86 = "Le nom d'utilisateur ne peut pas �tre identique au nom d'utilisateur par d�faut.";
var re_xSetup_ErrMsg87 = "Saisissez le mot de passe du commutateur. Le mot de passe du commutateur peut commencer par un chiffre, est sensible � la casse\net autorise les espaces int�gr�s. Il ne peut contenir ni point d'interrogation, ni tabulation, ni chiffre seul.";
var re_xSetup_ErrMsg88 = "Le mot de passe du commutateur ne peut �tre identique au mot de passe par d�faut.";

//For mtu 11/11/09
var re_xSetup_LblMtu = "MTU";
var re_xSetup_LblMtuJumbo = "MTU jumbo";
var re_xSetup_LblMtuRouting = "MTU routage";
var re_xSetup_ErrMsg89 = "Saisissez une taille valide MTU dans l'intervalle {0} � {1}.";
var re_xSetup_ErrMsg90 = "Saisissez une taille valide MTU jumbo dans l'intervalle {0} � {1}.";
var re_xSetup_ErrMsg91 = "Saisissez une taille valide MTU routage dans l'intervalle {0} � {1}.";
var re_xSetup_ConfMsg16 = "La modification de la taille MTU prendra uniquement effet lors du prochain rechargement. Voulez-vous continuer ?";
var re_xSetup_ConfMsg17 = "La modification de la taille MTU jumbo prendra uniquement effet lors du prochain rechargement. Voulez-vous continuer ?";

var re_xSetup_ReloadWaitMsg = "Veuillez patienter... Le red�marrage du commutateur n'est pas termin�.";
var re_xSetup_ErrMsg67 = "Veuillez patienter... Le commutateur est en cours de red�marrage.";

// For Stout 11/11/09
var re_xSetup_tab_Lbl1 = "Param�tres de base";
var re_xSetup_tab_Lbl2 = "Param�tres avanc�s";
var re_xSetup_Grp1Tt4 = "Param�tres du port de gestion Ethernet";
var re_xSetup_Fa0IPBalloonHelp = "Si votre station de gestion est connect�e via le port de gestion Ethernet (Fa0), saisissez l'adresse IP du port.";
var re_xSetup_Fa0IPBalloonHelp_lightsabre="Adresse IP du port de gestion Ethernet (Fa0).";

var re_xSetup_VlanIPBalloonHelp = "Si votre station de gestion est connect�e � un port r�seau, saisissez une adresse IP pour l�interface de gestion VLAN (ID VLAN {0}).";

//Added during Surge xsetup support 3rd May'10
var re_xSetup_ErrMsg92 = "Error:\n\nEntrez un mot de passe. Le mot de passe du commutateur peut comporter entre 1 et 25 caract�res alphanum�riques, peut commencer par un chiffre, est sensible � la casse et autorise les espaces int�gr�s. Le mot de passe ne peut pas �tre un seul chiffre, ne peut pas contenir un point d'interrogation ou un onglet, et il ne peut pas commencer ou se terminer par un espace. ";
var re_xSetup_ErrMsg93 = "Error:\n\n {0} n'est pas un mot de passe valide. Le mot de passe du commutateur peut comporter entre 1 et 25 caract�res alphanum�riques, peut commencer par un chiffre, est sensible � la casse et autorise les espaces int�gr�s. Le mot de passe ne peut pas �tre un seul chiffre, ne peut pas contenir un point d'interrogation ou un onglet, et il ne peut pas commencer ou se terminer par un espace. ";
