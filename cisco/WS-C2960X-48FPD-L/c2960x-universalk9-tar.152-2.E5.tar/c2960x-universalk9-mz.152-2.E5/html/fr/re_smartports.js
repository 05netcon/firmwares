/*
 *------------------------------------------------------------------
 * smartports resource file
 * Copyright (c) 2006 by cisco Systems, Inc.
 * feature code - sPort
 *------------------------------------------------------------------
*/

//macchiato
var re_sPort_Scr1Ttl="Smartports";
var re_sPort_Scr2Ttl="Smartports : Personnaliser";

var re_sPort_Txt1Mach="S�lectionnez un profil de port";
var re_sPort_Txt2Mach="Cliquez sur un port pour appliquer le profil de port s�lectionn�";
var re_sPort_AllPortsChkBoxMach="Appliquez le profil de port s�lectionn� pour tous les ports.";

var re_sPort_Txt3="Pour obtenir de plus amples renseignements, d�placez le pointeur au-dessus des ports";
var re_sPort_Btn1="Personnaliser...";

var re_sPort_LblPort="Port";
var re_sPort_LblRole="Profil";
var re_sPort_LblNatVlan="VLAN natif";
var re_sPort_LblAccVlan="VLAN d'acc�s";
var re_sPort_LblVoiceVlan="VLAN vocal";
var re_sPort_LblServerType="Genre de serveur";

var re_sPort_ErrMsg8Mach="Les ports {0} ne sont pas connect�s � des p�riph�riques de station de travail et ne peuvent donc pas �tre configur�s avec le profil Desktop.";
var re_sPort_ErrMsg9="Vous devez d'abord s�lectionner un profil de port � partir du menu d�roulant S�lectionner un profil de port.";
var re_sPort_ErrMsg10="Le port {0} est membre d'un EtherChannel. Supprimer le port de l'EtherChannel avant de changer le profil de port.";
var re_sPort_ErrMsg11="Le VLAN Cisco-Guest doit exister avant d'appliquer le profil Guest au port. Cr�ez le VLAN Cisco-Guest.";
var re_sPort_ErrMsg12="Le VLAN Cisco-Voice doit exister avant d'appliquer le profil IP Phone+Desktop au port. Cr�ez le VLAN Cisco-Voice.";
var re_sPort_ErrMsg13="Le port {0} doit �tre membre du VLAN Cisco-Guest.";
var re_sPort_ErrMsg14="Le port {0} doit �tre membre du VLAN Cisco-Guest. Cr�ez ce VLAN s'il n'existe pas d�j�.";
var re_sPort_ErrMsg15="Le port {0} doit �tre membre du VLAN Cisco-Voice.";
var re_sPort_ErrMsg16="Le port {0} doit �tre membre du VLAN Cisco-Voice. Cr�ez ce VLAN s'il n'existe pas d�j�.";
var re_sPort_ErrMsg17="Seuls les ports associ�s au profil de port IP Phone+Desktop peuvent �tre membres du VLAN Cisco-Voice.";
var re_sPort_ErrMsg18="Seuls les ports associ�s au profil Guest peuvent �tre membres du VLAN Cisco-Guest.";
var re_sPort_ErrMsg19="Les ports associ�s au profil Guest doivent �tre affect�s au VLAN Cisco-Guest. Les ports appliqu�s au profil IP Phone+Desktop doivent �tre affect�s au VLAN Cisco-Voice. Ces VLANS doivent exister avant d'associer ces profils aux ports.";
var re_sPort_ErrMsg20="Les ports {0} doivent �tre membres du VLAN Cisco-Guest. Cr�ez ce VLAN s'il n'existe pas d�j�.";
var re_sPort_ErrMsg21="Les ports {0} doivent �tre membres du VLAN Cisco-Voice. Cr�ez ce VLAN s'il n'existe pas d�j�.";
var re_sPort_ErrMsg22="Lorsque votre station de gestion de r�seaux est connect�e directement � un port de commutation et la diode SETUP est verte, vous ne pouvez pas modifier le profil de port ou les param�tres VLAN sur ce port du commutateur.";

var re_sPort_WngMsg1="Le port {0} est affect� � un VLAN non existant. Par d�faut, le port sera affect� au VLAN de gestion.";

//non-macchiato
var re_sPort_Grp1Ttl="Configuration recommand�e au niveau syst�me";
var re_sPort_Grp2Ttl="Configuration recommand�e au niveau port ";

var re_sPort_GlblChkBox="Activer";
var re_sPort_AllPortsChkBox="Activer la configuration du port s�lectionn� pour tous les ports";
var re_sPort_Txt1="S�lectionnez une configuration de port";
var re_sPort_Txt2="Cliquez un port pour activer la configuration de port s�lectionn�e";

//tooltip
var re_sPort_LblSetup="Configuration";

//customize table
var re_sPort_LblSetupType="Type de configuration";

//error messages
var re_sPort_ErrMsg1="Vous avez cliqu� Personnaliser sans avoir configur� les param�tres du port.";
var re_sPort_ErrMsg2="L'ID VLAN doit �tre un nombre entier. Entrez une ID VLAN valide.";
var re_sPort_ErrMsg3="Vous devez entrer une ID VLAN avant de cliquer Termin�.";
var re_sPort_ErrMsg4="{0} n'est pas une ID VLAN valide. Entrez une ID VLAN entre 1 et 1001 ou 1006 et 4094.";
var re_sPort_ErrMsg5="{0} n'est pas une ID VLAN valide. Entrez une ID VLAN entre 1 et 1001.";
var re_sPort_ErrMsg6="Le p�riph�rique fonctionne en mode client VTP, les nouveaux VLANs ne peuvent pas �tre cr��s dans ce mode.";
var re_sPort_ErrMsg7="Le nombre maximum de VLANS support�s sur ce p�riph�rique est {0} les VLANS suivants ne peuvent pas �tre utilis�s {1}";
var re_sPort_ErrMsg8="Les param�tres de connexion de Desktop ne peuvent �tre associ�s aux ports {0} parce qu'ils ne sont pas connect�s � des p�riph�riques de ce type.";

//new strings
var re_sPort_ErrMsg23="Les ports associ�s aux profils de port IP Phone+Desktop doivent aussi �tre associ�s � un VLAN d'acc�s autre que le VLAN Cisco-Voice.";
var re_sPort_ErrMsg24="Seuls les ports associ�s au profil de port IP Phone+Desktop ou Server peuvent �tre membres du VLAN Cisco-Voice.";

//additional strings - 03/06/06
var re_sPort_ErrMsg25  ="Vous avez cliqu� sur Personnaliser sans avoir configur� un profil de port.";
