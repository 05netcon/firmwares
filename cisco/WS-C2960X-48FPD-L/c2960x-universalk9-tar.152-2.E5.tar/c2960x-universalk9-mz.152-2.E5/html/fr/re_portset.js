/*
 *------------------------------------------------------------------
 * Resource file for Port settings
 * Copyright (c) 2006 by cisco Systems, Inc.
 *------------------------------------------------------------------
*/

//title
var re_pSet_Scr1Ttl="Param�trage des ports";

//Table headers

var re_pSet_TblHeader1="Port";
var re_pSet_TblHeader2="Description";
var re_pSet_TblHeader3="Activer";
var re_pSet_TblHeader4="Vitesse";
var re_pSet_TblHeader5="Duplex";
var re_pSet_TblHeader6="PoE";
var re_pSet_TblHeader7="Auto-MDIX";
var re_pSet_TblHeader8="Alimentation �lectrique par c�ble Ethernet";

//Warning messages.
var re_pSet_ErrMsg1="ERREUR : le port est nul";
var re_pSet_ErrMsg2="La description du port ne peut contenir un ? ou une tabulation.\n.";
var re_pSet_ErrMsg3="La description du port ne peut contenir plus de 18 caract�res.\n.";
var re_pSet_ErrMsg4="Vous ne pouvez pas activer auto-MDIX sur un port 1000BASE-SX SFP.\n";
var re_pSet_ErrMsg5="Vous ne pouvez pas activer auto-MDIX sur un port 1000BASE-LX SFP.\n";
var re_pSet_ErrMsg6="Vous ne pouvez pas activer auto-MDIX sur le port {0}. Ce port est d�sactiv�.\n";
var re_pSet_ErrMsg7="Vous ne pouvez pas activer auto-MDIX sur le port {0}. La vitesse et l'option duplex doivent �tre configur�es en 'Automatique' sur le port {1}.\n";
var re_pSet_ErrMsg8="Vous ne pouvez pas d�sactiver Auto-MDIX sur le port {0}. Ce port est non-actif.\n";
var re_pSet_ErrMsg9="Pendant la configuration initiale, vous ne pouvez pas d�sactiver l'interface de gestion {0}.\n";
var re_pSet_ErrMsg10="Pendant la configuration initiale, vous ne pouvez pas modifier le param�tre auto-MDIX sur l'interface de gestion {0}.\n";
var re_pSet_ErrMsg11="Pendant la configuration initiale, vous ne pouvez pas modifier le param�tre de vitesse sur l'interface de gestion {0}.\n";
var re_pSet_ErrMsg12="Vous ne pouvez pas modifier la vitesse du port de {0} � 1000 Mbps si le port est en mode half-duplex.\n";
var re_pSet_ErrMsg13="Vous ne pouvez pas modifier la vitesse du port de {0} � 'Auto' si le port est en mode half-duplex.\n";
var re_pSet_ErrMsg14="Pendant la configuration initiale, vous ne pouvez pas modifier le param�tre duplex sur l'interface de gestion {0}.";
var re_pSet_ErrMsg15="Le param�tre duplex sur ce port {0} ne peut �tre configur� en 'half-duplex' parce que sa vitesse est configur�e � 'Auto'.";
var re_pSet_ErrMsg16="Vous ne pouvez pas modifier la vitesse du port de {0} � 1000 Mbps si le port est en mode half-duplex.\n";
var re_pSet_ErrMsg17="Pendant la configuration initiale, vous ne pouvez pas modifier le param�tre PoE sur l'interface de gestion {0}\n";

//additional strings - 03/06/06
var re_pSet_ErrMsg18="Vous ne pouvez pas modifier la ligne duplex du port de {0} � half-duplex si la vitesse du port est 1000 Mbps.\n";
var re_pSet_ErrMsg19="La description du port peut contenir que des caract�res anglais.\n";
