/*
 *------------------------------------------------------------------
 * preflight resource file
 * Copyright (c) 2006, 2010 by cisco Systems, Inc.
 *------------------------------------------------------------------
*/

var re_preFlt_Ttl1 ="Risoluzione dei problemi di supporto del sistema operativo";
var re_preFlt_Ttl2 ="Risoluzione dei problemi relativi al supporto browser";
var re_preFlt_Ttl3 ="Risoluzione dei problemi di supporto del browser";
var re_preFlt_Ttl4 ="Risoluzione dei problemi relativi a JavaScript";
var re_preFlt_txt1 ="Sistema operativo";
var re_preFlt_txt2 ="Il sistema operativo (tipo di OS, versione) non � supportato.";
var re_preFlt_txt3 ="I seguenti sistemi operativi sono supportati:";
var re_preFlt_txt4 ="Windows XP, 2000";
var re_preFlt_txt5 ="Fare clic {qui} per tornare al report di Avvio.";
var re_preFlt_txt6 ="JavaScript non attivato. Per avviare l'applicazione di gestione dispositivi Javascript deve essere attivato.";
var re_preFlt_txt7 ="Abilitare JavaScript in Netscape";
var re_preFlt_txt8 ="Scegliere {Modifica > Preferenze} per aprire la finestra Preferenze.";
var re_preFlt_txt9 ="Fare clic su {Avanzate} sotto Categorie per visualizzare le preferenze avanzate.";
var re_preFlt_txt10 ="Selezionare {Abilita JavaScript} nell'area Avanzate e fare clic su OK.";
var re_preFlt_txt11 ="Fare clic {qui} per ritornare";
var re_preFlt_txt12 ="Abilitare JavaScript in Internet Explorer";
var re_preFlt_txt13 ="Scegliere {Strumenti > Opzioni Internet}";
var re_preFlt_txt14 ="Fare clic sulla scheda {Protezione}.";
var re_preFlt_txt15 ="Fare clic su {Livello personalizzato}. Verr� aperta la finestra Impostazioni di protezione.";
var re_preFlt_txt16 ="Scorrere verso il basso fino a Script e fare clic su {Attiva} sotto {Attiva gli script}.";
var re_preFlt_txt17 ="Fare clic su {OK} e poi su {S�} nella finestra di dialogo Avviso.";
var re_preFlt_txt18 ="Fare clic su {OK} per chiudere la finestra Opzioni Internet.";
var re_preFlt_txt20 ="Browser Internet";
var re_preFlt_txt21 ="Il  browser ({0}) non � supportato";
var re_preFlt_txt22 ="I seguenti browser sono supportati:";
var re_preFlt_txt23 ="Internet Explorer 5.5 e 6.0";
var re_preFlt_txt24 ="Netscape 7.1";
var re_preFlt_txt25 ="JavaScript";
var re_preFlt_txt26 ="JavaScript non � stato attivato.";
var re_preFlt_txt27 ="JavaScript deve essere attivato prima di avviare l'applicazione di gestione dispositivi.";
var re_preFlt_txt28 ="Fare clic {qui} per ulteriori informazioni.";
var re_preFlt_txt29 ="Impossibile determinare lo stato del browser.";
var re_preFlt_txt30 ="Sistema operativo";
var re_preFlt_txt31 ="Impossibile determinare lo stato del sistema operativo.";
var re_preFlt_txt32 ="Report di configurazione";
var re_preFlt_txt33 ="Report di avvio";
var re_preFlt_txt34 ="L'applicazione di gestione dispositivi non pu� essere avviata nel browser {0}";
var re_preFlt_txt35 ="Si prega di aggiornare il browser.";
var re_preFlt_txt36 ="L'applicazione di gestione dispositivi non supporta il browser {0}";
var re_preFlt_txt37 ="Fare clic su continua per avviare il browser non supportato:";
var re_preFlt_txt38 ="Fare clic {qui} per ulteriori informazioni.";
var re_preFlt_txt39 ="Il browser � supportato.";
var re_preFlt_txt40 ="L'applicazione di gestione dispositivi non supporta il sistema operativo {0}.";
var re_preFlt_txt41 ="Fare clic su Continua per avviare l'applicazione sul sistema non supportato:";
var re_preFlt_txt42 ="Il sistema operativo � supportato.";
var re_preFlt_txt43 ="Accesso lettura/scrittura";
var re_preFlt_txt44 ="L'applicazione di gestione dispositivi non supporta l'accesso di sola lettura per questo switch.";
var re_preFlt_txt45 ="Nota: l'accesso all'applicazione di gestione dispositivi verr� effettuato in modalit� lettura/scrittura.";
var re_preFlt_txt46 ="Passo 1";
var re_preFlt_txt47 ="Passo 2";
var re_preFlt_txt48 ="Passo 3";
var re_preFlt_txt49 ="Passo 4";
var re_preFlt_txt50 ="Passo 5";
var re_preFlt_txt51 ="Passo 6";
var re_preFlt_txt52 ="Passo 7";

//Newly added Strings
var re_preFlt_txt53="JavaScript � stato attivato.";
var re_preFlt_txt54="Il modo di accesso lettura/scrittura non � noto.";
var re_preFlt_txt55 ="Copyright (c) 2004-2006 di Cisco Systems, Inc.";
var re_preFlt_txt56 ="Continua";