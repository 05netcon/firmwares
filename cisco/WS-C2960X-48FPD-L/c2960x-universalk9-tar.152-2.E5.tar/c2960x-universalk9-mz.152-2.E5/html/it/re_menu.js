/*
 *------------------------------------------------------------------
 * menu resource file
 * Copyright (c) 2006, 2010 by cisco Systems, Inc.
 *------------------------------------------------------------------
*/

var re_menu_txt_contents ="Menu";
var re_menu_txt_dashboard ="Dashboard";
var re_menu_txt_configure ="Configurazione";
var re_menu_txt_smartports ="Smartports";
var re_menu_txt_portset ="Impostazioni della porta";
var re_menu_txt_exsetup ="Express Setup";
var re_menu_txt_vlans ="VLAN";
var re_menu_txt_snmp ="SNMP";
var re_menu_txt_ethchan ="EtherChannels";
var re_menu_txt_userpass ="Utenti e password";
var re_menu_txt_restartreload ="Riavvio e ripristino";
var re_menu_txt_monitor ="Monitoraggio";
var re_menu_txt_trends ="Trend";
var re_menu_txt_portstatus ="Stato delle porte";
var re_menu_txt_portstatistics ="Statistiche delle porte";
var re_menu_txt_alertlog ="Log degli avvisi";
var re_menu_txt_diag ="Diagnostica";
var re_menu_txt_softupgrade ="Aggiornamento software";
var re_menu_txt_netassist ="Network Assistant";
var re_menu_txt_maintenance ="Manutenzione";
var re_menu_txt_intro ="Introduzione";
var re_menu_txt_legend ="Legenda";
var re_menu_txt_support ="Supporto";
var re_menu_txt_telnet ="Telnet";

//new strings
var re_menu_txt_controllerDM="Gestione dispositivi del controller";
