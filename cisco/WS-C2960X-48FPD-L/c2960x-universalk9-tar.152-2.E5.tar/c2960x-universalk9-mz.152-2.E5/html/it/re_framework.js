/*
 *------------------------------------------------------------------
 * framework resource file - includes SSL, bottom banner buttons, graph, appsui, telnet, network assistant
 * Copyright (c) 2006-2007, 2010 by cisco Systems, Inc.
 * feature code - frmWrk
 *------------------------------------------------------------------
*/

//feature pages
var re_frmWrk_WngMsg1 ="Si � selezionato 'Invia' senza avere compiuto alcuna modifica nella finestra di dialogo.";
var re_frmWrk_WngMsg1Ttl ="Informazioni";

//appsui
var re_frmWrk_ErrMsgDefTtl ="Errore";
var re_frmWrk_WngMsgDefTtl ="Avvertenza";
var re_frmWrk_ConfMsgDefTtl ="Attenzione";

//framework
var re_frmWrk_ConfMsg1 ="Avvertenza:\n\nNella pagina sono presenti modifiche non salvate.\n\nFare clic su OK per salvare le modifiche oppure scartarle e continuare.";
var re_frmWrk_ConfMsgWindowClose ="Nella pagina sono presenti modifiche non salvate.";
//no handler messages
var re_frmWrk_ErrMsgNoApply ="Non sono disponibili gestori per Applica.";
var re_frmWrk_ErrMsgNoCancel ="Non sono disponibili gestori per Annulla.";
var re_frmWrk_ErrMsgNoNext ="Non sono disponibili gestori per Avanti.";
var re_frmWrk_ErrMsgNoBack ="Non sono disponibili gestori per Indietro.";
var re_frmWrk_ErrMsgNoFinish ="Non sono disponibili gestori per Termina.";
var re_frmWrk_ErrMsgNoHelp ="Guida non disponibile";

//xhome
var re_frmWrk_TxtFrmSupport ="Queste pagine fanno uso di Frame. Accertarsi che il proprio browser supporti appieno la funzionalit� dei Frame.";

//graph
var re_frmWrk_GraphLegend ="Legenda";

var re_frmWrk_GraphEmpty ="[grafico vuoto]";
var re_frmWrk_GraphTimeSlots ="Intervalli di tempo";

var re_frmWrk_GraphLblDay1 ="Dom";
var re_frmWrk_GraphLblDay2 ="Lun";
var re_frmWrk_GraphLblDay3 ="Mar";
var re_frmWrk_GraphLblDay4 ="Mer";
var re_frmWrk_GraphLblDay5 ="Gio";
var re_frmWrk_GraphLblDay6 ="Ven";
var re_frmWrk_GraphLblDay7 ="Sab";

var re_frmWrk_GraphLblMonth1 ="Gen";
var re_frmWrk_GraphLblMonth2 ="Feb";
var re_frmWrk_GraphLblMonth3 ="Mar";
var re_frmWrk_GraphLblMonth4 ="Apr";
var re_frmWrk_GraphLblMonth5 ="Mag";
var re_frmWrk_GraphLblMonth6 ="Giu";
var re_frmWrk_GraphLblMonth7 ="Lug";
var re_frmWrk_GraphLblMonth8 ="Ago";
var re_frmWrk_GraphLblMonth9 ="Set";
var re_frmWrk_GraphLblMonth10 ="Ott";
var re_frmWrk_GraphLblMonth11 ="Nov";
var re_frmWrk_GraphLblMonth12 ="Dic";

var re_frmWrk_GraphLblTimeAM ="am";
var re_frmWrk_GraphLblTimePM ="pm";
var re_frmWrk_GraphLblTitle ="Titolo";

//SSL dialog
var re_frmWrk_SSLTxt1 ="Stabilire una sessione protetta con lo switch?";
var re_frmWrk_SSLTxt2 ="Non visualizzare pi� questo messaggio";
var re_frmWrk_SSLBtn1 ="S�";
var re_frmWrk_SSLBtn2 ="No";

//bottom frame button names
var re_frmWrk_BtnDone ="Fatto";
var re_frmWrk_BtnBack ="Indietro";
var re_frmWrk_BtnNext ="Avanti";
var re_frmWrk_BtnFinish ="Fine";
var re_frmWrk_BtnCancel ="Annulla";
var re_frmWrk_BtnRefresh ="Aggiorna";
var re_frmWrk_BtnHelp ="Guida";
var re_frmWrk_BtnSubmit ="Invia";

//network assistant
var re_frmWrk_CNATtl ="Network Assistant";

//non-macchiato
//telnet
var re_frmWrk_TelnetTtl ="Telnet";
var re_frmWrk_TelnetTxt ="La console Telnet offre accesso all'interfaccia della riga di comando (CLI) dello switch. L'interfaccia CLI � un metodo di comunicazione con lo switch Cisco il cui uso � raccomandato esclusivamente agli utenti esperti. La console Telnet sar� aperta in una nuova finestra.";
var re_frmWrk_TelnetLinkTxt1 ="Avvia una console Telnet";
var re_frmWrk_TelnetLinkTxt2 ="Telnet non attiva su questo dispositivo. Passare a {Express Setup} per attivare Telnet.";

//new Strings

//OLH message
var re_frmWrk_OLHErrMsg1="Informazioni:\n\nLa guida online di questa finestra non � disponibile in {0}.  Per visualizzare la guida online in {0}, si deve prima aggiornare lo switch con il software dello switch {0} da Cisco.com";

var re_restart_Ttl="Riavvio e ripristino";
var re_restart_txt1="Riavvia lo switch con le sue impostazioni correnti.";
var re_restart_txt2="Ripristina lo switch alla configurazione di fabbrica e riavvia lo switch.";
var re_restart_txt3="Il dispositivo sar� ricaricato in {0} secondi.";
var re_restart_txt4="Dispositivo in corso di ricaricamento";
var re_restart_txt5="Ricaricamento dispositivo riuscito";
var re_restart_txt6="Ricaricamento in corso�";
var re_restart_ConfMsg1="Il dispositivo ripristiner� la sua configurazione predefinita di fabbrica e canceller� il suo indirizzo IP corrente. Continuare?";
var re_toolbar_txt_refresh="Aggiorna";
var re_toolbar_txt_print="Stampa";
var re_toolbar_txt_smartports="Smartports";
var re_toolbar_txt_swupgrade="Aggiornamento software";
var re_toolbar_txt_legend="Legenda";
var re_toolbar_txt_help="Aiuto";
var re_toolbar_txt_forward="Avanti";
var re_toolbar_txt_back="Indietro";

//network assistant
var re_frmWrk_CNATxt1="Cisco Network Assistant consente la configurazione e la gestione{\n}centralizzate degli switch, i router e gli access point{\n} wireless nelle reti delle piccole e medie imprese.";
var re_frmWrk_CNATxt2="Singolo punto di gestione della rete";
var re_frmWrk_CNATxt3="Configurazione intelligente dei dispositivi";
var re_frmWrk_CNATxt4="Monitoraggio e risoluzione dei problemi di rete";
var re_frmWrk_CNATxt5="Funzione di ricerca e guida online integrate";
var re_frmWrk_CNATxt6="ULTERIORI INFORMAZIONI e DOWNLOAD di NETWORK ASSISTANT GRATIS!";

//Strings newly added for Uptime display - 03/28/06
var re_Uptime_years ="anni";
var re_Uptime_year ="anno";
var re_Uptime_weeks ="settimane";
var re_Uptime_week ="settimana";
var re_Uptime_days ="giorni";
var re_Uptime_day ="giorno";
var re_Uptime_hours ="ore";
var re_Uptime_hour ="ora";
var re_Uptime_minutes ="minuti";
var re_Uptime_minute ="minuto";

//Telnet Not supported message for Vista
var re_frmWrk_TelnetLinkTxt3 = "La funzione Telnet non � disponibile se il proprio sistema operativo � Windows Vista o se si sta usando Internet Explorer 7.0.";
