/*
 *------------------------------------------------------------------
 * Resource file for port statistics
 * Copyright (c) 2006, 2010 by cisco Systems, Inc.
 *------------------------------------------------------------------
*/

//Title
var re_pStats_ScrTtl="Statistiche delle porte";

//Tabs
var re_pStats_tab_Lbl1="Panoramica";
var re_pStats_tab_Lbl2="Dettagli trasmissione";
var re_pStats_tab_Lbl3="Dettagli ricezione";

//Table Headers
var re_pStats_Tblheader1="Porta";
var re_pStats_Tblheader2="Byte{0}trasmessi";
var re_pStats_Tblheader3="Totale pacchetti{0}trasmessi";
var re_pStats_Tblheader4="Byte{0}ricevuti";
var re_pStats_Tblheader5="Totale pacchetti{0}ricevuti";
var re_pStats_Tblheader6="Totale pacchetti{0}errati trasmessi"; 
var re_pStats_Tblheader7="Totale pacchetti{0}errati ricevuti";
var re_pStats_Tblheader8="Pacchetti{0}unicast";
var re_pStats_Tblheader9="Pacchetti{0}multicast";
var re_pStats_Tblheader10="Pacchetti{0}broadcast";
var re_pStats_Tblheader11="Totale pacchetti{0}in collisione";
var re_pStats_Tblheader12="Pacchetti con{0}collisioni in eccesso";
var re_pStats_Tblheader13="Pacchetti con{0}collisioni in ritardo";
var re_pStats_Tblheader14="Errori FCS";
var re_pStats_Tblheader15="Pacchetti con{0}errori di allineamento";
var re_pStats_Tblheader16="Pacchetti{0}sovradimensionati";
var re_pStats_Tblheader17="Pacchetti{0}sottodimensionati";
var re_pStats_Tblheader18="Frammenti{0}di collisione";

//Warning messages
var re_pStats_WngMsg="Selezionare una riga e fare clic su 'Azzera conteggi' per cancellare le statistiche nella riga selezionata.";

//Button labels
var re_pStats_clr_btn="Azzera conteggi";
