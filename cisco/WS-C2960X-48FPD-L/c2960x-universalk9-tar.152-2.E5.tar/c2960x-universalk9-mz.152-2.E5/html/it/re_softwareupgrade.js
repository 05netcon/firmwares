/*
 *------------------------------------------------------------------
 * software upgrade resource file
 * Copyright (c) 2006, 2010 by cisco Systems, Inc.
 * feature code - swUpg
 *------------------------------------------------------------------
*/

//macchiato

var re_swUpg_Ttl ="Aggiornamento software";
var re_swUpg_Btn1 ="Aggiorna";

var re_swUpg_Txt1 ="Lo switch sta eseguendo la versione del software Cisco IOS";
var re_swUpg_Txt2 ="L'ultima versione del software per lo switch � disponibile all�indirizzo {0} (file in formato tar).";
var re_swUpg_Txt3 ="Scaricare il file tar sul proprio PC o sul dispositivo di rete.";
var re_swUpg_Txt4 ="Selezionare il file tar per l'aggiornamento usando il pulsante Sfoglia�";
var re_swUpg_Txt5 ="Fare clic su Aggiorna.";

var re_swUpg_FileBrowse ="Nome file immagine";

var re_swUpg_Grp1Ttl ="Stato";
var re_swUpg_TblHeader1Mach ="Fase";
var re_swUpg_TblHeader2Mach ="Dimensione del file";

var re_swUpg_ConfMsg1 ="Avviso:\n\nsi sta per aggiornare il software dello switch. Non interrompere questa\nsessione del browser fino a al termine del processo di aggiornamento. Dopo\nil termine del processo di aggiornamento, chiudere questa sessione del browser e visualizzare l'applicazione di gestione dispositivi in una nuova sessione. Fare clic su OK per continuare con il processo di aggiornamento, o fare clic su Annulla per uscire.";

var re_swUpg_ErrMsg1 ="Errore:\n\nfare clic su Sfoglia per accedere al file immagine dello switch (file tar) sul proprio PC.";
var re_swUpg_ErrMsg2 ="Errore: l'aggiornamento del software dello switch � in corso in un'altra sessione";
var re_swUpg_ErrMsg3 ="L'aggiornamento del software � in corso.";

var re_swUpg_Txt_Stage1Mach ="Caricamento del file tar nello switch";
var re_swUpg_Txt_Stage2Mach ="File tar caricato";
var re_swUpg_Txt_Stage3Mach ="Nuovo caricamento in sospeso";
var re_swUpg_Txt_Stage4Mach ="Aggiornamento fallito";

var re_swUpg_Txt_ImageInstalled ="Nuova immagine software installata. Nuovo caricamento del dispositivo in corso.{0}Attendere. Possono essere necessari fino a 5 minuti prima della ripresa della connessione.";
var re_swUpg_Txt_UpgInComplete ="Lo switch non � stato ancora ricaricato, l'applicazione di gestione dispositivi sta attendendo una risposta dal dispositivo.";
var re_swUpg_Txt_UpgComplete ="Il software dello switch � stato aggiornato. Per utilizzare il software aggiornato, terminare la sessione corrente e avviarne una nuova.";
var re_swUpg_Txt_ArchiveStatusMsg ="L'aggiornamento del software � andato a buon fine. Per usare il software aggiornato, terminare la sessione corrente e avviarne una nuova.";

var re_swUpg_ErrMsg4 ="Errore: l'aggiornamento precedente non � andato a buon fine o � stato annullato. Il clean-up non � terminato.";
var re_swUpg_ErrMsg5 ="Errore: la memoria presente nello switch non � sufficiente per l'installazione della nuova immagine software.";
var re_swUpg_ErrMsg6 ="Errore: il file non � compatibile con il formato tar delle versioni IOS di Cisco.";
var re_swUpg_ErrMsg7 ="Errore: il file dell�immagine software non � adatto a questo switch.";
var re_swUpg_ErrMsg8 ="Errore: il file dell�immagine software � corrotto. Scaricare nuovamente il file dal sito Cisco.com.";
var re_swUpg_ErrMsg9 ="Errore: la memoria presente nello switch non � sufficiente per l'esame della nuova immagine del software.";
var re_swUpg_ErrMsg10 ="Errore: il file non esiste";
var re_swUpg_ErrMsg11 ="Errore: impossibile estrarre l'immagine.";
var re_swUpg_ErrMsg12 ="Errore: Non definito";


//non-macchiato
var re_swUpg_TblHeader1 ="Fase";
var re_swUpg_TblHeader2 ="Stato";

var re_swUpg_Txt_Stage1 ="1. Caricamento del file tar nello switch...";
var re_swUpg_Txt_Stage2 ="2. Verifica del file tar...";
var re_swUpg_Txt_Stage3 ="3. Estrazione dei file dall�archivio tar...";
var re_swUpg_Txt_Stage4 ="4. Riavvio dello switch...";

var re_swUpg_Txt_RestartSwitch ="Attendere. Possono essere necessari fino a 5 minuti prima della ripresa della connessione.";

//additional strings - 03/06/06
var re_swUpg_TltpInProgress  = "In corso";
var re_swUpg_TltpCompleted  = "Completato";
var re_swUpg_TltpFailed  = "Operazione non riuscita";
var re_swUpg_Txt_Stage5Mach  = "Download immagine completato";
var re_swUpg_Txt_noUpgradeinProgress = "Non � in corso nessun aggiornamento software.";
var re_swUpg_Txt_UpgradeInAnotherSession = "L'aggiornamento del software � gi� in corso in un'altra sessione.";

//new strings - 03/28/06
var re_swUpg_ErrMsg13 ="Errore: non � possibile installare su questo switch la versione Cisco IOS 12.2(25)FY. Aggiornare lo switch alla versione IOS 12.2(25)SEG o successiva.";
var re_swUpg_ErrMsg14 ="Errore: la memoria presente nello switch non � sufficiente per l'installazione della nuova immagine software. L'immagine software corrente � stata rimossa. Lo switch sta ricaricando l'immagine software predefinita di fabbrica.";
var re_swUpg_Txt_UcodeBoot ="Lo switch � stato ricaricato con l'immagine software predefinita di fabbrica. Terminare la sessione corrente e avviarne una nuova.";

var re_swUpg_ErrMsg15 ="Errore: Non � possibile installare su questo switch la versione Cisco IOS 12.2.(25)FY. Aggiornare lo switch alla versione IOS 12.2(25)SEG o successiva. L'immagine software corrente � stata rimossa. Lo switch sta ricaricando l'immagine software predefinita di fabbrica.";
