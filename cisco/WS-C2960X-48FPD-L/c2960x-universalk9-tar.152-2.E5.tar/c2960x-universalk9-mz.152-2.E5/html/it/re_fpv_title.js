/*
 *------------------------------------------------------------------
 * FPV, topframe resource file
 * Copyright (c) 2006-2007, 2009-2010, 2013 by cisco Systems, Inc.
 *------------------------------------------------------------------
*/

var re_fpv_txt_status ="Stato";
var re_fpv_txt_duplex ="Duplex";
var re_fpv_txt_speed ="Velocit�";
var re_fpv_txt_power ="Alimentazione";
var re_fpv_txt_poe ="PoE";
var re_fpv_txt_view ="Visualizza";
var re_fpv_txt_nextrefresh1 ="Prossimo aggiornamento tra {0} secondo";
var re_fpv_txt_nextrefresh2 ="Prossimo aggiornamento tra {0} secondi";
var re_fpv_txt_refreshing ="Aggiornamento�";
var re_fpv_txt_refreshpause ="Aggiornamento sospeso";
var re_fpv_txt_movepointer ="Spostare il puntatore sulle porte per ulteriori informazioni.";
var re_fpv_Tltp_port ="Porta";
var re_fpv_Tltp_type ="Tipo";
var re_fpv_Tltp_descr ="Descrizione";
var re_fpv_Tltp_uptime ="Tempo di servizio";
var re_fpv_Tltp_poe ="PoE";
var re_fpv_Tltp_noalert ="Nessun avviso";
var re_fpv_Tltp_severity ="Severit�";
var re_fpv_Tltp_event ="Evento";
var re_fpv_Tltp_time ="Orario";
var re_fpv_Tltp_viewallalert ="Visualizza tutti gli avvisi";
var re_Ttl_txt_catseriesdevmanager1 ="Gestione dispositivi ITP serie {0}";
var re_Ttl_txt_catseriesdevmanager ="Gestione dispositivi Catalyst serie {0}";
//Choya - Added this string only in IT resource file as it want to keep seperate pattern from other language.
var re_Ttl_txt_catseriesdevmanager_help= "Guida all'applicazione di gestione dispositivi Cisco Catalyst serie {0}";
var re_Ttl_txt_catseriesdevmanager_help1= "Guida all'applicazione di gestione dispositivi ITP serie {0}";
var re_Ttl_txt_catseriesexsetup1 ="Express Setup di ITP Serie {0}";
var re_Ttl_txt_catseriesexsetup ="Express Setup di Catalyst Serie {0}";
var re_Ttl_txt_catexsetup ="Express Setup di Catalyst";
var re_Ttl_txt_catdevmanager ="Gestione dispositivi Catalyst";
var re_Ttl_txt_registernow ="Registrati ora";
var re_Ttl_txt_devmanager ="Gestione dispositivi";
var re_SSL_txt_session ="Sessione";
var re_SSL_txt_normalmode ="Modalit� normale";
var re_SSL_txt_securemode ="Modalit� protetta";
var re_SSL_txt_standard ="Standard";
var re_SSL_txt_secured ="Protetta";
var re_SSL_txt_userpref_WngMsg ="Si desidera rendere {0} la modalit� predefinita?";

//non-macchiato
var re_fpv_txt_switch ="Switch";
var re_fpv_txt_rps ="RPS";
var re_fpv_txt_stack ="Stack";
var re_fpv_txt_iobay ="Elemento I/O";
var re_fpv_txt_member ="Partecipante";
var re_fpv_txt_master ="Master";
var re_fpv_Tltp_inline ="Alimentazione in linea";
var re_Ttl_txt_esm ="Gestione dispositivi Modulo di servizio EnterSwitch";
var re_Ttl_txt_cbs3030 ="Gestione dispositvi Switch Catalyst Blade 3030";
var re_Ttl_txt_cbs3020 ="Gestione dispositvi Switch Catalyst Blade 3020";

//Newly added Strings
var re_Ttl_txt_esm_2 ="Modulo di servizio EtherSwitch";
var re_Ttl_txt_cbs3030_2="Switch Catalyst Blade 3030";
var re_Ttl_txt_cbs3020_2 ="Switch Catalyst Blade 3020";
var re_Ttl_txt_catalyst ="Catalyst";
var re_Ttl_txt_softrecover="Ripristino software";
var re_Ttl_txt_catseries1 ="ITP Serie {0}";
var re_Ttl_txt_catseries ="Catalyst Serie {0}";
var re_Ttl_txt_exsetup ="Express Setup";

//additional strings - 03/06/06
var re_fpv_Tltp_different_mode  = "Fare clic sul pulsante MODE per visualizzare una modalit� diversa.";
var re_fpv_txt_Lanugage  = "Lingua";

//Newly added strings (for Falchion)
var re_Ttl_txt_cbs3040="Switch Catalyst Blade 3040";

//Strings added for pixar SKUs
var re_fpv_Tltp_fru = "FRU";
var re_fpv_Tltp_pid = "PID";
var re_fpv_Tltp_fru_information = "FRU Information";
var re_fpv_Tltp_System_Power = "System Power";
var re_fpv_Tltp_PoE_Power = "PoE Power";
var re_fpv_Tltp_Sidinfo = "SID Information";
var re_fpv_Tltp_type = "Type";
var re_fpv_Tltp_System_Power = "System Power";
var re_fpv_Tltp_PoE_Power = "PoE Power";
var re_fpv_Tltp_serial = "Serial Number";
var re_fpv_Tltp_Port = "Port";
var re_fpv_Tltp_IPAddress = "IP Address";
var re_fpv_Tltp_Status = "Status";
var re_fpv_Tltp_EtherManagePort = "Ethernet Management Port";

//For Stout 11/11/09
var re_fpv_Tltp_IPAddress = "Indirizzo IP";
var re_fpv_Tltp_Status = "Stato";
var re_fpv_Tltp_EtherManagePort = "Porta di gestione Ethernet";
