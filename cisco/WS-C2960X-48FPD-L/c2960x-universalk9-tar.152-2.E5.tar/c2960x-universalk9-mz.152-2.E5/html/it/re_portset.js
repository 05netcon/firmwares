/*
 *------------------------------------------------------------------
 * Resource file for Port settings
 * Copyright (c) 2006, 2010 by cisco Systems, Inc.
 *------------------------------------------------------------------
*/

//title
var re_pSet_Scr1Ttl="Impostazioni della porta";

//Table headers

var re_pSet_TblHeader1="Porta";
var re_pSet_TblHeader2="Descrizione";
var re_pSet_TblHeader3="Attiva";
var re_pSet_TblHeader4="Velocit�";
var re_pSet_TblHeader5="Duplex";
var re_pSet_TblHeader6="PoE";
var re_pSet_TblHeader7="Auto-MDIX";
var re_pSet_TblHeader8="Alimentazione in linea";

//Warning messages.
var re_pSet_ErrMsg1="ERRORE: la porta � in stato NULL";
var re_pSet_ErrMsg2="La descrizione della porta non pu� contenere punti interrogativi o caratteri di tabulazione.\n";
var re_pSet_ErrMsg3="La descrizione della porta non pu� contenere pi� di 18 caratteri.\n";
var re_pSet_ErrMsg4="Non � possibile attivare l'auto-MDIX su una porta SFP 1000BASE-SX.\n";
var re_pSet_ErrMsg5="Non � possibile attivare l'auto-MDIX su una porta SFP 1000BASE-LX.\n";
var re_pSet_ErrMsg6="Non � possibile attivare l'auto-MDIX sulla porta {0}. La porta � disabilitata.\n";
var re_pSet_ErrMsg7="Non � possibile attivare l'auto-MDIX sulla porta {0}. Entrambi i parametri velocit� e duplex della porta {1} devono essere impostati su auto.\n";
var re_pSet_ErrMsg8="Non � possibile disattivare l'auto-MDIX sulla porta {0}. La porta � disabilitata.\n";
var re_pSet_ErrMsg9="Durante la configurazione iniziale non � possibile disattivare la vlan di gestione {0}.\n";
var re_pSet_ErrMsg10="Durante la configurazione iniziale non � possibile cambiare l'impostazione dell'auto-MDIX sulla vlan di gestione {0}.\n";
var re_pSet_ErrMsg11="Durante la configurazione iniziale non � possibile cambiare l'impostazione della velocit� sulla vlan di gestione {0}.\n";
var re_pSet_ErrMsg12="Non � possibile modificare a 1000 Mbps la velocit� della porta {0}, se questa � in modalit� half-duplex.\n";
var re_pSet_ErrMsg13="Non � possibile modificare a 'Auto' la velocit� della porta {0}, se questa � in modalit� half-duplex.\n";
var re_pSet_ErrMsg14="Durante la configurazione iniziale non � possibile cambiare l'impostazione del duplex sulla vlan di gestione {0}.\n";
var re_pSet_ErrMsg15="Non � possibile cambiare in 'half-duplex' il valore della porta {0}, se la sua velocit� � impostata su 'auto'.\n";
var re_pSet_ErrMsg16="Non � possibile modificare a 1000 Mbps la velocit� della porta {0}, se questa � in modalit� half-duplex.\n";
var re_pSet_ErrMsg17="Durante la configurazione iniziale non � possibile cambiare l'impostazione del PoE sulla vlan di gestione {0}.\n";

//additional strings - 03/06/06
var re_pSet_ErrMsg18 = "Non � possibile configurare la porta {0} in modalit� half-duplex, se la sua velocit� � pari a 1000 Mbps.\n";
var re_pSet_ErrMsg19 = "La descrizione della porta non pu� contenere lettere che non fanno parte dell'alfabeto inglese.\n";
