/*
 *------------------------------------------------------------------
 * express setup resource file - includes express setup (incl. smartports info page), managed and recovery mode pages
 * Copyright (c) 2006-2010 by cisco Systems, Inc.
 * feature code - xSetup
 *------------------------------------------------------------------
*/

//macchiato
var re_xSetup_Ttl ="Express Setup";

var re_xSetup_LblMgmtIntMach ="VLAN di gestione";
var re_xSetup_LblIPMode ="Modalit� di assegnazione IP";
var re_xSetup_LblIPModeStatic ="Statica";
var re_xSetup_LblIPModeDHCP ="DHCP";
var re_xSetup_LblIPAddress ="Indirizzo IP";
var re_xSetup_LblSubnet ="Subnet Mask";
var re_xSetup_LblDefGateway ="Gateway predefinito";
var re_xSetup_LblUsrName ="Nome utente";
var re_xSetup_LblPwd ="Password";
var re_xSetup_LblConfPwd ="Conferma password";
var re_xSetup_LblHostName ="Nome host";
var re_xSetup_LblSysDate ="Data di sistema {(GG/MMM/AAAA)}";
var re_xSetup_LblSysTime ="Ora di sistema {(HH:MM)}";
var re_xSetup_LblTimeZone ="Fuso orario";
var re_xSetup_LblDST ="Ora legale";
var re_xSetup_LblEnable ="Attiva";

var re_xSetup_Grp1Ttl ="Impostazioni di rete";
var re_xSetup_Grp1Tt2 ="Impostazioni opzionali";

var re_xSetup_Txt2 ="Il server DHCP rinegozier� l'indirizzo IP dello switch. Usare il nuovo indirizzo per avviare l'applicazione di gestione dispositivi.";

var re_xSetup_ErrMsg1 ="Errore:\n\nImmettere un VLAN ID compreso tra 1 e 1001.";
var re_xSetup_ErrMsg2 ="Errore\n\nImmettere un indirizzo IP per lo switch.";
var re_xSetup_ErrMsg4 ="Errore:\n\nL'indirizzo IP dello switch e il gateway predefinito devono appartenere alla stessa subnet.";
var re_xSetup_ErrMsg9 ="Errore:\n\nIl nome dell�host non deve contenere punti interrogativi, spazi o tab.";
var re_xSetup_ErrMsg18 ="Errore:\n\nL'indirizzo IP dello switch e il gateway predefinito non possono essere uguali.";
var re_xSetup_ErrMsg21 ="Errore:\n\n\"{0}\" non � un indirizzo IP valido. Immettere l'indirizzo IP nel formato x.x.x.x, nel quale ogni x pu� essere qualsiasi numero compreso tra 0 e 255.";
var re_xSetup_ErrMsg22 ="Errore:\n\n{0}\non � un indirizzo IP valido.";
var re_xSetup_ErrMsg23 ="Errore:\n\n\"{0}\" non � un indirizzo IP valido per il gateway predefinito.\nImmettere l'indirizzo IP nel formato x.x.x.x, nel quale ogni x pu� essere qualsiasi numero compreso tra 0 e 255.";
var re_xSetup_ErrMsg25 ="Errore:\n\nImmettere un numero tra 0 e {0} in questo campo";
var re_xSetup_ErrMsg26 ="Errore:\n\n\"{0}\" non � un indirizzo IP valido per il gateway predefinito.";

var re_xSetup_ConfMsg2 ="Avviso:\n\nL'indirizzo IP di questo dispositivo verr� cambiato. Express Setup cercher�\ndi collegarsi a questo dispositivo utilizzando questo nuovo indirizzo IP {0}\nSe l'indirizzo IP del vostro PC non � nella stessa sottorete di questo nuovo indirizzo IP,\nsi perder� la connettivit� a questo dispositivo. Fare clic su OK per applicare il nuovo indirizzo IP. Fare clic su annulla per non applicare il nuovo indirizzo IP.";
var re_xSetup_ConfMsg3 ="Attenzione:\n\nIl gateway predefinito non ha un indirizzo IP specificato. Continuare?";
var re_xSetup_ConfMsg6 ="Avviso:\n\nLa vlan di gestione {0} sar� configurata con questo\nIndirizzo IP {1}.\n\nProcedere?";
var re_xSetup_ConfMsg7 ="Avviso:\n\nLa vlan di gestione {0} sar� configurata con questo\nIndirizzo IP {1}.\n\nPer comunicare con lo switch, almeno una porta switch deve\nessere assegnata alla nuova VLAN di gestione.\n\nProcedere?";

var re_xSetup_ConfMsg8 ="Avviso:\n\nLa vlan di gestione {0} sar� configurata con l'indirizzo IP\nassegnato dal server DHCP.\n\nProcedere?";
var re_xSetup_ConfMsg9 ="Avviso:\n\nLa vlan di gestione {0} sar� configurata con l'indirizzo IP assegnato dal server DHCP.\n\nPer comunicare con lo switch, almeno una porta switch deve\nessere assegnata alla nuova VLAN di gestione.\n\nProcedere?";
var re_xSetup_ConfMsg10 ="Informazione:\n\nIl server DHCP negozier� nuovamente l'indirizzo IP dello switch, di conseguenza,\nl'indirizzo IP potrebbe cambiare. Se l'indirizzo IP cambia, per avviare\nil device manager sar� necessario utilizzare il nuovo indirizzo.\n\nProcedere?";

//express setup mode info page
var re_xSetup_InfoTxt1 ="La configurazione iniziale dello switch � completa.";
var re_xSetup_InfoTxt2 ="Prima di collegare i dispositivi � possibile ottimizzare le prestazioni dello switch assegnando ruoli porta Smartport alle porte degli switch. I ruoli porta assicurano protezione, affidabilit� e prestazioni migliori attivando le funzionalit� della porta secondo il dispositivo cui tale porta si collega. � possibile assegnare i ruoli porta uno per volta o attivare una configurazione standard delle Smartport. Per questo switch una configurazione standard delle Smartport assegner� i seguenti ruoli porta:";
var re_xSetup_InfoTxt3 ="I ruoli porta si possono assegnare anche per i router, i telefoni IP e altri dispositivi.";
var re_xSetup_InfoTxt4 ="Porte 1-24 - Dekstop e computer";
var re_xSetup_InfoTxt5 ="Porte high-speed 1 e 2 - Switch Ethernet";
var re_xSetup_InfoTxt6 ="Porte 1-24 - Telefoni IP";
var re_xSetup_InfoTxt7 ="Porte high-speed 1 e 2 - Switch Ethernet";
var re_xSetup_InfoTxt8 ="Porte 1-4 - Acces point";
var re_xSetup_InfoTxt9 ="Porte 5-24 - Dekstop e computer";
var re_xSetup_InfoTxt10 ="Porte high-speed 1 e 2 - Switch Ethernet";
var re_xSetup_InfoTxt11 ="Porte high-speed 1-8 - Server";
var re_xSetup_InfoTxt12 ="Porte high-speed 9-12 - Switch Ethernet";

var re_xSetup_InfoChkBox1 ="Si, attiva i ruoli porta e visualizza la finestra di dialogo Smartport";
var re_xSetup_InfoChkBox2 ="No grazie";

var re_xSetup_InfoErrMsg1 ="� stato fatto clic su Invia senza avere selezionato un'opzione";
var re_xSetup_InfoPageTtl ="Informazioni Smartports";

//recovery mode page
var re_xSetup_RecTtl ="Ripristino software";
var re_xSetup_RecRadio1 ="Cancella la configurazione del sistema.";
var re_xSetup_RecRadio2 ="Avvia con l'immagine IOS predefinita di fabbrica.";
var re_xSetup_RecRadio3 ="Cancella configurazione sistema e Avvia con l'immagine IOS predefinita di fabbrica.";

var re_xSetup_RecConfMsg1 ="Verranno cancellate tutte le impostazioni personalizzate dello switch, compresi gli indirizzi IP, ma il riavvio sar� effettuato con la versione corrente. Fare clic su OK per continuare.";
var re_xSetup_RecConfMsg2 ="Verranno mantenute tutte le impostazioni personalizzate dello switch (compresi gli indirizzi IP) e il riavvio sar� effettuato con il software predefinito di fabbrica. Fare clic su OK per continuare.";
var re_xSetup_RecConfMsg3 ="Verranno cancellate tutte le impostazioni personalizzate dello switch (compresi gli indirizzi IP), e il riavvio sar� effettuato con il software predefinito di fabbrica. Fare clic su OK per continuare.";
var re_xSetup_RecConfMsgTtl ="Avviso";

var re_xSetup_RecTxt1 ="Lo switch sar� riavviato. Usare Express Setup per assegnare un indirizzo IP allo switch. Consultare la guida introduttiva per le procedure.";
var re_xSetup_RecTxt2 ="Lo switch sar� riavviato. Immettere l'indirizzo IP dello switch nel browser per visualizzare il device manager.";

//non-macchiato
var re_xSetup_LblMgmtInt ="VLAN di gestione";
var re_xSetup_LblSwPwd ="Password switch";
var re_xSetup_LblConfirmSwPwd ="Conferma password switch";
var re_xSetup_LblTelnet ="Accesso Telnet";
var re_xSetup_LblTelnetPwd ="Password Telnet";
var re_xSetup_LblConfTelnetPwd ="Conferma password Telnet";
var re_xSetup_LblSnmp ="SNMP";
var re_xSetup_LblSnmpRead ="SNMP Community di lettura";
var re_xSetup_LblSnmpWrite ="SNMP Community di scrittura";
var re_xSetup_LblSysContact ="Contatto";
var re_xSetup_LblSysLocation ="Posizione";
var re_xSetup_LblDisable ="Disattiva";

var re_xSetup_Txt1 ="Reindirizzamento al nuovo indirizzo IP�";

var re_xSetup_ErrMsg3 ="Errore:\n\nGli indirizzi IP 10.0.0.1 e 10.0.0.3 non possono essere usati in modalit� Express Setup.";
var re_xSetup_ErrMsg5 ="Errore:\n\nLa password dello Switch non pu� iniziare n� terminare con uno spazio.";
var re_xSetup_ErrMsg6 ="Errore:\n\nLa password Telnet non pu� iniziare n� terminare con uno spazio.";
var re_xSetup_ErrMsg7 ="Errore:\n\nLa password dello Switch pu� iniziare con un numero e contenere spazi e le maiuscole e le minuscole sono considerate come lettere diverse. Non pu� contenere punti interrogativi o caratteri di tabulazione.";
var re_xSetup_ErrMsg8 ="Errore:\n\nImmettere la stessa Password nei campi Password e Conferma Password.";
var re_xSetup_ErrMsg10 ="Errore:\n\nIl nome del contatto non pu� contenere punti interrogativi o caratteri di tabulazione.";
var re_xSetup_ErrMsg11 ="Errore:\n\nLa posizione non pu� contenere punti interrogativi o caratteri di tabulazione.";
var re_xSetup_ErrMsg12 ="Errore:\n\nSe si attiva l'accesso via Telnet � necessario immettere una password Telnet. La password Telnet non pu� contenere punti interrogativi o caratteri di tabulazione.";
var re_xSetup_ErrMsg13 ="Errore:\n\nLa password Telnet pu� iniziare con un numero e contenere spazi e in essa le maiuscole e le minuscole sono considerate come lettere diverse. Non pu� contenere punti interrogativi o caratteri di tabulazione.";
var re_xSetup_ErrMsg14 ="Errore:\n\nImmettere la stessa Password nei campi Password e Conferma Password.";
var re_xSetup_ErrMsg15 ="Errore:\n\nSe si attiva L'SNMP � necessario immettere una community string in almeno uno dei campi SNMP corrispondenti.";
var re_xSetup_ErrMsg16 ="Errore:\n\nImmettere una community string SNMP senza fare uso di punti interrogativi, spazi o caratteri di tabulazione.";
var re_xSetup_ErrMsg17 ="Errore:\n\nLe community string SNMP di Lettura e Scrittura non possono essere uguali.";
var re_xSetup_ErrMsg19 ="Errore:\n\nLa password dello Switch pu� contenere fino a 25 caratteri alfanumerici.";
var re_xSetup_ErrMsg20 ="Errore:\n\nLa password Telnet pu� contenere fino a 25 caratteri alfanumerici.";
var re_xSetup_ErrMsg24 ="Errore:\n\n{0}\non � un indirizzo IP valido per il gateway predefinito.";

var re_xSetup_WngMsg1 ="Avviso:\n\nPrima di immettere una password Telnet si deve attivare l�accesso via Telnet.";
var re_xSetup_WngMsg2 ="Avviso:\n\nPrima di immettere community string di lettura/scrittura si deve attivare il protocollo SNMP.";
var re_xSetup_WngMsg3 ="Avviso:\n\nPrima di inserire la posizione e il contatto si deve attivare il protocollo SNMP.";

var re_xSetup_ConfMsg1 ="Avviso:\n\nL'indirizzo IP di questo dispositivo verr� cambiato.\nSi potrebbe perdere la connettivit� al dispositivo.\nContinuare?";
var re_xSetup_ConfMsg4 ="Avviso:\n\nLo Switch � privo di password. Continuare?";
var re_xSetup_ConfMsg5 ="Avviso:\n\nL'indirizzo IP {0} � in conflitto con l�indirizzo/i IP gi� \nconfigurato/i della/e seguente interfaccia/e \n\nInterfaccia \tIndirizzo IP \tNetmask\n{1}\nL'indirizzo IP della/e interfaccia/e suddetta/e sar� rimosso per configurare \nl'Indirizzo IP {2} sull'interfaccia VLAN {3}.\n\nSi desidera procedere?";


//new strings
var re_xSetup_Grp1Tt3="Ipostazioni controller wireless";
var re_xSetup_LblCtrllerStackNumber="Numero{\n}Stack";
var re_xSetup_LblCtrllerVlan="ID VLAN{\n}di gestione";

var re_xSetup_ErrMsg27="Errore\n\nImmettere un indirizzo IP per il controller.";
var re_xSetup_ErrMsg28="Errore\n\nImmettere un gateway predefinito per il controller.";
var re_xSetup_ErrMsg29="Errore:\n\nL�indirizzo IP del controller e del gateway predefinito non possono essere uguali.";
var re_xSetup_ErrMsg30="Errore:\n\nL�indirizzo IP del controller e del gateway predefinito devono appartenere alla stessa subnet.";
var re_xSetup_ErrMsg31="Errore:\n\nImmettere un VLAN ID compreso tra 1 e 1001 per il controller.";
var re_xSetup_ErrMsg32="Errore:\n\nImmettere un VLAN ID compreso tra 1 e 1001 per il controller {0}.";
var re_xSetup_ErrMsg33="Errore:\n\nImmettere un VLAN ID compreso tra 1 e 1001 per il controller {0}.";
var re_xSetup_ErrMsg34="Errore\n\nImmettere un indirizzo IP per il controller {0}.";
//var re_xSetup_ErrMsg35="Errore:\n\n\"{0}\" non � un indirizzo IP valido. Immettere l�indirizzo IP nel formato x.x.x.x, nel quale ogni x pu� essere qualsiasi numero compreso tra 0 e 255.";
var re_xSetup_ErrMsg36="Errore:\n\n{0}\non � un indirizzo IP valido.";
var re_xSetup_ErrMsg37="Errore:\n\nImmettere un gateway predefinito per il controller {0}.";
//var re_xSetup_ErrMsg38="Errore:\n\n\"{0}\" non � un indirizzo IP valido per il gateway predefinito.\nImmettere l�indirizzo IP nel formato x.x.x.x, nel quale ogni x pu� essere qualsiasi numero compreso tra 0 e 255.";
var re_xSetup_ErrMsg39="Errore:\n\nL�indirizzo IP del controller {0} e del gateway predefinito non possono essere uguali.";
var re_xSetup_ErrMsg40="Errore:\n\nL�indirizzo IP del controller {0} e del gateway predefinito devono appartenere alla stessa subnet.";
//var re_xSetup_ErrMsg41="Errore:\n\n{0}\non � un indirizzo IP valido per il gateway predefinito.";

var re_xSetup_ErrMsg42 ="Errore:\n\nGli indirizzi IP nella rete {0} non possono essere configurati su questo switch.";
var re_xSetup_ErrMsg43 ="Errore;\n\nAllo switch � assegnato un nome utente ma non una password. Immettere una password.";
var re_xSetup_ErrMsg44 ="Errore;\n\nAllo switch � assegnata una password ma non un nome utente. Immettere nome utente.";
var re_xSetup_ErrMsg45 ="Avviso:\n\nAllo switch non sono stati assegnati nome utente e password.\nContinuare?";
var re_xSetup_ErrMsg46 ="Errore:\n\nLa password non pu� iniziare n� terminare con uno spazio.";
var re_xSetup_ErrMsg47 ="Errore:\n\nImmettere un nome utente. Il nome pu� contenere fino a 64 caratteri alfanumerici\n e non pu� contenere punti interrogativi, spazi o caratteri di tabulazione.";
var re_xSetup_ErrMsg48 ="Errore:\n\nLa password pu� iniziare con un numero e contenere spazi ma non punti interrogativi e caratteri di tabulazione, e in essa le maiuscole e le minuscole sono considerate come lettere diverse.";
var re_xSetup_ErrMsg49 ="Errore:\n\nImmettere la stessa Password nei campi Password e Conferma Password.";
var re_xSetup_ErrMsg50 ="Errore:\n\nLa password pu� contenere fino a 25 caratteri alfanumerici.";
var re_xSetup_ErrMsg51 ="Errore:\n\nLa VLAN {0} non � disponibile. Immettere un altro VLAN ID.";
var re_xSetup_ErrMsg52 ="Sar� negoziato dal DHCP";

//additional strings - 03/06/06
var re_xSetup_ErrMsg53  = "Il nome utente non pu� contenere lettere che non fanno parte dell'alfabeto inglese.";
var re_xSetup_ErrMsg54  = "La password non pu� contenere lettere che non fanno parte dell'alfabeto inglese.";
var re_xSetup_ErrMsg55  = "Il nome host non pu� contenere lettere che non fanno parte dell'alfabeto inglese.";
var re_xSetup_ErrMsg56  = "La password telnet non pu� contenere lettere che non fanno parte dell'alfabeto inglese.";
var re_xSetup_ErrMsg57  = "La community string SNMP non pu� contenere lettere che non fanno parte dell'alfabeto inglese.";
var re_xSetup_ErrMsg58  = "Il contatto non pu� contenere lettere che non fanno parte dell'alfabeto inglese.";
var re_xSetup_ErrMsg59  = "La posizione non pu� contenere lettere che non fanno parte dell'alfabeto inglese.";

var re_xSetup_ConfMsg14 = "Avviso:\n\nL'assegnazione di una nuova password Telnet determina la modifica dell'accesso locale o TACACS a Telnet. Continuare?";

//New error message for hostname and username and password fields. 11/11/09
var re_xSetup_ErrMsg76 = "Errore:\n\nimmettere un nome utente. Il nome pu� essere composto da un massimo di 64 caratteri alfanumerici.\nPu� contenere solo i caratteri A-Z, a-z, 0-9, trattino, trattino basso e punto.";
var re_xSetup_ErrMsg77 = "Errore:\n\nla password pu� iniziare con un numero e in essa le maiuscole e le minuscole sono considerate come lettere diverse.\nPu� contenere solo i caratteri A-Z, a-z, 0-9, trattino, trattino basso e punto.";
var re_xSetup_ErrMsg78 = "Errore:\n\nil nome host pu� contenere solo i caratteri A-Z, a-z, 0-9, trattino, trattino basso e punto.";
var re_xSetup_ErrMsg80 = "Errore:\n\n {0} non � una password valida.";

//for PSIRT
var re_xSetup_ErrMsg85 = "Immettere un nome utente. Esso pu� contenere fino a 64 caratteri alfanumerici. Non deve contenere punti interrogativi, spazi o caratteri di tabulazione.";
var re_xSetup_ErrMsg86 = "Il nome utente non pu� essere uguale a quello predefinito.";
var re_xSetup_ErrMsg87 = "Immettere una password dello switch. La password dello switch pu� iniziare con un numero e contenere spazi. \nLe maiuscole e le minuscole sono considerate come lettere diverse. Non pu� contenere punti interrogativi, caratteri di tabulazione o singole cifre.";
var re_xSetup_ErrMsg88 = "La password dello switch non pu� essere uguale a quella predefinita.";

//For mtu 11/11/09
var re_xSetup_LblMtu = "MTU";
var re_xSetup_LblMtuJumbo = "MTU Jumbo";
var re_xSetup_LblMtuRouting = "MTU di routing";
var re_xSetup_ErrMsg89 = "Immettere dimensioni MTU valide comprese tra {0} e {1}.";
var re_xSetup_ErrMsg90 = "Immettere dimensioni MTU Jumbo valide comprese tra {0} e {1}.";
var re_xSetup_ErrMsg91 = "Immettere dimensioni MTU di routing valide comprese tra {0} e {1}.";
var re_xSetup_ConfMsg16 = "La modifica alle dimensioni MTU non verr� elaborata fino al caricamento successivo. Procedere?";
var re_xSetup_ConfMsg17 = "La modifica delle dimensioni MTU Jumbo non verr� elaborata fino al caricamento successivo. Procedere?";

var re_xSetup_ReloadWaitMsg = "Attendere. Lo switch non ha completato il processo di riavvio.";
var re_xSetup_ErrMsg67 = "Attendere. � in corso il riavvio dello switch.";

//For Stout 11/11/09
var re_xSetup_tab_Lbl1 = "Impostazioni di base";
var re_xSetup_tab_Lbl2 = "Impostazioni avanzate";
var re_xSetup_Grp1Tt4 = "Impostazioni della porta di gestione Ethernet";
var re_xSetup_Fa0IPBalloonHelp = "Se la stazione di gestione � collegata tramite la porta (Fa0) di gestione Ethernet, immettere un indirizzo IP per la porta.";
var re_xSetup_Fa0IPBalloonHelp_lightsabre="Indirizzo IP relativo alla porta (Fa0) di gestione Ethernet.";

var re_xSetup_VlanIPBalloonHelp = "Se la stazione di gestione � collegata a una porta di rete, immettere un indirizzo IP per l�interfaccia di gestione VLAN (ID VLAN {0}).";

//Added during Surge xsetup support 3rd May'10
var re_xSetup_ErrMsg92 = "Errore:\n\nInserire una password. La password per lo switch pu� contenere fino a 25 caratteri alfanumerici, pu� iniziare con un numero, contenere spazi al suo interno e distingue tra maiuscole e minuscole. La password non pu� essere di un'unica cifra e non pu� contenere ? o tab e non pu� iniziare o finire con uno spazio.";
var re_xSetup_ErrMsg93 = "Errore:\n\n {0} non � una password valida. La password per lo switch pu� contenere fino a 25 caratteri alfanumerici, pu� iniziare con un numero, contenere spazi al suo interno e distingue tra maiuscole e minuscole. La password non pu� essere di un'unica cifra e non pu� contenere ? o tab e non pu� iniziare o finire con uno spazio.";
