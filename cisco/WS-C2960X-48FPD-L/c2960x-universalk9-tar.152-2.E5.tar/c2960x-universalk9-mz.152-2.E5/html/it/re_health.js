/*
 *------------------------------------------------------------------
 * health resource file
 * Copyright (c) 2006, 2010 by cisco Systems, Inc.
 *------------------------------------------------------------------
*/
// NOTE: This file is shared by dashboard and trends page.


//Title
var re_trend_ScrTtl="Trend";

//Resource content for dashboard
var re_trend_ports_Lbl="Porte";
var re_trend_viewtrends_Lbl="Visualizza trend";

//Table header
var re_trend_TblHeader1="Stato di salute dello switch";
var re_trend_TblHeader2="Utilizzo delle porte";
var re_trend_TblHeader3="Errori e utilizzo delle porte";
var re_trend_title_Lbl="Titolo";


//Table content
var re_trend_bandutil_Lbl="Utilizzo della larghezza di banda";
var re_trend_stkbandutil_Lbl="Utilizzo della larghezza di banda dello stack";
var re_trend_packeterr_Lbl="Errori di trasmissione";
var re_trend_stkpacketerr_Lbl="Errori di trasmissione dello stack";
var re_trend_inpwrutil_Lbl="Utilizzo alimentazione in linea";
var re_trend_poeutil_Lbl="Utilizzo di PoE";
var re_trend_timeslot_Lbl="Intervallo di tempo";
var re_trend_pwrutil_Lbl="Utilizzo di corrente";

var re_trend_recutil_Lbl="Utilizzo in ricezione";
var re_trend_transutil_Lbl="Utilizzo in trasmissione";
var re_trend_receive_Lbl="Ricezione";
var re_trend_transmit_Lbl="Trasmissione";


//Tooltip
var re_trend_TltpLbl4="Utilizzo";

//link
var re_trend_viewportstat_Lbl="Visualizza statistiche";

var re_trend_sec_Lbl="secondi";
var re_trend_min_Lbl="minuti";
var re_trend_hrs_Lbl="ore";
var re_trend_day_Lbl="giorni";

var re_trend_ls_Lbl="Ultimi 60 secondi";
var re_trend_lm_Lbl="Ultimi 60 minuti";
var re_trend_lh_Lbl="Ultime 24 ore";
var re_trend_ld_Lbl="Ultimi 14 giorni";

var re_trend_rfsh_Lbl="Ciclo di aggiornamento";
var re_trend_porterr_Lbl="Errori sulle porte";
var re_trend_port_Lbl="Porta";

//non-macchiato
var re_trend_connport_Lbl="Porta collegata";
var re_trend_noport_Txt="Nessuna porta collegata per questo dispositivo";
