/*
 *------------------------------------------------------------------
 * smartports resource file
 * Copyright (c) 2006, 2010 by cisco Systems, Inc.
 * feature code - sPort
 *------------------------------------------------------------------
*/

//macchiato
var re_sPort_Scr1Ttl ="Smartports";
var re_sPort_Scr2Ttl ="Smartports: personalizzazione";

var re_sPort_Txt1Mach ="Seleziona ruolo";
var re_sPort_Txt2Mach ="Fare clic su una porta per applicare il ruolo selezionato";
var re_sPort_AllPortsChkBoxMach ="Applica il ruolo selezionato a tutte le porte.";

var re_sPort_Txt3 ="Spostare il puntatore sulle porte per ulteriori informazioni";
var re_sPort_Btn1 ="Personalizza�";

var re_sPort_LblPort ="Porta";
var re_sPort_LblRole ="Ruolo";
var re_sPort_LblNatVlan ="VLAN nativa";
var re_sPort_LblAccVlan ="VLAN di accesso";
var re_sPort_LblVoiceVlan ="VLAN voce";
var re_sPort_LblServerType ="Tipo di server";

var re_sPort_ErrMsg8Mach ="Le porte {0} sono connesse a dispositivi non desktop e non possono essere applicate al ruolo Desktop.";
var re_sPort_ErrMsg9 ="Si deve prima selezionare un ruolo dal campo Seleziona ruolo.";
var re_sPort_ErrMsg10 ="La porta {0} fa parte di un EtherChannel. Rimuovere la porta dall'Etherchannel prima di cambiarne il ruolo.";
var re_sPort_ErrMsg11 ="La VLAN Cisco-Guest deve esistere prima dell'applicazione del ruolo Guest alla porta. Creare la VLAN Cisco-Guest.";
var re_sPort_ErrMsg12 ="La VLAN Cisco-Voice deve esistere prima dell'applicazione del ruolo di IP Phone+Desktop alla porta. Creare la VLAN Cisco-Voice.";
var re_sPort_ErrMsg13 ="La porta {0} deve fare parte della VLAN Cisco-Guest.";
var re_sPort_ErrMsg14 ="La porta {0} deve fare parte della VLAN Cisco-Guest. Creare questa VLAN se ancora non esiste.";
var re_sPort_ErrMsg15 ="La porta {0} deve fare parte della VLAN Cisco-Voice.";
var re_sPort_ErrMsg16 ="La porta {0} deve fare parte della VLAN Cisco-Voice. Creare questa VLAN se ancora non esiste.";
var re_sPort_ErrMsg17 ="Soltanto le porte con ruolo di IP Phone+Desktop possono fare parte della VLAN Cisco-Voice.";
var re_sPort_ErrMsg18 ="Soltanto le porte applicate con ruolo di porta Guest possono fare parte della VLAN Cisco-Guest.";
var re_sPort_ErrMsg19 ="Le porte applicate con ruolo Guest devono essere assegnate alla VLAN Cisco-Guest. Le porte applicate con ruolo IP Phone +Desktop devono essere assegnate alla VLAN Cisco-Voice. Queste VLAN devono essere presenti prima di applicare questi ruoli alle porte.";
var re_sPort_ErrMsg20 ="Le porte {0} devono fare parte della VLAN Cisco-Guest. Creare questa VLAN se ancora non esiste.";
var re_sPort_ErrMsg21 ="Le porte {0} devono fare parte della VLAN Cisco-Voice. Creare questa VLAN se ancora non esiste.";
var re_sPort_ErrMsg22 ="Quando la stazione di gestione della rete � connessa direttamente a una porta switch, e il LED SETUP � verde, non � possibile cambiare il ruolo della porta o le impostazioni di VLAN di tale porta.";

var re_sPort_WngMsg1 ="La porta {0} � assegnata a una VLAN non esistente. La porta sar� assegnata alla VLAN di gestione predefinita.";

//non-macchiato
var re_sPort_Grp1Ttl ="Configurazione raccomandata del sistema";
var re_sPort_Grp2Ttl ="Configurazione raccomandata delle porte";

var re_sPort_GlblChkBox ="Attiva";
var re_sPort_AllPortsChkBox ="Applicare l'impostazione porte selezionata a tutte le porte";
var re_sPort_Txt1 ="Seleziona un'impostazione porte";
var re_sPort_Txt2 ="Fare clic su una porta per attivare l'impostazione porte selezionata";

//tooltip
var re_sPort_LblSetup ="Impostazione";

//customize table
var re_sPort_LblSetupType ="Tipo di impostazione";

//error messages
var re_sPort_ErrMsg1 ="� stato selezionato Personalizza senza configurare l'impostazione delle porte.";
var re_sPort_ErrMsg2 ="Il VLAN ID pu� contenere solo numeri interi. Immettere un VLAN ID valido.";
var re_sPort_ErrMsg3 ="Prima di fare clic su Fatto si deve immettere un VLAN ID.";
var re_sPort_ErrMsg4 ="{0} non � un VLAN ID valido. Immettere un VLAN ID compreso tra 1 e 1001 o tra 1006 e 4094.";
var re_sPort_ErrMsg5 ="{0} non � un VLAN ID valido. Inserire un valore compreso tra 1 e 1001";
var re_sPort_ErrMsg6 ="Il dispositivo si trova in modalit� client VTP e le nuove VLAN non possono essere create in questa modalit�";
var re_sPort_ErrMsg7 ="Il numero massimo di VLAN supportate da questo dispositivo � {0}; le seguenti VLAN non possono essere utilizzate {1}";
var re_sPort_ErrMsg8 ="Le impostazioni delle connessioni Desktop non possono essere applicate alle porte {0} poich� queste sono connesse a dispositivi non desktop.";

//new strings
var re_sPort_ErrMsg23 = "Le porte con ruolo di IP Phone+Desktop dovrebbero appartenere anche alla VLAN di accesso, oltre alla VLAN Cisco-Voice.";
var re_sPort_ErrMsg24 = "Soltanto le porte applicate con ruolo di Telefono IP+Desktop o ruolo di porta Server possono fare parte della VLAN Cisco-Voice.";

//additional strings - 03/06/06
var re_sPort_ErrMsg25  = "� stato selezionato Personalizza senza configurare un ruolo porta.";
