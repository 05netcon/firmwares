/*
 *------------------------------------------------------------------
 * dashboard resource file
 * Copyright (c) 2006, 2009-2010 by cisco Systems, Inc.
 * feature code - dshBrd
 *------------------------------------------------------------------
*/

//macchiato
var re_dshBrd_Ttl ="Dashboard";

var re_dshBrd_LblHostName ="Nome host";
var re_dshBrd_LblProductID ="ID prodotto";
var re_dshBrd_LblIPAddress ="Indirizzo IP";
var re_dshBrd_LblMacAddress ="Indirizzo MAC";
var re_dshBrd_LblVersionID ="ID Versione";
var re_dshBrd_LblSNum ="Numero di serie";
var re_dshBrd_LblSoftware ="Software";
var re_dshBrd_LblContact ="Contatto";
var re_dshBrd_LblLocation ="Posizione";
var re_dshBrd_LbBwUsed ="Banda utilizzata";

var re_dshBrd_LblPktError ="Errori di trasmissione";
var re_dshBrd_LblPwrUtil ="Utilizzo di PoE";
var re_dshBrd_LblFan ="Ventola";
var re_dshBrd_LblTemp ="Temperatura";

var re_dshBrd_Txt1 ="OK";
var re_dshBrd_Txt6 ="DIFETTOSA";

var re_dshBrd_TltpBwUsed ="Banda utilizzata";
var re_dshBrd_TltpPktError ="Errori di trasmissione";
var re_dshBrd_TltpPwrUsed ="Carica utilizzata";
var re_dshBrd_TltpPwrRemain ="Carica rimanente";
var re_dshBrd_TltpFanOk ="VENTOLA OK";
var re_dshBrd_TltpFanFaulty ="VENTOLA DIFETTOSA";
var re_dshBrd_TltpTempOk ="TEMPERATURA OK";
var re_dshBrd_TltpTempFaulty ="ERRORE DI TEMPERATURA";

var re_dshBrd_Grp1Ttl ="Informazioni sullo switch";
var re_dshBrd_Grp1Tt2 ="Stato di salute dello switch";
var re_dshBrd_Grp1Tt3Mach ="Errori e utilizzo delle porte";

var re_dshBrd_Link1 ="Visualizza trend";
var re_dshBrd_Link2 ="Visualizza statistiche";

var re_dshBrd_Radio1 ="Utilizzo delle porte";
var re_dshBrd_Radio2 ="Errori sulle porte";

var re_dshBrd_ErrMsg1 ="CLI della banda non supportata. Effettuare l'aggiornamento a un'immagine IOS che la supporti.";

var re_dshBrd_GraphLegendTxt1 ="Ricezione";
var re_dshBrd_GraphLegendTxt2 ="Trasmissione";
var re_dshBrd_GraphXAxis ="Porte";

//non-macchiato
var re_dshBrd_LblType ="Tipo";
var re_dshBrd_Grp1Tt3 ="Utilizzo delle porte";
var re_dshBrd_LblStackBwUsed ="Larghezza di banda utilizzata dallo stack";
var re_dshBrd_LblStackPktError ="Errori di trasmissione dello stack";

var re_dshBrd_Txt2 ="VENTOLA 1 OK";
var re_dshBrd_Txt3 ="VENTOLA 1 DIFETTOSA";
var re_dshBrd_Txt4 ="VENTOLA 2 OK";
var re_dshBrd_Txt5 ="VENTOLA 2 DIFETTOSA";
var re_dshBrd_LblInlinePwrUtil ="Utilizzo alimentazione in linea";

//new strings
var re_dshBrd_Grp1Tt4="Informazioni controller";

//additional strings - 03/06/06
var re_dshBrd_TxtIPDHCP  = "Negoziato con DHCP";
var re_dshBrd_TltpFan1Ok  = "VENTOLA 1 OK";
var re_dshBrd_TltpFan1Faulty  = "VENTOLA 1 DIFETTOSA";
var re_dshBrd_TltpFan2Ok  = "VENTOLA 2 OK";
var re_dshBrd_TltpFan2Faulty  = "VENTOLA 2 DIFETTOSA";
var re_dshBrd_TltpTemperatureOk  = "Temperatura OK";
var re_dshBrd_TltpTemperatureFaulty  = "Errore di temperatura";
var re_dshBrd_TltpPort  = "Porta";
var re_dshBrd_TltpUtilization  = "Utilizzo";

var re_dshBrd_TxtWarning = "Avvertenza";

//Fo Stout 11/11/09
var re_dshBrd_LblEthMgmtPortIP = "Indirizzo IP porta{0}di gestione Ethernet";