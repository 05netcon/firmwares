/*
 *------------------------------------------------------------------
 * Resource file for port status
 * Copyright (c) 2006, 2010 by cisco Systems, Inc.
 *------------------------------------------------------------------
*/

//Title
var re_pStatus_ScrTtl="Stato delle porte";

//Table headers
var re_pStatus_TblHeader1="Porta";
var re_pStatus_TblHeader2="Descrizione";
var re_pStatus_TblHeader3="Stato";
var re_pStatus_TblHeader4="VLAN";
var re_pStatus_TblHeader5="Velocit�";
var re_pStatus_TblHeader6="Duplex";
var re_pStatus_TblHeader7="PoE";
var re_pStatus_TblHeader8="Auto-MDIX";
var re_pStatus_TblHeader9="Alimentazione in linea";

//Alert messages
var re_pStatus_ErrMsg1="ERRORE: la porta � in stato NULL";
var re_pStatus_ErrMsg2="Porta {0} non trovata";
