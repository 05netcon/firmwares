/*
 *------------------------------------------------------------------
 * sitewide.js
 *
 * Copyright (c) 2003-2007 by cisco Systems, Inc.
 * All rights reserved.
 *------------------------------------------------------------------
 */

var DLIM_WhSp = /[\s]+/;
var DLIM_WhSp_slash = /[\/\s]+/;
var DLIM_WhSp_comma = /[\,\s]+/;
var DLIM_WhSp_parens = /[\(\)\s]+/;
var DLIM_WhSp_colon = /[\:\s]+/;
var DLIM_newline = /[\r\n]+/;
var DLIM_nonword          = /[\W]+/;
var DLIM_nonword_period   = /[^a-zA-Z0-9_\.]+/;
var DLIM_nonword_colon    = /[^a-zA-Z0-9_:]+/;

//disable right click
document.oncontextmenu = new Function("return false");

// method to Print the page
/*
function printPage(){  
	if (top.mainFrame.window.print) {
		top.mainFrame.window.focus();
	    top.mainFrame.window.print() ;  
	} else {
	    var WebBrowser = '<OBJECT ID="WebBrowser1" WIDTH=0 HEIGHT=0 CLASSID="CLSID:8856F961-340A-11D0-A96B-00C04FD705A2"></OBJECT>';
		document.body.insertAdjacentHTML('beforeEnd', WebBrowser);
	    WebBrowser1.ExecWB(6, 2);
		
	}
}
*/


/*
 * This function converts the short interface name to long interface names
 */
function toLongPortName(intName) {

 	var GIG_SHORT_PRE = "GI";
 	var FA_SHORT_PRE = "FA";
 	var LO_SHORT_PRE = "LO";
	var TE_SHORT_PRE = "TE";
   if (intName.toUpperCase().indexOf(GIG_SHORT_PRE)!= -1) {
		return ("GigabitEthernet" + intName.substring(GIG_SHORT_PRE.length,intName.length));
	}    if (intName.toUpperCase().indexOf(FA_SHORT_PRE)!= -1) {
		return ("FastEthernet" + intName.substring(FA_SHORT_PRE.length,intName.length));
	}    if (intName.toUpperCase().indexOf(LO_SHORT_PRE)!= -1) {
		return ("LongReachEthernet" + intName.substring(LO_SHORT_PRE.length,intName.length));
	}if (intName.toUpperCase().indexOf(TE_SHORT_PRE)!= -1) {
		return ("TenGigabitEthernet" + intName.substring(TE_SHORT_PRE.length,intName.length));
	}   
} 

/*
 * This function converts the long interface name to short interface names
 */
function toShortPortName(intName) {

 	var GIG_LONG_PRE = "GIGABITETHERNET";
 	var FA_LONG_PRE = "FASTETHERNET";
 	var LO_LONG_PRE = "LONGREACHETHERNET";
   if (intName.toUpperCase().indexOf(GIG_LONG_PRE)!= -1) {
		return ("Gi" + intName.substring(GIG_LONG_PRE.length,intName.length));
	}    if (intName.toUpperCase().indexOf(FA_LONG_PRE)!= -1) {
		return ("Fa" + intName.substring(FA_LONG_PRE.length,intName.length));
	}    if (intName.toUpperCase().indexOf(LO_LONG_PRE)!= -1) {
		return ("Lo" + intName.substring(LO_LONG_PRE.length,intName.length));
	}
	return intName; 
}

// Calculate the netmask from the number of masked bits of an octet
function calcNetMaskField(numberOfBits) {
   if (numberOfBits <= 0) {
      return "0";
   } else if (numberOfBits >= 8) {
      return "255";
   } else if (numberOfBits == 7) {
      return "254";
   } else if (numberOfBits == 6) {
      return "252";
   } else if (numberOfBits == 5) {
      return "248";
   } else if (numberOfBits == 4) {
      return "240";
   } else if (numberOfBits == 3) {
      return "224";
   } else if (numberOfBits == 2) {
      return "192";
   } else if (numberOfBits == 1) {
      return "128";
   }
}


// calculate the netmask string from the masked number of bits
function calcNetMask_string(numberOfBits) {
   var subNetMask = "";
   subNetMask += calcNetMaskField(numberOfBits);
   subNetMask += ".";
   numberOfBits -= 8;
   subNetMask += calcNetMaskField(numberOfBits);
   subNetMask += ".";
   numberOfBits -= 8;
   subNetMask += calcNetMaskField(numberOfBits);
   subNetMask += ".";
   numberOfBits -= 8;
   subNetMask += calcNetMaskField(numberOfBits);
   return subNetMask;
}

// calculate the netmask
function calcNetMask(numberOfBits) {
   var str;
   if (numberOfBits) {
      if (numberOfBits == "undefined") {
         document.write("unassigned");
      } else {
         str = calcNetMask_string(numberOfBits);
         document.write(str);
      }
   } else {
      document.write("unassigned");
   }
}

/// to split the string with the specified delimiter
function split (delimiter, string) { 
   if(string=="" || string==null) return "";
   var localstring = string;
   var word = localstring.split(delimiter);
   if (word.length>1) {
      
      while ((word.length>1)&&(word[0]=="")) {
         localstring = localstring.substr(1);
         word = localstring.split(delimiter);
      }
      
      while ((word.length>1)&&word[word.length-1]=="") {
         localstring = localstring.substr(0,localstring.length-1);
         word = localstring.split(delimiter);
      }
   }
   return word;
}

// will return the token at the index specified,
// string will be splitted with the delimiter specified
function token_string (delimiter, index, string) {
	if(string=="" || string==null) return ""; 
    var tok = null;
	var index;
	var backindex;
    var word = split(delimiter, string);
    var last_token = word.length - 1;
    if (index >= 0) {
       if (index <= last_token) {
          tok = word[index]; 
       }
    } else {
       backindex = last_token + index + 1;
       if (backindex >= 0) {
          tok = word[backindex]; 
       }
    }
    return tok;
}

//trim_string method matches spaces at beginning and end of text and replace
//with null strings
function trim_string(string){ 
	if (string == null) return;
  return string.replace(/^\s+/,'').replace(/\s+$/,'');
} 

// compact_line method removes multiple spaces between words
// this will not remove the space at the start and end of the line
// for that pass the retunr value of this method to trim_string.
// O/p of the call compact_line("   The    line to   be compacted   "); will be
// " The line to be compacted "
function compact_line(line){ 
  return line.replace(/\s+/g,' ');
} 

// grep_string returns the first line that contains the pattern
function grep_string (pattern, string) {
   if(string=="" || string==null) return "";	
   var line = split(DLIM_newline, string);
   for (var curline = 0; curline < line.length; curline++) {
      if (-1 != line[curline].search(pattern)) {
          return line[curline];
      }
   }
}

// grep_string returns the first line that contains the pattern
function grep_string_patternArrray (pattern, string) {
   if(string=="" || string==null) return "";	
   var line = split(DLIM_newline, string);
   for (var curline = 0; curline < line.length; curline++) {
   	
   	  if (-1 != line[curline].search(pattern[0])) {
	  	var Found = CheckPatternArray(pattern,line[curline]);
		if(Found){
			return line[curline];
		}
          
      }
	  
   }
}
function CheckPatternArray(pattern,line){
	var fndIndex =0;
	for(var ptrnIndex=0;ptrnIndex<pattern.length;ptrnIndex++){
		if(line.search(pattern[ptrnIndex]) != -1){
			fndIndex++;
		}
	}
	if(fndIndex == pattern.length){
		return true;
	}
	return false;

}

// grep_string writes the first line that contains the pattern
function grep (pattern, string) {
   if(string=="" || string==null) return "";
   var line = grep_string(pattern, string);
   if (line) {
      document.write(line);
   }
}

// grep_string returns all the lines that contains the pattern
function multi_grep_string (pattern, string) {
   if(string=="" || string==null) return "";
   var result = new Array();
   var i = 0;
   var line = string.split(DLIM_newline);
   for (var curline = 0; curline < line.length; curline++) {
      if (-1 != line[curline].search(pattern)) {
         result[i] = line[curline];
         i += 1;
      }
   }
   return result;
}

// find_string finds the first line matching the pattern and then
// returns token at the specified index after splitting with the delimiter
function find_string (pattern, delimiter, index, string) {
   if(string=="" || string==null) return "";	
   var line = grep_string(pattern, string);
   if (line) {
      tok = token_string(delimiter, index, line);
      if (tok) {
          return tok;
      }
   }
}

// token_string_label_blank will return the string between the label and the end of line
function token_string_label_to_eol(label, string)
{
   if(string=="" || string==null) return "";	
   if (string) {
      match = string.search(label);
      if (-1 != match) {
         remainder = string.substring(match+label.length);
         tok = token_string(DLIM_newline, 0, remainder);
         if (tok)
            return tok;
      }
   }
}

// makeArray creates an array with the specified size.
function makeArray(n){
  this.length = n;
  return this;
}

function FAQ(faqTxt, faqTag) {
	return new Option(faqTxt, faqTag);
}

/*
 * This function extracts the port number from the interface name
 * parameters: intName - interface name, option - method to be used to extract the number
 * options: 1 - loop from end of the name, 2 - loop forward in the name, 3 - extract all numbers in a name, null - use option 1
 * enhanced to show and hide the quick tip.
 */
function getPortNumber(intName, option) {
	if(intName == null) {
		return;
	}
	intName = trim_string(intName);
	if(intName == "") {
		return;
	}
	var portNumber = "";
	if(option == 1 || option == null || option == "") {
		for(var i=intName.length-1; i>=0; i--) {
			var temp = intName.charAt(i);
			if(!isNaN(parseInt(temp))) {
				portNumber = temp + portNumber;
			}
			else {
				break;
			}
		}
	}
	else if(option == 2) {
		for(var i=0; i<intName.length; i++) {
			var temp = intName.charAt(i);
			if(!isNaN(parseInt(temp))) {
				portNumber += temp;
			}
			else {
				break;
			}
		}
	}
	else if(option == 3) {
		portNumber = intName.match(/[0-9]/g).join("");
	}
	
	return portNumber;
}

function replaceSpecialChars(str)
{
	if ( str == null ) return;
	return str.replace(/&/g,"&#38").replace(/</g, "&#60;").replace(/>/g, "&#62;");
}

function replaceParams(strToReplace, replacableStrArray) {
	if(strToReplace == null || replacableStrArray == null) {
		return null;
	}
	var paramSearch ;
	for(var i=0; i<replacableStrArray.length; i++) {
		paramSearch = "{" + i + "}";
		strToReplace = strToReplace.replace(paramSearch, replacableStrArray[i]);
	}
	return strToReplace;
}

function replaceString(strToReplace, replacableStr) {
	if(strToReplace == null || replacableStr == null) {
		return null;
	}
	var replacedStr;
	replacedStr = strToReplace.replace("{0}", replacableStr);
	return replacedStr;
}

function replaceTags(strToReplace, replacableStrArray) {
	if(strToReplace == null || replacableStrArray == null) {
		return null;
	}
	var re = /{[^}]+}/ig;
	var strMatch = strToReplace.match(re);
	for(var i=0; i<strMatch.length; i++) {
		if(replacableStrArray[i] != null)
			strToReplace = strToReplace.replace(strMatch[i], replacableStrArray[i].replace("><", ">" + strMatch[i].replace(/{|}/g, "") + "<"))
	}
	
	return strToReplace;
}

function doesStringHasUcodeChar(stringtoCheck)
{
	if (stringtoCheck==null) return;
	for (var index = 0; index< stringtoCheck.length; index++)
	{
		if ( stringtoCheck.charCodeAt(index) > 255 ) return true;
	}
	return false;
}

function localizeUptime(str)
{
	if (str==null || top.resourceFrame==null) return;
	var uptime = str.toLowerCase();
	var singularUnits = new Array("year", "week", "day", "hour", "minute");
	var singularResource = new Array(top.resourceFrame.re_Uptime_year,top.resourceFrame.re_Uptime_week,top.resourceFrame.re_Uptime_day,top.resourceFrame.re_Uptime_hour, top.resourceFrame.re_Uptime_minute);
	var pluralUnits = new Array("years", "weeks", "days", "hours", "minutes");
	var pluralResource = new Array(top.resourceFrame.re_Uptime_years,top.resourceFrame.re_Uptime_weeks,top.resourceFrame.re_Uptime_days,top.resourceFrame.re_Uptime_hours, top.resourceFrame.re_Uptime_minutes);
	for (var i=0; i<pluralUnits.length; i++)
	{
			if (uptime.indexOf(pluralUnits[i]) != -1)
			{
				uptime = uptime.replace(pluralUnits[i], pluralResource[i])
			}
			else if (uptime.indexOf(singularUnits[i]) != -1)
			{
				uptime = uptime.replace(singularUnits[i], singularResource[i])
			}
	}
	return uptime;
}

function StringBuffer() { 
   this.buffer = []; 
 } 

 StringBuffer.prototype.append = function append(string) { 
   this.buffer.push(string); 
   return this; 
 }; 

 StringBuffer.prototype.toString = function toString() { 
   return this.buffer.join(""); 
 }; 

 /*
 * This function set the embedded help text in a screen
 */
 
function setHelpText(helpText) {
	document.writeln('\
						<table border=0 cellspacing="0" cellpadding="0"> <tr>');
	document.writeln('\
						<td class="xpcontent">');						
	document.writeln(helpText);
	
	document.writeln('\
						</td> </tr> </table>');				
}