/*
 *------------------------------------------------------------------
 * software upgrade resource file
 * Copyright (c) 2006-2007 by cisco Systems, Inc.
 * feature code - swUpg
 *------------------------------------------------------------------
*/

//macchiato

var re_swUpg_Ttl = "Software Upgrade";
var re_swUpg_Btn1 = "Upgrade";

var re_swUpg_Txt1 = "The switch is running Cisco IOS software release";
var re_swUpg_Txt2 = "Go to {0} to find the latest Cisco IOS software (in tar file format) for the switch.";
var re_swUpg_Txt3 = "Download the tar file to your PC or to a network drive.";
var re_swUpg_Txt4 = "Select the tar file to upgrade using the Browse... button.";
var re_swUpg_Txt5 = "Click Upgrade.";

var re_swUpg_FileBrowse = "Image File Name";

var re_swUpg_Grp1Ttl = "Status";
var re_swUpg_TblHeader1Mach = "Stage";
var re_swUpg_TblHeader2Mach = "File Size";

var re_swUpg_ConfMsg1 = "Warning:\n\nYou are about to upgrade the switch software. Do not use or close this\nbrowser session until after the upgrade process completes. After the\nupgrade process completes, close this browser session, and display the\ndevice manager from a new browser session.\n\nClick OK to continue with the upgrade process, or click Cancel to exit\nthe upgrade process";

var re_swUpg_ErrMsg1 = "Error:\n\nClick Browse to navigate to the switch image file (tar file) on your PC.";
var re_swUpg_ErrMsg2 = "Error: The switch software upgrade is in progress in another session";
var re_swUpg_ErrMsg3 = "Software Upgrade is in Progress!";

var re_swUpg_Txt_Stage1Mach = "Loading the tar file to the switch";
var re_swUpg_Txt_Stage2Mach = "Tar file loaded";
var re_swUpg_Txt_Stage3Mach = "Reload Pending";
var re_swUpg_Txt_Stage4Mach = "Upgrade Failed";

var re_swUpg_Txt_ImageInstalled = "New software image installed. Reloading the device.{0}Please wait! It may take up to 5 minutes to resume connection.";
var re_swUpg_Txt_UpgInComplete = "Switch is not yet reloaded, device manager is waiting for a response from the device.";
var re_swUpg_Txt_UpgComplete = "The switch software is upgraded. To use the latest software, end your current device manager session and start a new device manager session.";
var re_swUpg_Txt_ArchiveStatusMsg = "The software has been upgraded successfully. To use the latest software, end your current device manager session and start a new device manager session.";

var re_swUpg_ErrMsg4 = "Error: Previous upgrade was unsuccessful or aborted. Clean-up is not done";
var re_swUpg_ErrMsg5 = "Error: There is not enough memory on the switch to install the new software image.";
var re_swUpg_ErrMsg6 = "Error: The file is not a valid Cisco IOS tar file.";
var re_swUpg_ErrMsg7 = "Error: The software image file is not appropriate for this switch.";
var re_swUpg_ErrMsg8 = "Error: The software image file is corrupted. Download the software image file from Cisco.com again.";
var re_swUpg_ErrMsg9 = "Error: There is not enough memory on the switch to examine the new software image.";
var re_swUpg_ErrMsg10 = "Error: File does not exist";
var re_swUpg_ErrMsg11 = "Error: Unable to extract image.";
var re_swUpg_ErrMsg12 = "Error: Undefined";


//non-macchiato
var re_swUpg_TblHeader1 = "Stage";
var re_swUpg_TblHeader2 = "Status";

var re_swUpg_Txt_Stage1 = "1. Loading the tar file to the switch";
var re_swUpg_Txt_Stage2 = "2. Verifying the tar file";
var re_swUpg_Txt_Stage3 = "3. Extracting the software files from the tar file";
var re_swUpg_Txt_Stage4 = "4. Restarting the switch";

var re_swUpg_Txt_RestartSwitch = "Please wait! It may take up to 5 minutes to resume connection.";

//additional strings - 03/06/06
var re_swUpg_TltpInProgress = "In Progress";
var re_swUpg_TltpCompleted = "Completed";
var re_swUpg_TltpFailed = "Failed";
var re_swUpg_Txt_Stage5Mach = "Image download complete";
var re_swUpg_Txt_noUpgradeinProgress = 'No Software Upgrade is in progress.';
var re_swUpg_Txt_UpgradeInAnotherSession = 'Software upgrade is already in Progress in another session!';

//new strings - 03/28/06
var re_swUpg_ErrMsg13 = "Error: You cannot install Cisco IOS 12.2(25)FY on this switch. Upgrade the switch to Cisco IOS 12.2(25)SEG or later."; //The current software image has been removed. The switch is now reloading the factory-default software image.";
var re_swUpg_ErrMsg14 = "Error: There is not enough memory on the switch to install the new software image. The current software image has been removed. The switch is now reloading the factory-default software image.";
var re_swUpg_Txt_UcodeBoot = "The switch has been reloaded with the factory-default software image. End your current device manager session and start a new device manager session.";

var re_swUpg_ErrMsg15 = "Error: You cannot install Cisco IOS 12.2(25)FY on this switch. Upgrade the switch to Cisco IOS 12.2(25)SEG or later. The current software image has been removed. The switch is now reloading the factory-default software image.";

//mixed stack strings - 11/13/06
var re_swUpg_ErrMsg16 = "Error:\n\nSelect an image for upgrading the Catalyst 3750 switches in the switch stack.";
var re_swUpg_ErrMsg17 = "Error:\n\nSelect an image for upgrading the Catalyst 3750-E switches in the switch stack.";
var re_swUpg_ErrMsg18 = "Error:\n\nSelect two images that have the same version number.";
var re_swUpg_Txt_PartialUpgrade = "Some switches in the stack were not upgraded. Make sure you are upgrading the switches with the appropriate switch image and that each switch has enough flash space for the image. Reload the stack and run the software upgrade process again.";
var re_firmUpg_Ttl = "Firmware Upgrade";

//Rockwell Sw Upgrade Error - 6/6/2007
var re_swUpg_ErrMsg19 = "Error: Invalid firmware."; 
var re_swUpg_Txt6 = "The switch is running firmware release";
var re_swUpg_Txt7 = "Go to {0} to find the latest firmware (in tar file format) for the switch.";