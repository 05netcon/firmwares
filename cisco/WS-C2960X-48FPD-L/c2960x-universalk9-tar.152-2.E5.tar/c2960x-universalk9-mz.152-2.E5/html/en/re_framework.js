/*
 *------------------------------------------------------------------
 * framework resource file - includes SSL, bottom banner buttons, graph, appsui, telnet, network assistant
 * Copyright (c) 2006-2007 by cisco Systems, Inc.
 * feature code - frmWrk
 *------------------------------------------------------------------
*/

//feature pages
var re_frmWrk_WngMsg1 = 'You have clicked "Submit" without making any changes in the dialog box.';
var re_frmWrk_WngMsg1Ttl = "Information";

//appsui
var re_frmWrk_ErrMsgDefTtl = "Error";
var re_frmWrk_WngMsgDefTtl = "Warning";
var re_frmWrk_ConfMsgDefTtl = "Attention";

//framework
var re_frmWrk_ConfMsg1 = "Warning:\n\nThere are unsaved changes on the page.\n\nClick OK to save the changes or Cancel to discard and continue.";
var re_frmWrk_ConfMsgWindowClose = "There are unsaved changes on the page.";
//no handler messages
var re_frmWrk_ErrMsgNoApply = "No handler available for Apply.";
var re_frmWrk_ErrMsgNoCancel = "No handler available for Cancel.";
var re_frmWrk_ErrMsgNoNext = "No handler available for Next.";
var re_frmWrk_ErrMsgNoBack = "No handler available for Back.";
var re_frmWrk_ErrMsgNoFinish = "No handler available for Finish.";
var re_frmWrk_ErrMsgNoHelp = "No Help Available";

//xhome
var re_frmWrk_TxtFrmSupport = "These pages use Frames. Please make sure that the browser fully supports Frames feature!";

//graph
var re_frmWrk_GraphLegend = "Legend";

var re_frmWrk_GraphEmpty = "[empty graph]";
var re_frmWrk_GraphTimeSlots = "Time Slots";

var re_frmWrk_GraphLblDay1 = "Sun"; 
var re_frmWrk_GraphLblDay2 = "Mon"; 
var re_frmWrk_GraphLblDay3 = "Tue"; 
var re_frmWrk_GraphLblDay4 = "Wed"; 
var re_frmWrk_GraphLblDay5 = "Thu"; 
var re_frmWrk_GraphLblDay6 = "Fri"; 
var re_frmWrk_GraphLblDay7 = "Sat"; 

var re_frmWrk_GraphLblMonth1 = "Jan"; 
var re_frmWrk_GraphLblMonth2 = "Feb"; 
var re_frmWrk_GraphLblMonth3 = "Mar"; 
var re_frmWrk_GraphLblMonth4 = "Apr"; 
var re_frmWrk_GraphLblMonth5 = "May"; 
var re_frmWrk_GraphLblMonth6 = "Jun"; 
var re_frmWrk_GraphLblMonth7 = "Jul"; 
var re_frmWrk_GraphLblMonth8 = "Aug"; 
var re_frmWrk_GraphLblMonth9 = "Sep"; 
var re_frmWrk_GraphLblMonth10 = "Oct"; 
var re_frmWrk_GraphLblMonth11 = "Nov"; 
var re_frmWrk_GraphLblMonth12 = "Dec"; 

var re_frmWrk_GraphLblTimeAM = "am";
var re_frmWrk_GraphLblTimePM = "pm";
var re_frmWrk_GraphLblTitle = "Title";

//SSL dialog
var re_frmWrk_SSLTxt1 = "Do you want a secured session with the switch?";
var re_frmWrk_SSLTxt2 = "Don't ask me anymore";
var re_frmWrk_SSLBtn1 = "Yes";
var re_frmWrk_SSLBtn2 = "No";

//bottom frame button names
var re_frmWrk_BtnDone = "Done";
var re_frmWrk_BtnBack = "Back";
var re_frmWrk_BtnNext = "Next";
var re_frmWrk_BtnFinish = "Finish";
var re_frmWrk_BtnCancel = "Cancel";
var re_frmWrk_BtnRefresh = "Refresh";
var re_frmWrk_BtnHelp = "Help";
var re_frmWrk_BtnSubmit = "Submit";

//network assistant
var re_frmWrk_CNATtl = "Network Assistant";

//non-macchiato
//telnet
var re_frmWrk_TelnetTtl = "Telnet";
var re_frmWrk_TelnetTxt = "The Telnet Console provides access to the switch CLI interface. CLI is an advanced method of communication with your Cisco switch and is recommended for experts only. The Telnet Console will launch in new window.";
var re_frmWrk_TelnetLinkTxt1 = "Launch a Telnet Console";
var re_frmWrk_TelnetLinkTxt2 = "Telnet is not enabled on this device. Go to {Express Setup} to enable Telnet.";

//new Strings

//OLH message
var re_frmWrk_OLHErrMsg1 = "Information:\n\nThe online help for this window is not available in {0}. To display the online help in {0}, you must first upgrade the switch with the {0} switch software from Cisco.com.";

var re_restart_Ttl = "Restart / Reset";
var re_restart_txt1 = "Restart the switch with its current settings.";
var re_restart_txt2 = "Reset the switch to factory defaults, and then restart the switch.";
var re_restart_txt3 = "Device will be reloaded in {0} second(s).";
var re_restart_txt4 = "Device getting reloaded...";
var re_restart_txt5 = "Device reloaded successfully.";
var re_restart_txt6 = "Reload is in Progress...";
var re_restart_ConfMsg1 = "The device will reset to its factory default settings and will delete its current IP address. Do you want to continue?";
var re_toolbar_txt_refresh = "Refresh";
var re_toolbar_txt_print = "Print";
var re_toolbar_txt_smartports = "Smartports";
var re_toolbar_txt_swupgrade = "Software Upgrade";
var re_toolbar_txt_legend = "Legend";
var re_toolbar_txt_help = "Help";
var re_toolbar_txt_forward = "Forward";
var re_toolbar_txt_back = "Back";

//network assistant
var re_frmWrk_CNATxt1 = "Cisco Network Assistant offers centralized configuration and{\n}management of Cisco switches, routers and wireless access{\n}points in small and medium-size business networks.";
var re_frmWrk_CNATxt2 = "Single point of network management";
var re_frmWrk_CNATxt3 = "Intelligent configuration of devices";
var re_frmWrk_CNATxt4 = "Simplified network monitoring and troubleshooting";
var re_frmWrk_CNATxt5 = "Built-in search function and online help";
var re_frmWrk_CNATxt6 = "LEARN MORE and DOWNLOAD NETWORK ASSISTANT for FREE!";

//Strings newly added for Uptime display - 03/28/06
var re_Uptime_years = "years";
var re_Uptime_year = "year";
var re_Uptime_weeks = "weeks";
var re_Uptime_week = "week";
var re_Uptime_days = "days";
var re_Uptime_day = "day";
var re_Uptime_hours = "hours";
var re_Uptime_hour = "hour";
var re_Uptime_minutes = "minutes";
var re_Uptime_minute = "minute";

//New strings added for Houseblend (only for Tango page)
var re_frmWrk_CCATxt7 = "Cisco Configuration Assistant reduces the time and expense of network configuration and deployment, and simplifies ongoing administration and troubleshooting for small and medium-sized business networks.";
var re_frmWrk_CCATxt8 = "LEARN MORE and DOWNLOAD CISCO CONFIGURATION ASSISTANT for FREE!";

//Telnet Not supported message for Vista
var re_frmWrk_TelnetLinkTxt3 = "The Telnet feature is not available if your operating system is Windows Vista or if you are using Internet Explorer 7.0.";

