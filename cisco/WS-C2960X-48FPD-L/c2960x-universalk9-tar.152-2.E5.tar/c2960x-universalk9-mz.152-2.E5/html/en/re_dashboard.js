/*
 *------------------------------------------------------------------
 * dashboard resource file
 * Copyright (c) 2006-2007 by cisco Systems, Inc.
 * feature code - dshBrd
 *------------------------------------------------------------------
*/

//macchiato
var re_dshBrd_Ttl = "Dashboard";

var re_dshBrd_LblHostName = "Host Name";
var re_dshBrd_LblProductID = "Product ID";
var re_dshBrd_LblIPAddress = "IP Address";
var re_dshBrd_LblMacAddress = "MAC Address";
var re_dshBrd_LblVersionID = "Version ID";
var re_dshBrd_LblSNum = "Serial Number";
var re_dshBrd_LblSoftware = "Software";
var re_dshBrd_LblContact = "Contact";
var re_dshBrd_LblLocation = "Location";
var re_dshBrd_LbBwUsed = "Bandwidth Used";

var re_dshBrd_LblPktError = "Packet Error";
var re_dshBrd_LblPwrUtil = "PoE Utilization";
var re_dshBrd_LblFan = "Fan";
var re_dshBrd_LblTemp = "Temp";

var re_dshBrd_Txt1 = "OK";
var re_dshBrd_Txt6 = "FAULTY";

var re_dshBrd_TltpBwUsed = "Bandwidth Used";
var re_dshBrd_TltpPktError = "Packet Error";
var re_dshBrd_TltpPwrUsed = "Power Used";
var re_dshBrd_TltpPwrRemain = "Power Remaining";
var re_dshBrd_TltpFanOk = "FAN is OK";
var re_dshBrd_TltpFanFaulty = "FAN is FAULTY";
var re_dshBrd_TltpTempOk = "Temp is OK";
var re_dshBrd_TltpTempFaulty = "Temp is FAULTY";

var re_dshBrd_Grp1Ttl = "Switch Information";
var re_dshBrd_Grp1Tt2 = "Switch Health";
var re_dshBrd_Grp1Tt3Mach = "Port Utilization/Errors";

var re_dshBrd_Link1 = "View Trends";
var re_dshBrd_Link2 = "View Port Statistics";

var re_dshBrd_Radio1 = "Port Utilization";
var re_dshBrd_Radio2 = "Port Errors";

var re_dshBrd_ErrMsg1 = "Bandwidth CLI is not supported.  Please upgrade to an IOS image that supports.";

var re_dshBrd_GraphLegendTxt1 = "Receive";
var re_dshBrd_GraphLegendTxt2 = "Transmit";
var re_dshBrd_GraphXAxis = "Ports";

//non-macchiato
var re_dshBrd_LblType = "Type";
var re_dshBrd_Grp1Tt3 = "Port Utilization";
var re_dshBrd_LblStackBwUsed = "Stack Bandwidth Used";
var re_dshBrd_LblStackPktError = "Stack Packet Error";

var re_dshBrd_Txt2 = "FAN 1 OK";
var re_dshBrd_Txt3 = "FAN 1 FAULTY";
var re_dshBrd_Txt4 = "FAN 2 OK";
var re_dshBrd_Txt5 = "FAN 2 FAULTY";
var re_dshBrd_LblInlinePwrUtil = "Inline Power Utilization";

//new strings
var re_dshBrd_Grp1Tt4 = "Controller Information";

//additional strings - 03/06/06
var re_dshBrd_TxtIPDHCP = "Negotiated with DHCP";
var re_dshBrd_TltpFan1Ok = "FAN 1 is OK";
var re_dshBrd_TltpFan1Faulty = "FAN 1 is FAULTY";
var re_dshBrd_TltpFan2Ok = "FAN 2 is OK";
var re_dshBrd_TltpFan2Faulty = "FAN 2 is FAULTY";
var re_dshBrd_TltpTemperatureOk = "Temperature is OK";
var re_dshBrd_TltpTemperatureFaulty = "Temperature is Faulty";
var re_dshBrd_TltpPort = "Port";
var re_dshBrd_TltpUtilization = "Utilization";

//pixar strings - 06/21/06
var re_dshBrd_LblEthMgmtPortIP = "Ethernet Management{0}Port IP Address";
var re_dshBrd_TxtWarning = "Warning";

//Xmen2 strings
var re_dshBrd_Lbl_CIP_SNum = "CIP Serial Number";