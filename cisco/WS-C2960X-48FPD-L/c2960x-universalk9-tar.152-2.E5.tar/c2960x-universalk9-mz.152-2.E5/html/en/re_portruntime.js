/*
 *------------------------------------------------------------------
 * Resource file for port status
 * Copyright (c) 2006, 2008 by cisco Systems, Inc.
 *------------------------------------------------------------------
*/

//Title
var re_pStatus_ScrTtl		="Port Status";

//Table headers
var re_pStatus_TblHeader1	="Port";
var re_pStatus_TblHeader2	="Description";
var re_pStatus_TblHeader3	="Status";
var re_pStatus_TblHeader4	="VLAN";
var re_pStatus_TblHeader5	="Speed";
var re_pStatus_TblHeader6	="Duplex";
var re_pStatus_TblHeader7	="PoE";
var re_pStatus_TblHeader8	="Auto-MDIX";
var re_pStatus_TblHeader9	="Inline Power";

//Alert messages
var re_pStatus_ErrMsg1		="ERROR: port is null";
var re_pStatus_ErrMsg2		="{0} port not found" ;

//Added for Xmen2 on Apr 18 2008
var re_pStatus_TblHeader10	="MediaType";