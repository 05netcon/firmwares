/*
 *------------------------------------------------------------------
 * Resource file for Port settings
 * Copyright (c) 2006, 2008 by cisco Systems, Inc.
 *------------------------------------------------------------------
*/

//title
var re_pSet_Scr1Ttl		="Port Settings";

//Table headers

var re_pSet_TblHeader1	="Port";
var re_pSet_TblHeader2	="Description";
var re_pSet_TblHeader3	="Enable";
var re_pSet_TblHeader4	="Speed";
var re_pSet_TblHeader5	="Duplex";
var re_pSet_TblHeader6	="PoE";
var re_pSet_TblHeader7	="Auto-MDIX";
var re_pSet_TblHeader8	="Inline Power";

//Warning messages.
var re_pSet_ErrMsg1		="ERROR: port is null";
var re_pSet_ErrMsg2		="The port description cannot contain a ? or a tab.\n";
var re_pSet_ErrMsg3		="The port description cannot contain more than 18 characters.\n";
var re_pSet_ErrMsg4		="You cannot enable auto-MDIX on a 1000BASE-SX SFP port.\n";
var re_pSet_ErrMsg5		="You cannot enable auto-MDIX on a 1000BASE -LX SFP port.\n";
var re_pSet_ErrMsg6		="You cannot enable auto-MDIX on port {0}. This port is disabled.\n";
var re_pSet_ErrMsg7		="You cannot enable auto-MDIX on port {0}. Both speed and duplex should be set to auto on port {1}.\n";
var re_pSet_ErrMsg8		="You can not disable Auto-MDIX on port {0}. This port is disabled.\n";
var re_pSet_ErrMsg9		="During initial setup, you cannot disable the management interface {0}.\n";
var re_pSet_ErrMsg10	="During initial setup, you cannot change the auto-MDIX setting on the management interface {0}.\n";
var re_pSet_ErrMsg11	="During initial setup, you cannot change the speed setting on the management interface {0}.\n";
var re_pSet_ErrMsg12	="You cannot change the port speed of {0} to 1000 Mbps if the port is in half-duplex mode.\n";
var re_pSet_ErrMsg13	="You cannot change the port speed of {0}  to 'Auto' if the port is in half-duplex mode.\n";
var re_pSet_ErrMsg14	="During initial setup, you cannot change the duplex setting on the management interface {0}.\n";
var re_pSet_ErrMsg15	="The duplex setting on this port {0} cannot be set to 'half' because its speed is set to 'auto'.\n";
var re_pSet_ErrMsg16	="You cannot change the port speed of {0} to 1000 Mbps if the port is in half-duplex mode.\n";
var re_pSet_ErrMsg17	="During initial setup, you cannot change the PoE setting on the management interface {0}.\n";
//Newly added
var re_pSet_ErrMsg18	="You cannot change the port duplex of {0} to half if the port speed is 1000 Mbps.\n";
var re_pSet_ErrMsg19	="The port description cannot contain non-English letters.\n";

//added for stiletto
var re_pSet_ErrMsg20	= "You cannot enable the {0} management port.\n";
var re_pSet_ErrMsg21	= "You cannot disable the {0} management port.\n";

//Added for Xmen2 on Apr 18 2008
var re_pSet_TblHeader9	="MediaType";
