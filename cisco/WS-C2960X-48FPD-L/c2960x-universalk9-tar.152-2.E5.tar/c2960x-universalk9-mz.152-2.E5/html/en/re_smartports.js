/*
 *------------------------------------------------------------------
 * smartports resource file
 * Copyright (c) 2006, 2009 by cisco Systems, Inc.
 * feature code - sPort
 *------------------------------------------------------------------
*/

//macchiato
var re_sPort_Scr1Ttl = "Smartports";
var re_sPort_Scr2Ttl = "Smartports: Customize";

var re_sPort_Txt1Mach = "Select a port role";
var re_sPort_Txt2Mach = "Click a port to apply the selected port role";
var re_sPort_AllPortsChkBoxMach = "Apply the selected port role for all ports";

var re_sPort_Txt3 = "Move the pointer over the ports for more information";
var re_sPort_Btn1 = "Customize...";

var re_sPort_LblPort = "Port";
var re_sPort_LblRole = "Role";
var re_sPort_LblNatVlan = "Native VLAN";
var re_sPort_LblAccVlan = "Access VLAN";
var re_sPort_LblVoiceVlan = "Voice VLAN";
var re_sPort_LblServerType = "Server Type";


var re_sPort_ErrMsg8Mach = "The ports {0} are connected to non-desktop devices and cannot be applied with the Desktop port role.";
var re_sPort_ErrMsg9 = "You must first select a port role from the Select a port role field.";
var re_sPort_ErrMsg10 = "Port {0} is a member of an EtherChannel. Remove the port from the EtherChannel before changing the port role.";
var re_sPort_ErrMsg11 = "The Cisco-Guest VLAN must exist before applying the Guest role to the port. Create the Cisco-Guest VLAN.";
var re_sPort_ErrMsg12 = "The Cisco-Voice VLAN must exist before applying the IP Phone+Desktop role to the port. Create the Cisco-Voice VLAN.";
var re_sPort_ErrMsg13 = "Port {0} must be a member of the Cisco-Guest VLAN.";
var re_sPort_ErrMsg14 = "Port {0} must be a member of the Cisco-Guest VLAN. Create this VLAN if it does not already exist.";
var re_sPort_ErrMsg15 = "Port {0} must be a member of the Cisco-Voice VLAN.";
var re_sPort_ErrMsg16 = "Port {0} must be a member of the Cisco-Voice VLAN. Create this VLAN if it does not already exist.";
var re_sPort_ErrMsg17 = "Only ports applied with the IP Phone+Desktop port role can be members of the Cisco-Voice VLAN.";
var re_sPort_ErrMsg18 = "Only ports applied with the Guest port role can be members of the Cisco-Guest VLAN.";
var re_sPort_ErrMsg19 = "Ports applied with the Guest role must be assigned to the Cisco-Guest VLAN. Ports applied with the IP Phone+Desktop role must be assigned to the Cisco-Voice VLAN. These VLANs must exist before applying these roles to ports.";
var re_sPort_ErrMsg20 = "Ports {0} must be a member of the Cisco-Guest VLAN. Create this VLAN if it does not already exist. If this VLAN does exist, click Customize and assign ports {1} to the Cisco-Guest VLAN.";
var re_sPort_ErrMsg21 = "Ports {0} must be a member of the Cisco-Voice VLAN. Create this VLAN if it does not already exist. If this VLAN does exist, click Customize and assign ports {1} to the Cisco-Voice VLAN.";
var re_sPort_ErrMsg22 = "While your network management station is directly connected to a switch port and the SETUP LED is green, you cannot change the port role or VLAN settings on that switch port.";

var re_sPort_WngMsg1 = "Port {0} is assigned to a non-existent VLAN. The port will be assigned to the default management VLAN.";

//non-macchiato
var re_sPort_Grp1Ttl = "Recommended System Setup";
var re_sPort_Grp2Ttl = "Recommended Port Setup";

var re_sPort_GlblChkBox = "Enable";
var re_sPort_AllPortsChkBox = "Enable the selected port setup for all ports";
var re_sPort_Txt1 = "Select a port setup";
var re_sPort_Txt2 = "Click a port to enable the selected port setup";


//tooltip
var re_sPort_LblSetup = "Setup";

//customize table
var re_sPort_LblSetupType = "Setup Type";

//error messages
var re_sPort_ErrMsg1 = "You have clicked Customize without configuring a port setup.";
var re_sPort_ErrMsg2 = "VLAN ID should contain integers only. Enter a valid VLAN ID.";
var re_sPort_ErrMsg3 = "You must enter a VLAN ID before clicking Done.";
var re_sPort_ErrMsg4 = "{0} is not a valid VLAN ID. Enter a VLAN ID in the range of 1 to 1001 or 1006 to 4094.";
var re_sPort_ErrMsg5 = "{0} is not a valid VLAN ID. Enter a VLAN ID in the range of 1 to 1001.";
var re_sPort_ErrMsg6 = "The device is running in VTP client mode, the new VLANs can not be created in this mode";
var re_sPort_ErrMsg7 = "The maximum VLANs supported on this device are {0} following VLANs can not be used {1}";
var re_sPort_ErrMsg8 = "Desktop connection settings cannot be applied to ports {0} because they are connected to non-desktop devices.";

//new strings
var re_sPort_ErrMsg23 = "Ports applied with the IP Phone+Desktop port role should belong to access VLANs other than Cisco-Voice.";
var re_sPort_ErrMsg24 = "Only ports applied with the IP Phone+Desktop port role or the Server port role can be members of the Cisco-Voice VLAN.";

//additional strings - 03/06/06
var re_sPort_ErrMsg25 = "You have clicked Customize without configuring a port role.";

var re_sPort_LblIngressVlan = "Ingress VLAN";
var re_sPort_LbldstInterface= "Destination Interface";
var re_sPort_ErrMsg26 = "The {0} port role is already applied to port {1}. This port role cannot be applied to more than one switch port.";
var re_sPort_ErrMsg27 = "The {0} source port cannot be the same port as the {1} destination port.";
var re_sPort_ErrMsg28 ="The {0} port role cannot be applied to more than one switch port. Select one port to which to apply the {1} port role.";
var re_sPort_ErrMsg29 ="Recommended System Setup needs to be enabled to apply Generic Ethernetip port role.";
var re_sPort_ErrMsg30 = "{0} Port Role  Partially Applied";
var re_sPort_ErrMsg31 = "Configure the Parameters for partially applied {0} Port role";
//var re_sPort_ErrMsg32 ="Generic Ethernetip port role is applied to one or more ports, but Recommended System Setup is disabled.";
var re_sPort_ErrMsg32 ="Cisco Ethernetip port role is applied to one or more ports, but Recommended System Setup is disabled.";
var re_sPort_ErrMsg33="Old version of the port roles Desktop, Switch, Router, IP Phone+Desktop and Wirless Access Point are being used. Replace these port roles with the appropriate newer version of the port roles";
var re_sPort_ErrMsg34 = "REP is configured on the port {0}. Changing the port role to {1} for the port will conflict with REP settings.";
var re_sPort_ErrMsg35 = "A port role cannot be configured on a routed port.";
var re_sPort_ErrMsg36 = "The port role is not applied to these ports, as these are routed ports: {0}.";
