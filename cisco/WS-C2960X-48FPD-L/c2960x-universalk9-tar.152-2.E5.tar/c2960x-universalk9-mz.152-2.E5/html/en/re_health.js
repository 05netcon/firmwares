/*
 *------------------------------------------------------------------
 * health resource file
 * Copyright (c) 2006 by cisco Systems, Inc.
 *------------------------------------------------------------------
*/
// NOTE: This file is shared by dashboard and trends page.


//Title
var re_trend_ScrTtl				="Trends";

//Resource content for dashboard
var re_trend_ports_Lbl			="Ports";
var re_trend_viewtrends_Lbl		="View Trends";

//Table header
var re_trend_TblHeader1			="Switch Health";
var re_trend_TblHeader2			="Port Utilization";
var re_trend_TblHeader3			="Port Utilization/Errors"
var re_trend_title_Lbl			="Title";


//Table content
var re_trend_bandutil_Lbl		="Bandwidth Utilization";
var re_trend_stkbandutil_Lbl	="Stack Bandwidth Utilization";
var re_trend_packeterr_Lbl		="Packet Error";
var re_trend_stkpacketerr_Lbl	="Stack Packet Error";
var re_trend_inpwrutil_Lbl		="Inline Power Utilization";
var re_trend_poeutil_Lbl		="PoE Utilization";
var re_trend_timeslot_Lbl		="Time Slot";
var re_trend_pwrutil_Lbl		="Power Utilization";

var re_trend_recutil_Lbl		="Receive Utilization";
var re_trend_transutil_Lbl		="Transmit Utilization";
var re_trend_receive_Lbl		="Receive";
var re_trend_transmit_Lbl		="Transmit";


//Tooltip
var re_trend_TltpLbl4			="Utilization";

//link
var re_trend_viewportstat_Lbl	="View Port Statistics";

var re_trend_sec_Lbl			="Seconds";
var re_trend_min_Lbl			="Minutes";
var re_trend_hrs_Lbl			="Hours";
var re_trend_day_Lbl			="Days";

var re_trend_ls_Lbl				="Last 60 Seconds";
var re_trend_lm_Lbl				="Last 60 Minutes";
var re_trend_lh_Lbl				="Last 24 Hours";
var re_trend_ld_Lbl				="Last 14 Days";

var re_trend_rfsh_Lbl			="Refresh Cycle";
var re_trend_porterr_Lbl		="Port Errors";
var re_trend_port_Lbl			="Port";

//non-macchiato
var re_trend_connport_Lbl		="Connected Port";
var re_trend_noport_Txt			="No Ports Connected for this device";