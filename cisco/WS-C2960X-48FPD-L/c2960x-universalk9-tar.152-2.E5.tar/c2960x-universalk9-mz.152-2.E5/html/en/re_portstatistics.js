/*
 *------------------------------------------------------------------
 * Resource file for port statistics
 * Copyright (c) 2006, 2012 by cisco Systems, Inc.
 *------------------------------------------------------------------
*/

//Title
var re_pStats_ScrTtl		="Port Statistics";

//Tabs
var re_pStats_tab_Lbl1		="Overview";
var re_pStats_tab_Lbl2		="Transmit Detail";
var re_pStats_tab_Lbl3		="Receive Detail";

//Table Headers
var re_pStats_Tblheader1	="Port";
var re_pStats_Tblheader2	="Transmitted{0}(bytes)";
var re_pStats_Tblheader3	="Total Transmitted{0}(pkts)";
var re_pStats_Tblheader4	="Received{0} (bytes)";
var re_pStats_Tblheader5	="Total Received{0}(pkts)";
var re_pStats_Tblheader6	="Total Transmit{0}Errors (pkts)";
var re_pStats_Tblheader7	="Total Receive{0}Errors (pkts)";
var re_pStats_Tblheader8	="Unicast{0} (pkts)";
var re_pStats_Tblheader9	="Multicast{0} (pkts)";
var re_pStats_Tblheader10	="Broadcast{0} (pkts)";
var re_pStats_Tblheader11	="Total Collision{0} (pkts)";
var re_pStats_Tblheader12	="Excessive{0} Collisions (pkts)";
var re_pStats_Tblheader13	="Late Collisions{0} (pkts)";
var re_pStats_Tblheader19	="Link Diagnostics{0} (pkts)";

var re_pStats_Tblheader14	="FCS Errors{0} (pkts)";
var re_pStats_Tblheader15	="Alignment{0}Errors (pkts)";
var re_pStats_Tblheader16	="Oversize{0} (pkts)";
var re_pStats_Tblheader17	="Undersize{0} (pkts)";
var re_pStats_Tblheader18	="Collision{0}Fragments";
var re_pStats_Tblheader21   ="Link Diagnostics {0} (pkts)"; 

//Warning messages
var re_pStats_WngMsg		='Select a row and then click "Clear Counters" to clear the statistics in the selected row.';

//Button labels
var re_pStats_clr_btn		="Clear Counters";