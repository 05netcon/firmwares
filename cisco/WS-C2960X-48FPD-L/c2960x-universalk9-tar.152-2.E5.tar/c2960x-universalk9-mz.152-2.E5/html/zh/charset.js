/*
 *------------------------------------------------------------------
 * charset.js - Chinese
 * Copyright (c) 2006 by cisco Systems, Inc.
 *------------------------------------------------------------------
*/

document.write('<meta http-equiv="content-type" content="text/html; charset=gb2312">');
document.charset = "gb2312";
