/*
 *------------------------------------------------------------------
 * Resource file for port status
 * Copyright (c) 2006 by cisco Systems, Inc.
 *------------------------------------------------------------------
*/

//Title
var re_pStatus_ScrTtl="�˿�״̬";

//Table headers
var re_pStatus_TblHeader1="�˿�";
var re_pStatus_TblHeader2="˵��";
var re_pStatus_TblHeader3="״̬";
var re_pStatus_TblHeader4="VLAN";
var re_pStatus_TblHeader5="�ٶ�";
var re_pStatus_TblHeader6="˫��";
var re_pStatus_TblHeader7="PoE";
var re_pStatus_TblHeader8="Auto-MDIX";
var re_pStatus_TblHeader9="���ϵ�Դ";

//Alert messages
var re_pStatus_ErrMsg1="���󣺶˿���Ч";
var re_pStatus_ErrMsg2="{0} �˿�δ�ҵ�";
