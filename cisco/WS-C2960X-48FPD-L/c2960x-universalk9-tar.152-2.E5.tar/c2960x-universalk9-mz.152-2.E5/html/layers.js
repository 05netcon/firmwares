/*
 *------------------------------------------------------------------
 * layers.js
 *
 * Copyright (c) 2003, 2004 by cisco Systems, Inc.
 * All rights reserved.
 *------------------------------------------------------------------
 */

// will set the layerContent as the content of the layer layerName
function set_layercontent(layerName, layerContent){
	if(document.layers){
	// the browser is "NN4";
		layerObj = document.layers[layerName];
		layerObj.document.open();
		layerObj.document.write(layerContent);
		layerObj.document.close();
	}

	if(document.all){
	// the browser is "ie"
		layerObj = document.all[layerName];
		layerObj.innerHTML=layerContent
	}

	if(!document.all && document.getElementById){
	// the browser is "NN6";
		layerObj = document.getElementById(layerName);
		layerObj.innerHTML =layerContent;
	}
}

// returns the layer object with the name layerName
function getLayerByName(layerName) {
	if(document.layers){
	// the browser is "NN4";
		layerObj = document.layers[layerName];
	}

	if(document.all){
	// the browser is "ie"
		layerObj = document.all[layerName];
	}

	if(!document.all && document.getElementById){
	// the browser is "NN6";
		layerObj = document.getElementById(layerName);
	}
	return(layerObj);
}

// set the visibility of the layer with the name layerName
function setVisibleLayer(layerName, visibility) {
	layerObj = getLayerByName(layerName);
	if(layerObj == null)
		return;
	if(visibility == true) {
		layerObj.style.display = "block";
		layerObj.style.visibility = "visible"
	}
	else {
		layerObj.style.display = "none";
		layerObj.style.visibility = "hidden"
	}
}
