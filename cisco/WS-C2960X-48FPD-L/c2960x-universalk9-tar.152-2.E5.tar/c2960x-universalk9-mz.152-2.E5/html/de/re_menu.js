/*
 *------------------------------------------------------------------
 * menu resource file
 * Copyright (c) 2006, 2009 by cisco Systems, Inc.
 *------------------------------------------------------------------
*/

var re_menu_txt_contents = "Inhalt";
var re_menu_txt_dashboard = "Dashboard";
var re_menu_txt_configure = "Konfigurieren";
var re_menu_txt_smartports = "Smartports";
var re_menu_txt_portset = "Porteinstellungen";
var re_menu_txt_exsetup = "Schnelleinrichtung";// changed the title from "Express Einrichtung" to "Schnelleinrichtung" as it is suggested by Julien during Stout support.
var re_menu_txt_vlans = "VLANs";
var re_menu_txt_snmp = "SNMP";
var re_menu_txt_ethchan = "EtherChannels";
var re_menu_txt_userpass = "Benutzer und Passw�rter";
var re_menu_txt_restartreload = "Neu starten / Zur�cksetzen";
var re_menu_txt_monitor = "�berwachen";
var re_menu_txt_trends = "Trends";
var re_menu_txt_portstatus = "Portstatus";
var re_menu_txt_portstatistics = "Portstatistik";
var re_menu_txt_alertlog = "Alarmprotokoll";
var re_menu_txt_diag = "Diagnostik";
var re_menu_txt_softupgrade = "Software Upgrade";
var re_menu_txt_netassist = "Network Assistant";
var re_menu_txt_maintenance = "Wartung";
var re_menu_txt_intro = "Einleitung";
var re_menu_txt_legend = "Legende";
var re_menu_txt_support = "Unterst�tzung";
var re_menu_txt_telnet = "Telnet";

//new strings
var re_menu_txt_controllerDM="Steuerungsger�temanager";
