/*
 *------------------------------------------------------------------
 * Resource file for port status
 * Copyright (c) 2006 by cisco Systems, Inc.
 *------------------------------------------------------------------
*/

//Title
var re_pStatus_ScrTtl="Portstatus";

//Table headers
var re_pStatus_TblHeader1="Port";
var re_pStatus_TblHeader2="Beschreibung";
var re_pStatus_TblHeader3="Status";
var re_pStatus_TblHeader4="VLAN";
var re_pStatus_TblHeader5="Geschwindigkeit";
var re_pStatus_TblHeader6="Duplex";
var re_pStatus_TblHeader7="PoE";
var re_pStatus_TblHeader8="Auto-MDIX";
var re_pStatus_TblHeader9="Inline Strom";

//Alert messages
var re_pStatus_ErrMsg1="FEHLER: Port ist Null";
var re_pStatus_ErrMsg2="{0} Port wurde nicht gefunden";
