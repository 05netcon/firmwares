﻿/*
 *------------------------------------------------------------------
 * Resource file for port statistics
 * Copyright (c) 2006, 2010 by cisco Systems, Inc.
 *------------------------------------------------------------------
*/

//Title
var re_pStats_ScrTtl="Portstatistik";

//Tabs
var re_pStats_tab_Lbl1="Übersicht";
var re_pStats_tab_Lbl2="Übertragungsangaben";
var re_pStats_tab_Lbl3="Empfangsangaben";

//Table Headers
var re_pStats_Tblheader1="Port";
var re_pStats_Tblheader2="{0}(Bytes)übertragen";
var re_pStats_Tblheader3="Gesamtzahl {0}(Pkte) übertragen";
var re_pStats_Tblheader4="{0} (Bytes) empfangen";
var re_pStats_Tblheader5="Gesamtzahl {0}(Pkte) empfangen";
var re_pStats_Tblheader6="Gesamtzahl {0}Fehler (Pkte) übertragen";
var re_pStats_Tblheader7="Gesamtzahl {0}Fehler (Pkte) empfangen";
var re_pStats_Tblheader8="Unicast{0} (Pkte)";
var re_pStats_Tblheader9="Multicast{0} (Pkte)";
var re_pStats_Tblheader10="Broadcast{0} (Pkte)";
var re_pStats_Tblheader11="Insgesamt {0}Kollisionen (Pkte)";
var re_pStats_Tblheader12="Überhöhte{0} Kollisionen (Pkte)";
var re_pStats_Tblheader13="Verspätete Kollisionen{0} (Pkte)";
var re_pStats_Tblheader14="FCS Fehler{0} (Pkte)";
var re_pStats_Tblheader15="Ausrichtungsfehler{0} (Pkte)";
var re_pStats_Tblheader16="Übergröße{0} (Pkte)";
var re_pStats_Tblheader17="Untergröße{0} (Pkte)";
var re_pStats_Tblheader18="Kollisionsfragmente{0}";

//Warning messages
var re_pStats_WngMsg="Wählen Sie eine Zeile und klicken Sie dann 'Zähler zurücksetzen', um die Statistik der ausgewählten Zeile zurückzusetzen.";

//Button labels
var re_pStats_clr_btn="Zähler zurücksetzen";
