/*
 *------------------------------------------------------------------
 * charset.js - German
 * Copyright (c) 2006 by cisco Systems, Inc.
 *------------------------------------------------------------------
*/

document.write('<meta http-equiv="content-type" content="text/html; charset=Windows-1252">');
document.charset = "Windows-1252";
