/*
 *------------------------------------------------------------------
 * FPV, topframe resource file
 * Copyright (c) 2006-2007, 2009, 2013 by cisco Systems, Inc.
 *------------------------------------------------------------------
*/

var re_fpv_txt_status = "Status";
var re_fpv_txt_duplex = "Duplex";
var re_fpv_txt_speed = "Geschwindigkeit";
var re_fpv_txt_power = "Energie";
var re_fpv_txt_poe = "PoE";
var re_fpv_txt_view = "Ansicht";
var re_fpv_txt_nextrefresh1 = "N�chste Aktualisierung in {0} Sekunde";
var re_fpv_txt_nextrefresh2 = "N�chste Aktualisierung in {0} Sekunden";
var re_fpv_txt_refreshing = "Aktualisiere...";
var re_fpv_txt_refreshpause = "Aktualisierung unterbrochen";
var re_fpv_txt_movepointer = "F�r weitere Informationen ziehen Sie den Zeiger �ber die Ports.";
var re_fpv_Tltp_port = "Port";
var re_fpv_Tltp_type = "Typ";
var re_fpv_Tltp_descr = "Beschreibung";
var re_fpv_Tltp_uptime = "Betriebszeit";
var re_fpv_Tltp_poe = "PoE";
var re_fpv_Tltp_noalert = "Keine Alarme";
var re_fpv_Tltp_severity = "Schweregrad";
var re_fpv_Tltp_event = "Ereignis";
var re_fpv_Tltp_time = "Zeit";
var re_fpv_Tltp_viewallalert = "Alle Alarme anzeigen";
var re_Ttl_txt_catseriesdevmanager1 ="ITP {0} Serie Ger�temanager";
var re_Ttl_txt_catseriesdevmanager ="Catalyst {0} Serie Ger�temanager";
var re_Ttl_txt_catseriesexsetup1 ="ITP {0} Serie Schnelleinrichtung";
var re_Ttl_txt_catseriesexsetup ="Catalyst {0} Serie Schnelleinrichtung";
var re_Ttl_txt_catexsetup ="Catalyst Schnelleinrichtung";
var re_Ttl_txt_catdevmanager = "Catalyst Ger�temanager";
var re_Ttl_txt_registernow = "Jetzt anmelden";
var re_Ttl_txt_devmanager = "Ger�temanager";
var re_SSL_txt_session = "Sitzung";
var re_SSL_txt_normalmode = "Normalmodus";
var re_SSL_txt_securemode = "Sicherheitsmodus";
var re_SSL_txt_standard = "Standard";
var re_SSL_txt_secured = "Gesichert";
var re_SSL_txt_userpref_WngMsg = "M�chten Sie {0} zum Standardmodus machen?";

//non-macchiato
var re_fpv_txt_switch = "Switch";
var re_fpv_txt_rps = "RPS";
var re_fpv_txt_stack = "Stapel";
var re_fpv_txt_iobay = "I/O Bay";
var re_fpv_txt_member = "Mitglied";
var re_fpv_txt_master = "Master";
var re_fpv_Tltp_inline = "Inline Strom";
var re_Ttl_txt_esm = "EtherSwitch Servicemodul Ger�temanager";
var re_Ttl_txt_cbs3030 = "Catalyst Blade Switch 3030 Ger�temanager";
var re_Ttl_txt_cbs3020 = "Catalyst Blade Switch 3020 Ger�temanager";

//Newly added Strings
var re_Ttl_txt_esm_2 ="EtherSwitch Service Modul";
var re_Ttl_txt_cbs3030_2= "Catalyst Blade Switch 3030 Ger�temanager";
var re_Ttl_txt_cbs3020_2 = "Catalyst Blade Switch 3020 Ger�temanager";
var re_Ttl_txt_catalyst ="Catalyst";
var re_Ttl_txt_softrecover="Software Fehlerbeseitigung";
var re_Ttl_txt_catseries1 ="ITP {0} Serie";
var re_Ttl_txt_catseries ="Catalyst {0} Serie";
var re_Ttl_txt_exsetup ="Schnelleinrichtung";// changed the title from "Express Einrichtung" to "Schnelleinrichtung" as it is suggested by Julien during Stout support.

//additional strings - 03/06/06
var re_fpv_Tltp_different_mode ="Klicken Sie auf diese Schaltfl�che, um einen anderen Modus zu w�hlen";
var re_fpv_txt_Lanugage ="Sprache";

//Newly added strings (for Falchion)
var re_Ttl_txt_cbs3040="Catalyst Blade Switch 3040";

//Strings added for pixar SKUs
var re_fpv_Tltp_fru = "FRU";
var re_fpv_Tltp_pid = "PID";
var re_fpv_Tltp_fru_information = "FRU Information";
var re_fpv_Tltp_System_Power = "System Power";
var re_fpv_Tltp_PoE_Power = "PoE Power";
var re_fpv_Tltp_Sidinfo = "SID Information";
var re_fpv_Tltp_type = "Type";
var re_fpv_Tltp_System_Power = "System Power";
var re_fpv_Tltp_PoE_Power = "PoE Power";
var re_fpv_Tltp_serial = "Serial Number";
var re_fpv_Tltp_Port = "Port";
var re_fpv_Tltp_IPAddress = "IP Address";
var re_fpv_Tltp_Status = "Status";
var re_fpv_Tltp_EtherManagePort = "Ethernet Management Port";

//For Stout 11/11/09
var re_fpv_Tltp_IPAddress = "IP-Adresse";
var re_fpv_Tltp_EtherManagePort = "Ethernet-Management-Port";
