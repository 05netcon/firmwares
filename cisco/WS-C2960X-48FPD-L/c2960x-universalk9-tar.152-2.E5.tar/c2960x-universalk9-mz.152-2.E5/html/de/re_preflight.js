/*
 *------------------------------------------------------------------
 * preflight resource file
 * Copyright (c) 2006 by cisco Systems, Inc.
 *------------------------------------------------------------------
*/

var re_preFlt_Ttl1 = "Fehlerbehebung der Unterst�tzung des Betriebssystems";
var re_preFlt_Ttl2 = "Fehlerbehebung des Internet Browsers";
var re_preFlt_Ttl3 = "Fehlerbehebung der Unterst�tzung des Internet Browsers";
var re_preFlt_Ttl4 = "Fehlerbehebung f�r JavaScript";
var re_preFlt_txt1 = "Betriebssystem";
var re_preFlt_txt2 = "Dieses Betriebssystem (BS Typ, Version) wird nicht unterst�tzt.";
var re_preFlt_txt3 = "Diese Betriebssysteme werden unterst�tzt:";
var re_preFlt_txt4 = "Windows XP, 2000";
var re_preFlt_txt5 = "{Hier} klicken, um zum Initialisierungsbericht zur�ckzukehren.";
var re_preFlt_txt6 = "JavaScript ist nicht aktiviert. Bevor der Ger�temanager starten kann, muss JavaScript aktiviert werden.";
var re_preFlt_txt7 = "JavaScript in Netscape wird aktiviert";
var re_preFlt_txt8 = "W�hlen Sie {Bearbeiten > Einstellungen} zum �ffnen des Einstellungsfensters.";
var re_preFlt_txt9 = "Klicken Sie unter Kategorie auf {Erweitert}, um die erweiterten Einstellungen anzuzeigen.";
var re_preFlt_txt10 = "Markieren Sie {Enable JavaScript} im Erweiterungsbereich und klicken Sie OK.";
var re_preFlt_txt11 = "{Hier} klicken um zur�ckzukehren";
var re_preFlt_txt12 = "JavaScript in Internet Explorer wird aktiviert";
var re_preFlt_txt13 = "W�hlen Sie {Werkzeuge > Internetoptionen.}";
var re_preFlt_txt14 = "Klicken Sie auf das {Sicherheit} Register.";
var re_preFlt_txt15 = "Klicken Sie auf {Sondereinstellung}. Das Fenster Sicherheitseinstellungen wird ge�ffnet.";
var re_preFlt_txt16 = "Bl�ttern Sie zu Scripting und klicken Sie {Aktivieren} unter Aktives Scripting.";
var re_preFlt_txt17 = "Klicken Sie {OK} und dann {Ja} in der Warnungsdialogbox.";
var re_preFlt_txt18 = "Klicken Sie {OK} zum Schlie�en des Internet Optionen Fensters.";
var re_preFlt_txt20 = "Internet Browser";
var re_preFlt_txt21 = "Der Internet Browser ({0}) wird nicht unterst�tzt";
var re_preFlt_txt22 = "Diese Internet Browser werden unterst�tzt:";
var re_preFlt_txt23 = "Internet Explorer 5.5 und 6.0";
var re_preFlt_txt24 = "Netscape 7.1";
var re_preFlt_txt25 = "JavaScript";
var re_preFlt_txt26 = "JavaScript ist nicht aktiviert.";
var re_preFlt_txt27 = "Der Ger�temanager startet nicht, bis JavaScript aktiviert wird.";
var re_preFlt_txt28 = "F�r weitere Informationen {hier} klicken.";
var re_preFlt_txt29 = "Der Internet Browser Status ist unbekannt.";
var re_preFlt_txt30 = "Betriebssystem";
var re_preFlt_txt31 = "Der Betriebssystemstatus ist unbekannt.";
var re_preFlt_txt32 = "Einrichtungsbericht";
var re_preFlt_txt33 = "Initialisierungsbericht";
var re_preFlt_txt34 = "Der Ger�temanager l�uft nicht mit dem Internet Browser {0}";
var re_preFlt_txt35 = "Bitte aktualisieren Sie Ihren Browser.";
var re_preFlt_txt36 = "Der Ger�temanager unterst�tzt den Internet Browser nicht";
var re_preFlt_txt37 = "Klicken Sie fortfahren, um mit dem nicht unterst�tzten Browser zu starten:";
var re_preFlt_txt38 = "F�r weitere Informationen {hier} klicken.";
var re_preFlt_txt39 = "Dieser Internet Browser wird unterst�tzt.";
var re_preFlt_txt40 = "Der Ger�temanager unterst�tzt das Betriebssystem {0} nicht.";
var re_preFlt_txt41 = "Klicken Sie fortfahren, um mit dem nicht unterst�tzten System zu starten:";
var re_preFlt_txt42 = "Dieses Betriebssystem wird unterst�tzt.";
var re_preFlt_txt43 = "Read Write Zugriff";
var re_preFlt_txt44 = "Der Ger�temanager unterst�tzt keinen Read-only Zugriff f�r diesen Switch.";
var re_preFlt_txt45 = "Hinweis: Der Zugriff auf den Ger�temanager erfolgt in Read-Write Modus.";
var re_preFlt_txt46 = "Schritt 1";
var re_preFlt_txt47 = "Schritt 2";
var re_preFlt_txt48 = "Schritt 3";
var re_preFlt_txt49 = "Schritt 4";
var re_preFlt_txt50 = "Schritt 5";
var re_preFlt_txt51 = "Schritt 6";
var re_preFlt_txt52 = "Schritt 7";

//Newly added Strings
var re_preFlt_txt53="JavaScript wurde aktiviert.";
var re_preFlt_txt54="Der Lese-Schreibzugangsmodus ist unbekannt.";
var re_preFlt_txt55 ="Copyright (c) 2004-2006 durch Cisco Systems, Inc.";
var re_preFlt_txt56 ="Fortfahren";
