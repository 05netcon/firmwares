﻿/*
 *------------------------------------------------------------------
 * smartports resource file
 * Copyright (c) 2006, 2010 by cisco Systems, Inc.
 * feature code - sPort
 *------------------------------------------------------------------
*/

//macchiato
var re_sPort_Scr1Ttl = "Smartports";
var re_sPort_Scr2Ttl = "Smartports: Anpassen";

var re_sPort_Txt1Mach = "Wählen Sie eine Portfunktion";
var re_sPort_Txt2Mach = "Klicken Sie auf einen Port, um die gewählte Portfunktion zu übernehmen";
var re_sPort_AllPortsChkBoxMach = "Gewählte Portfunktion für alle Ports übernehmen";

var re_sPort_Txt3 = "Für weitere Informationen ziehen Sie den Zeiger über die Ports";
var re_sPort_Btn1 = "Anpassen...";

var re_sPort_LblPort = "Port";
var re_sPort_LblRole = "Funktion";
var re_sPort_LblNatVlan = "Natives VLAN";
var re_sPort_LblAccVlan = "Zugriff VLAN";
var re_sPort_LblVoiceVlan = "Voice VLAN";
var re_sPort_LblServerType = "Servertyp";

var re_sPort_ErrMsg8Mach = "Die Ports {0} sind mit Nicht-Desktop Geräten verbunden und können nicht mit der Desktop Portfunktion angelegt werden.";
var re_sPort_ErrMsg9 = "Sie müssen zunächst im Feld 'Wählen Sie eine Portfunktion' eine Portfunktion wählen.";
var re_sPort_ErrMsg10 = "Port {0} ist ein Mitglied eines EtherChannel. Entfernen Sie den Port vom EtherChannel, bevor Sie die Portfunktion ändern.";
var re_sPort_ErrMsg11 = "Vor Anwendung der Guest Funktion auf den Port muss das Cisco-Guest VLAN eingerichtet werden. Erstellen Sie das Cisco-Guest VLAN.";
var re_sPort_ErrMsg12 = "Vor Anwendung der IP Phone+Desktop Funktion auf den Port muss das Cisco-Voice VLAN eingerichtet werden. Erstellen Sie das Cisco-Voice VLAN.";
var re_sPort_ErrMsg13 = "Port {0} muss ein Mitglied des Cisco-Guest VLANs sein.";
var re_sPort_ErrMsg14 = "Port {0} muss ein Mitglied des Cisco-Guest VLANs sein. Erstellen Sie dieses VLAN, falls es nicht bereits existiert.";
var re_sPort_ErrMsg15 = "Port {0} muss ein Mitglied des Cisco-Voice VLANs sein.";
var re_sPort_ErrMsg16 = "Port {0} muss ein Mitglied des Cisco-Voice VLANs sein. Erstellen Sie dieses VLAN, falls es nicht bereits existiert.";
var re_sPort_ErrMsg17 = "Nur Ports mit der IP Phone+Desktop Portfunktion können Mitglieder des Cisco-Voice VLANs sein.";
var re_sPort_ErrMsg18 = "Nur Ports mit der Guest Portfunktion können Mitglieder des Cisco-Guest VLANs sein.";
var re_sPort_ErrMsg19 = "Ports mit der Guest Funktion müssen dem Cisco-Guest VLAN zugewiesen werden. Ports mit der IP Phone+Desktop Funktion müssen dem Cisco-Voice VLAN zugewiesen werden. Diese VLANs müssen bereits bestehen, bevor die Funktionen von den Ports übernommen werden können.";
var re_sPort_ErrMsg20 = "Ports {0} müssen Mitglieder des Cisco-Guest VLANs sein. Erstellen Sie dieses VLAN, falls es nicht bereits existiert.";
var re_sPort_ErrMsg21 = "Ports {0} müssen Mitglieder des Cisco-Voice VLANs sein. Erstellen Sie dieses VLAN, falls es nicht bereits existiert.";
var re_sPort_ErrMsg22 = "Sie können die Portfunktion oder VLAN Einstellungen eines Switch-Ports nicht ändern, während Ihre Netzwerk Managementstation direkt an diesen Switch-Port angeschlossen ist und die SETUP LED grün leuchtet.";

var re_sPort_WngMsg1 = "Port {0} ist einem VLAN zugeordnet, das nicht existiert. Der Port wird dem Standardmanagement VLAN zugewiesen.";

//non-macchiato
var re_sPort_Grp1Ttl = "Empfohlene Systemeinrichtung";
var re_sPort_Grp2Ttl = "Empfohlene Porteinrichtung";

var re_sPort_GlblChkBox = "Aktivieren";
var re_sPort_AllPortsChkBox = "Die gewählte Porteinrichtung für alle Ports aktivieren";
var re_sPort_Txt1 = "Wählen Sie eine Porteinrichtung";
var re_sPort_Txt2 = "Klicken Sie auf einen Port, um die gewählte Porteinrichtung zu aktivieren.";

//tooltip
var re_sPort_LblSetup = "Einrichtung";

//customize table
var re_sPort_LblSetupType = "Einrichtungstyp";

//error messages
var re_sPort_ErrMsg1 = "Sie haben Anpassen angeklickt, ohne eine Porteinrichtung konfiguriert zu haben.";
var re_sPort_ErrMsg2 = "Die VLAN ID sollte nur Ganzzahlen enthalten. Geben Sie eine gültige VLAN ID ein.";
var re_sPort_ErrMsg3 = "Sie müssen eine VLAN ID eingeben, bevor Sie Fertig klicken.";
var re_sPort_ErrMsg4 = "{0} ist keine gültige VLAN ID. Geben Sie eine VLAN ID zwischen 1 und 1001 oder 1006 und 4094 ein.";
var re_sPort_ErrMsg5 = "{0} ist keine gültige VLAN ID. Geben Sie eine VLAN ID zwischen 1 und 1001 ein.";
var re_sPort_ErrMsg6 = "Das Gerät läuft in VTP Client Modus, daher können die neuen VLANs nicht in diesem Modus erstellt werden";
var re_sPort_ErrMsg7 = "Dieses Gerät unterstützt maximal {0} VLANs. Die folgenden VLANs können nicht verwendet werden {1}";
var re_sPort_ErrMsg8 = "Desktop Verbindungseinstellungen können nicht in den Ports {0} angelegt werden, weil sie mit nicht-Desktop Geräten verbunden sind.";

//new strings
var re_sPort_ErrMsg23 = "Ports mit der Portfunktion IP Phone+Desktop sollten zu anderen Zugangs-VLANs als Cisco-Voice gehören.";
var re_sPort_ErrMsg24 = "Nur Ports mit der Portfunktion IP Phone+Desktop oder Server können dem Cisco-Voice VLAN angehören.";

//additional strings - 03/06/06
var re_sPort_ErrMsg25 ="Sie haben auf 'Anpassen' geklickt, aber keine Portrolle konfiguriert.";
