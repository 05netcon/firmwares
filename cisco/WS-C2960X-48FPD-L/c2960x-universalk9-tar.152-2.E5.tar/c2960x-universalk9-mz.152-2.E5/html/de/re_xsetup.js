﻿/*
 *------------------------------------------------------------------
 * express setup resource file - includes express setup (incl. smartports info page), managed and recovery mode pages
 * Copyright (c) 2006-2010 by cisco Systems, Inc.
 * feature code - xSetup
 *------------------------------------------------------------------
*/

//macchiato
var re_xSetup_Ttl ="Schnelleinrichtung";// changed title from "Express Einrichtung" to "Schnelleinrichtung" as it is suggested by Julien during Stout support

var re_xSetup_LblMgmtIntMach = "Managementschnittstelle (VLAN)";
var re_xSetup_LblIPMode = "IP Zuordnungsmodus";
var re_xSetup_LblIPModeStatic = "Statik";
var re_xSetup_LblIPModeDHCP = "DHCP";
var re_xSetup_LblIPAddress = "IP Adresse";
var re_xSetup_LblSubnet = "Subnetzmaske";
var re_xSetup_LblDefGateway = "Standard Gateway";
var re_xSetup_LblUsrName = "Benutzername";
var re_xSetup_LblPwd = "Passwort";
var re_xSetup_LblConfPwd = "Passwort bestätigen";
var re_xSetup_LblHostName = "Hostname";
var re_xSetup_LblSysDate = "Systemdatum {(TT/MMM/JJJJ)}";
var re_xSetup_LblSysTime = "Systemzeit {(SS:MM)}";
var re_xSetup_LblTimeZone = "Zeitzone";
var re_xSetup_LblDST = "Sommerzeit";
var re_xSetup_LblEnable = "Aktivieren";

var re_xSetup_Grp1Ttl = "Netzwerkeinstellungen";
var re_xSetup_Grp1Tt2 = "Optionale Einstellungen";

var re_xSetup_Txt2 = "Der DHCP Server handelt die Switch IP Adresse neu aus. Verwenden Sie die neue Adresse zum Starten des Gerätemanagers.";

var re_xSetup_ErrMsg1 = "Fehler:\n\nGeben Sie eine VLAN ID zwischen 1 und 1001 ein.";
var re_xSetup_ErrMsg2 = "Fehler:\n\nGeben Sie eine IP Adresse für den Switch ein.";
var re_xSetup_ErrMsg4 = "Fehler:\n\nDie IP Adresse für den Switch und das Standard Gateway müssen demselben Subnet angehören.";
var re_xSetup_ErrMsg9 = "Fehler:\n\nDer Hostname darf weder ?, Leerstellen noch Tabulatoren enthalten.";
var re_xSetup_ErrMsg18 = "Fehler:\n\nDie IP Adresse für den Switch und das Standard Gateway darf nicht dieselbe sein.";
var re_xSetup_ErrMsg21 = "Fehler:\n\n\"{0}\" ist keine gültige IP Adresse. Geben Sie eine IP Adresse im x.x.x.x Format an, bei der x = 0 bis 255 sein kann.";
var re_xSetup_ErrMsg22 = "Fehler:\n\n{0} ist keine gültige IP Adresse.";
var re_xSetup_ErrMsg23 = "Fehler:\n\n\"{0}\" ist keine gültige IP Adresse für das Standard Gateway.\nGeben Sie eine IP Adresse im x.x.x.x Format an, bei der x = 0 bis 255 sein kann.";
var re_xSetup_ErrMsg25 = "Fehler:\n\nGeben Sie in diesem Feld eine Zahl von 0 bis {0} ein.";
var re_xSetup_ErrMsg26 = "Fehler:\n\n\"{0}\" ist keine gültige IP Adresse für das Standard Gateway.";

var re_xSetup_ConfMsg2 = "Warnung:\n\nDie IP Adresse dieses Geräts wird geändert. Die Express Einrichtung versucht\n, mit der neuen IP Adresse {0} eine Verbindung zu diesem Gerät herzustellen.\nFalls Ihre PC IP Adresse sich nicht im selben Subnet befindet wie diese neue IP Adresse,\ngeht die Verbindung mit diesem Gerät verloren. Klicken Sie OK, um fortzufahren und die \nneue IP Adresse zu übernehmen. Klicken Sie Abbrechen, um die neue IP Adresse nicht zu übernehmen.";
var re_xSetup_ConfMsg3 = "Warnung:\n\nEs ist keine IP Adresse für das Standard Gateway angegeben. Möchten Sie fortfahren?";
var re_xSetup_ConfMsg6 = "Warnung:\n\nDie Managementschnittstelle {0} wird mit dieser \nIP Adresse {1} konfiguriert.\n\nMöchten Sie fortfahren?";
var re_xSetup_ConfMsg7 = "Warnung:\n\nDie Managementschnittstelle {0} wird mit dieser \nIP Adresse {1} konfiguriert.\n\nUm mit dem Switch kommunizieren zu können, muss \ndem neuen Management VLAN mindestens ein Switchport zugeordnet sein.\n\nMöchten Sie fortfahren?";

var re_xSetup_ConfMsg8 = "Warnung:\n\nDie Managementschnittstelle {0} wird mit der vom DHCP Server zugewiesenen \nIP Adresse konfiguriert.\n\nMöchten Sie fortfahren?";
var re_xSetup_ConfMsg9 = "Warnung:\n\nDie Managementschnittstelle {0} wird mit der vom DHCP Server zugewiesenen\nIP Adresse konfiguriert.\n\nUm mit dem Switch zu kommunizieren, muss dem neuen Management VLAN \nmindestens ein Switchport zugeordnet sein.\n\nMöchten Sie fortfahren?";
var re_xSetup_ConfMsg10 = "Information:\n\nDer DHCP Server verhandelt die neue Switch IP Adresse. Daher\nkann sich die IP Adresse ändern. Falls dies geschieht, müssen Sie\ndie neue Adresse benutzen, um den Gerätemanager zu starten.\n\nMöchten Sie fortfahren?";

//express setup mode info page
var re_xSetup_InfoTxt1 = "Die anfängliche Switch-Konfigurierung ist abgeschlossen.";
var re_xSetup_InfoTxt2 = "Bevor Sie irgendwelche Geräte anschließen, können Sie die Switchleistung optimieren, indem Sie den Switchports Smartports Portfunktionen zuweisen. Portfunktionen bieten mehr Sicherheit, Zuverlässigkeit und bessere Leistung, indem sie Portfunktionen aufgrund des Geräts zuweisen, mit dem der Port verbunden wird. Sie können jeweils nur eine Portfunktion zuordnen oder eine Smartports Standardkonfigurierung aktivieren. Die Smartports Standardkonfigurierung würde diesem Switch die folgenden Portfunktionen zuordnen:";
var re_xSetup_InfoTxt3 = "Sie können auch Portfunktionen für Router, IP Telefone und andere Geräte zuordnen.";
var re_xSetup_InfoTxt4 = "Ports 1 bis 24 - Desktops und Computer";
var re_xSetup_InfoTxt5 = "High-Speed Ports 1 und 2 - Ethernet-Switche";
var re_xSetup_InfoTxt6 = "Ports 1 bis 24 - IP Telefone";
var re_xSetup_InfoTxt7 = "High-Speed Ports 1 und 2 - Ethernet-Switche";
var re_xSetup_InfoTxt8 = "Ports 1 bis 4 - Zugriffspunkte";
var re_xSetup_InfoTxt9 = "Ports 5 bis 24 - Desktops und Computer";
var re_xSetup_InfoTxt10 = "High-Speed Ports 1 und 2 - Ethernet-Switche";
var re_xSetup_InfoTxt11 = "High-Speed Ports 1 bis 8 - Server";
var re_xSetup_InfoTxt12 = "High-Speed Ports 9 bis 12 - Ethernet-Switche";

var re_xSetup_InfoChkBox1 = "Ja, Portfunktionen aktivieren und den Smartports Dialog anzeigen";
var re_xSetup_InfoChkBox2 = "Nein, danke.";

var re_xSetup_InfoErrMsg1 = "Sie haben Einreichen angeklickt, aber keine Option gewählt";
var re_xSetup_InfoPageTtl = "Smartports Information";

//recovery mode page
var re_xSetup_RecTtl = "Software Fehlerbehebung";
var re_xSetup_RecRadio1 = "Systemkonfigurierung löschen.";
var re_xSetup_RecRadio2 = "Booten mit werkseitig voreingestelltem IOS Image.";
var re_xSetup_RecRadio3 = "Systemkonfigurierung löschen und mit werkseitig voreingestelltem IOS Image booten.";

var re_xSetup_RecConfMsg1 = "Dies löscht alle benutzerdefinierten Switch-Einstellungen, einschließlich der IP Adresse, startet aber mit der existierenden Softwareversion neu. Zum Fortfahren klicken Sie OK.";
var re_xSetup_RecConfMsg2 = "Dies erhält alle benutzerdefinierten Switch-Einstellungen(einschließlich der IP Adresse) und startet den Switch mit Hilfe der werkseitigen Standardsoftware neu. Zum Fortfahren klicken Sie OK.";
var re_xSetup_RecConfMsg3 = "Dies löscht alle benutzerdefinierten Switch-Einstellungen (einschließlich der IP Adresse) und startet erneut mit der werkseitigen Standardsoftware. Zum Fortfahren klicken Sie OK.";
var re_xSetup_RecConfMsgTtl = "Warnung";

var re_xSetup_RecTxt1 = "Der Switch wird neu gestartet. Verwenden Sie die Express Einrichtung, um dem Switch eine IP Adresse zuzuordnen. Sehen Sie sich für das Verfahren die Erste Schritte Anleitung an.";
var re_xSetup_RecTxt2 = "Der Switch wird neu gestartet. Gegen Sie in einer Browser-Sitzung eine IP Adresse für den Switch ein, um den Gerätemanager anzuzeigen.";

//non-macchiato
var re_xSetup_LblMgmtInt = "Managementschnittstelle (VLAN ID)";
var re_xSetup_LblSwPwd = "Switch-Passwort";
var re_xSetup_LblConfirmSwPwd = "Switch-Passwort bestätigen";
var re_xSetup_LblTelnet = "Telnet-Zugriff";
var re_xSetup_LblTelnetPwd = "Telnet-Passwort";
var re_xSetup_LblConfTelnetPwd = "Telnet-Passwort bestätigen";
var re_xSetup_LblSnmp = "SNMP";
var re_xSetup_LblSnmpRead = "SNMP-Lese-Community";
var re_xSetup_LblSnmpWrite = "SNMP-Schreib-Community";
var re_xSetup_LblSysContact = "Systemkontakt";
var re_xSetup_LblSysLocation = "Systemstandort";
var re_xSetup_LblDisable = "Deaktivieren";

var re_xSetup_Txt1 = "Zur neuen IP Adresse umleiten....";

var re_xSetup_ErrMsg3 = "Fehler:\n\nDie IP Adressen 10.0.0.1 und 10.0.0.3 können im Express Einrichtungsmodus nicht verwendet werden.";
var re_xSetup_ErrMsg5 = "Fehler:\n\nDas Switch-Passwort darf nicht mit einer Leerstelle beginnen oder enden.";
var re_xSetup_ErrMsg6 = "Fehler:\n\nDas Telnet-Passwort darf nicht mit einer Leerstelle beginnen oder enden.";
var re_xSetup_ErrMsg7 = "Fehler:\n\nDas Switch-Passwort kann mit einer Zahl beginnen. Es ist die Groß- und Kleinschreibung zu beachten und es darf Leerstellen beinhalten. Es darf keine ? oder Tabulatoren enthalten.";
var re_xSetup_ErrMsg8 = "Fehler:\n\nGeben Sie in den Feldern Switch-Passwort und Switch-Passwort bestätigen dasselbe Passwort ein.";
var re_xSetup_ErrMsg10 = "Fehler:\n\nDer Systemkontaktname darf keine ? oder Tabulatoren enthalten.";
var re_xSetup_ErrMsg11 = "Fehler:\n\nDer Systemstandort darf keine ? oder Tabulatoren enthalten.";
var re_xSetup_ErrMsg12 = "Fehler:\n\nWenn Sie den Telnet-Zugriff aktivieren, müssen Sie ein Telnet Passwort eingeben. Das Telnet Passwort\ndarf keine ? oder Tabulatoren enthalten.";
var re_xSetup_ErrMsg13 = "Fehler:\n\nDas Telnet Passwort kann mit einer Zahl beginnen. Es ist die Groß- und Kleinschreibung zu beachten und es darf Leerstellen beinhalten. Es darf keine ? oder Tabulatoren enthalten.";
var re_xSetup_ErrMsg14 = "Fehler:\n\nGeben Sie in den Feldern Telnet Passwort und Telnet Passwort bestätigen dasselbe Passwort ein.";
var re_xSetup_ErrMsg15 = "Fehler:\n\nWenn Sie SNMP aktivieren, müssen Sie in mindestens einem der SNMP Community Felder einen Community String eingeben.";
var re_xSetup_ErrMsg16 = "Fehler:\n\nGeben Sie einen SNMP Community String ein, der keine ?, Leerstellen oder Tabulatoren enthält.";
var re_xSetup_ErrMsg17 = "Fehler:\n\nDie SNMP Read and Write Community Strings dürfen nicht gleich sein.";
var re_xSetup_ErrMsg19 = "Fehler:\n\nDas Switch-Passwort kann bis zu 25 alphanumerische Zeichen enthalten.";
var re_xSetup_ErrMsg20 = "Fehler:\n\nDas Telnet-Passwort darf 25 alphanumerische Zeichen enthalten.";
var re_xSetup_ErrMsg24 = "Fehler:\n\n{0} ist keine gültige Standard Gateway IP Adresse.";

var re_xSetup_WngMsg1 = "Warnung:\n\nSie müssen den Telnet-Zugriff aktivieren, bevor Sie ein Telnet-Passwort einrichten.";
var re_xSetup_WngMsg2 = "Warnung:\n\nSie müssen SNMP aktivieren, bevor Sie die Read/Write Community Strings einrichten.";
var re_xSetup_WngMsg3 = "Warnung:\n\nSie müssen zunächst SNMP aktivieren, bevor Sie den Systemkontakt/Speicherort einrichten.";

var re_xSetup_ConfMsg1 = "Warnung:\n\nDie IP Adresse dieses Geräts wird geändert.\nDie Verbindung zum Gerät geht möglicherweise verloren.\nMöchten Sie fortfahren?";
var re_xSetup_ConfMsg4 = "Warnung:\n\nDem Switch wurde kein Passwort zugewiesen. Möchten Sie fortfahren?";
var re_xSetup_ConfMsg5 = "Warnung:\n\nDie IP Adresse {0} steht in Konflikt mit der bereits \nkonfigurierten IP Adresse der/den folgenden Schnittstelle(n).\n\nDie Schnittstelle, \tIP Adresse, \tNetzmaske,\n{1}\nIP Adresse der o.g. Schnittstelle(n) wird zur Konfigurierung \nder IP Adresse {2} im Schnittstellen-VLAN {3} entfernt.\n\nMöchten Sie fortfahren?";

//new strings
var re_xSetup_Grp1Tt3="Kabellose Steuereinheiteinstellungen";
var re_xSetup_LblCtrllerStackNumber="Stapel{\n}Nummer";
var re_xSetup_LblCtrllerVlan="Management{\n}VLAN ID";

var re_xSetup_ErrMsg27="Fehler:\n\nGeben Sie eine IP-Adresse für die Steuereinheit ein.";
var re_xSetup_ErrMsg28="Fehler:\n\nGeben Sie ein Standardgateway für die Steuereinheit ein.";
var re_xSetup_ErrMsg29="Fehler:\n\nDie IP-Adresse für die Steuereinheit und das Standardgateway dürfen nicht identisch sein.";
var re_xSetup_ErrMsg30="Fehler:\n\nDie IP-Adresse für die Steuereinheit und das Standardgateway müssen zum gleichen Subnetzwerk gehören.";
var re_xSetup_ErrMsg31="Fehler:\n\nGeben Sie eine VLAN ID für die Steuereinheit zwischen 1 und 1000 ein.";
var re_xSetup_ErrMsg32="Fehler:\n\nGeben Sie eine VLAN ID für die Steuereinheit {0} zwischen 1 und 1000 ein.";
var re_xSetup_ErrMsg33="Fehler:\n\nGeben Sie eine VLAN ID für die Steuereinheit {0} zwischen 1 und 1000 ein.";
var re_xSetup_ErrMsg34="Fehler:\n\nGeben Sie eine IP-Adresse für die Steuereinheit {0} ein.";
//var re_xSetup_ErrMsg35="Fehler:\n\n\"{0}\" ist keine gültige IP-Adresse. Geben Sie eine IP-Adresse im x.x.x.x Format ein, wobei x den Wert 0 bis 255 haben darf.";
var re_xSetup_ErrMsg36="Fehler:\n\n{0} ist keine gültige IP-Adresse.";
var re_xSetup_ErrMsg37="Fehler:\n\nGeben Sie ein Standardgateway für die Steuereinheit {0} ein.";
//var re_xSetup_ErrMsg38="Fehler:\n\n\"{0}\" ist keine gültige IP-Adresse für das Standardgateway. \nGeben Sie eine IP-Adresse im x.x.x.x Format ein, wobei x den Wert 0 bis 255 haben darf.";
var re_xSetup_ErrMsg39="Fehler:\n\nDie IP-Adresse für die Steuereinheit {0} und das Standardgateway dürfen nicht identisch sein.";
var re_xSetup_ErrMsg40="Fehler:\n\nDie IP-Adresse für die Steuereinheit {0} und das Standardgateway müssen zum gleichen Subnetzwerk gehören.";
//var re_xSetup_ErrMsg41="Fehler:\n\n{0} ist keine gültige Standardgateway IP-Adresse.";

var re_xSetup_ErrMsg42 ="Fehler:\n\nDie IP-Adressen im {0} Netzwerk können auf diesem Switch nicht konfiguriert werden.";
var re_xSetup_ErrMsg43 ="Fehler:\n\nDem Switch wurde ein Benutzername zugewiesen, jedoch kein Passwort. Geben Sie ein Passwort ein.";
var re_xSetup_ErrMsg44 ="Fehler:\n\nDem Switch wurde ein Passwort zugewiesen, jedoch kein Benutzername. Geben Sie einen Benutzernamen ein.";
var re_xSetup_ErrMsg45 ="Warnung:\n\nDem Switch wurde weder ein Benutzername noch ein Passwort zugewiesen. Wollen Sie trotzdem fortfahren?";
var re_xSetup_ErrMsg46 ="Fehler:\n\nDas Passwort darf am Anfang und am Ende kein Leerzeichen haben.";
var re_xSetup_ErrMsg47 ="Fehler:\n\nDer Name darf aus bis zu 64 alphanumerischen Zeichen bestehen. \nlt enthält ein ?, ein Leerzeichen oder ein Tabulator.";
var re_xSetup_ErrMsg48 ="Fehler:\n\nDas Passwort darf mit einer Ziffer beginnen, achtet auf Groß- und Kleinschreibung und darf Leerzeichen enthalten. \nlt darf kein ? oder Tabulator enthalten.";
var re_xSetup_ErrMsg49 ="Fehler:\n\nGeben Sie in den Feldern Passwort und Passwort bestätigen das gleiche Passwort ein.";
var re_xSetup_ErrMsg50 ="Fehler:\n\nDas Passwort darf bis zu 25 alphanumerische Zeichen lang sein.";
var re_xSetup_ErrMsg51 ="Fehler:\n\nVLAN {0} steht nicht zur Verfügung. Geben Sie eine andere VLAN ID ein.";
var re_xSetup_ErrMsg52 ="Wird durch DHCP übertragen";

//additional strings - 03/06/06
var re_xSetup_ErrMsg53 ="Der Benutzername darf nur englische Buchstaben enthalten.";
var re_xSetup_ErrMsg54 ="Das Passwort darf nur englische Buchstaben enthalten.";
var re_xSetup_ErrMsg55 ="Der Hostname darf nur englische Buchstaben enthalten.";
var re_xSetup_ErrMsg56 ="Das Telnet-Passwort darf nur englische Buchstaben enthalten.";
var re_xSetup_ErrMsg57 ="Der SNMP Community-String darf nur englische Buchstaben enthalten.";
var re_xSetup_ErrMsg58 ="Der Systemkontakt darf nur englische Buchstaben enthalten.";
var re_xSetup_ErrMsg59 ="Der Systemstandort darf nur englische Buchstaben enthalten.";

var re_xSetup_ConfMsg14 = "Warnung:\n\nDie Zuweisung eines neuen Telnet-Passworts überschreibt die bestehende TACACS-Anmeldung für Telnet. Möchten Sie fortfahren?";

////New error message for hostname and username and password fields.
var re_xSetup_ErrMsg76 = "Fehler:\n\nGeben Sie einen Benutzernamen ein. Der Name kann maximal 64 alphanumerische Zeichen lang sein\n und nur die folgenden Zeichen enthalten: A-Z, a-z, 0-9, Bindestrich, Unterstrich und Punkt.";
var re_xSetup_ErrMsg77 = "Fehler:\n\nDas Passwort kann mit einer Zahl beginnen. Groß- und Kleinschreibung ist zu beachten.\nEs kann nur die folgenden Zeichen enthalten: A-Z, a-z, 0-9, Bindestrich, Unterstrich und Punkt.";
var re_xSetup_ErrMsg78 = "Fehler:\n\nDer Hostname kann nur die folgenden Zeichen enthalten: A-Z, a-z, 0-9, Bindestrich, Unterstrich und Punkt.";
var re_xSetup_ErrMsg80 = "Fehler:\n\n {0} ist kein gültiges Passwort.";

//for PSIRT
var re_xSetup_ErrMsg85 = "Geben Sie einen Benutzernamen ein. Er kann bis zu 64 alphanumerische Zeichen enthalten. Der Name darf keine ?, Leerstellen oder Tabulatoren enthalten.";
var re_xSetup_ErrMsg86 = "Der Benutzername und der Standardbenutzername dürfen nicht identisch sein.";
var re_xSetup_ErrMsg87 = "Geben Sie ein Switch-Passwort ein. Das Switch-Passwort kann mit einer Zahl beginnen und Leerstellen beinhalten.\nGroß- und Kleinschreibung ist zu beachten. Es darf keine ?, Tabulatoren oder einzelne Ziffern enthalten.";
var re_xSetup_ErrMsg88 = "Das Switch-Passwort muss sich vom Standardpasswort unterscheiden.";

//For mtu 11/11/09
var re_xSetup_LblMtu = "MTU";
var re_xSetup_LblMtuJumbo = "Jumbo-MTU";
var re_xSetup_LblMtuRouting = "Routing-MTU";
var re_xSetup_ErrMsg89 = "Geben Sie eine gültige MTU-Größe im Bereich von {0} bis {1} ein.";
var re_xSetup_ErrMsg90 = "Geben Sie eine gültige Jumbo-MTU-Größe im Bereich von {0} bis {1} ein.";
var re_xSetup_ErrMsg91 = "Geben Sie eine gültige Routing-MTU-Größe im Bereich von {0} bis {1} ein.";
var re_xSetup_ConfMsg16 = "Die geänderte MTU-Größe gilt erst ab dem nächsten Ladevorgang. Möchten Sie fortfahren?";
var re_xSetup_ConfMsg17 = "Die geänderte Jumbo-MTU-Größe gilt erst ab dem nächsten Ladevorgang. Möchten Sie fortfahren?";

var re_xSetup_ReloadWaitMsg = "Bitte warten. Der Neustart des Switches ist noch nicht abgeschlossen.";
var re_xSetup_ErrMsg67 = "Bitte warten. Der Switch wird neu geladen.";

//Strings added for Stout
var re_xSetup_tab_Lbl1 = "Grundlegende Einstellungen";
var re_xSetup_tab_Lbl2 = "Erweiterte Einstellungen";
var re_xSetup_Grp1Tt4 = "Einstellungen des Ethernet-Management-Ports";
var re_xSetup_Fa0IPBalloonHelp = "Wenn Ihre Managementstation über einen Ethernet-Management-Port (Fa0) verbunden ist, geben Sie eine IP-Adresse für den Port ein.";
var re_xSetup_Fa0IPBalloonHelp_lightsabre="IP-Adresse des Ethernet Management-Ports (Fa0).";

var re_xSetup_VlanIPBalloonHelp = "Falls Ihre Managementstation an einen Netzwerk-Port angeschlossen ist, geben Sie eine IP-Adresse für die VLAN-Verwaltungsoberfläche ein (VLAN-ID {0}).";

//Added during Surge xsetup support 3rd May'10.
var re_xSetup_ErrMsg92 = "Fehler:\n\nGeben Sie ein Passwort ein. Das Passwort für den Switch kann 1 bis 25 alphanumerische Zeichen enthalten und kann mit einer Ziffer beginnen. Es wird zwischen Groß-und Kleinschreibung unterschieden. Eingebettete Leerstellen sind erlaubt. Das Passwort kann nicht aus einem einzigen Zeichen bestehen, darf kein ? und keinen Tab enthalten und darf nicht mit einem Leerzeichen beginnen oder enden.";
var re_xSetup_ErrMsg93 = "Fehler:\n\n {0} ist kein gültiges Passwort. Das Passwort für den Switch kann 1 bis 25 alphanumerische Zeichen enthalten und kann mit einer Ziffer beginnen. Es wird zwischen Groß-und Kleinschreibung unterschieden. Eingebettete Leerstellen sind erlaubt. Das Passwort kann nicht aus einem einzigen Zeichen bestehen, darf kein ? und keinen Tab enthalten und darf nicht mit einem Leerzeichen beginnen oder enden.";
