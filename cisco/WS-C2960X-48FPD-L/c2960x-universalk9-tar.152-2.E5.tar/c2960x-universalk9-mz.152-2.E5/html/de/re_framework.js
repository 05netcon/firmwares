/*
 *------------------------------------------------------------------
 * framework resource file - includes SSL, bottom banner buttons, graph, appsui, telnet, network assistant
 * Copyright (c) 2006-2007 by cisco Systems, Inc.
 * feature code - frmWrk
 *------------------------------------------------------------------
*/

//feature pages
var re_frmWrk_WngMsg1 ="Sie haben auf 'Einreichen' geklickt, ohne �nderungen in der Dialogbox einzugeben.";
var re_frmWrk_WngMsg1Ttl = "Information";

//appsui
var re_frmWrk_ErrMsgDefTtl = "Fehler";
var re_frmWrk_WngMsgDefTtl = "Warnung";
var re_frmWrk_ConfMsgDefTtl = "Achtung";

//framework
var re_frmWrk_ConfMsg1 = "Warnung:\n\nDiese Seite enth�lt ungesicherte �nderungen.\n\nKlicken Sie OK, um die �nderungen zu speichern, oder Abbrechen, um sie zu verwerfen und fortzufahren.";
var re_frmWrk_ConfMsgWindowClose = "Diese Seite enth�lt ungesicherte �nderungen.";
//no handler messages
var re_frmWrk_ErrMsgNoApply = "Kein Anwender verf�gbar f�r �bernehmen.";
var re_frmWrk_ErrMsgNoCancel = "Kein Anwender verf�gbar f�r Abbrechen.";
var re_frmWrk_ErrMsgNoNext = "Kein Anwender verf�gbar f�r Weiter.";
var re_frmWrk_ErrMsgNoBack = "Kein Anwender verf�gbar f�r Zur�ck.";
var re_frmWrk_ErrMsgNoFinish = "Kein Anwender verf�gbar f�r Beenden.";
var re_frmWrk_ErrMsgNoHelp = "Keine Hilfe verf�gbar";

//xhome
var re_frmWrk_TxtFrmSupport = "Diese Seiten verwenden Frames. Bitte achten Sie darauf, dass der Browser die Frame-Funktion vollst�ndig unterst�tzt!";

//graph
var re_frmWrk_GraphLegend = "Legende";

var re_frmWrk_GraphEmpty = "[leere Grafik]";
var re_frmWrk_GraphTimeSlots = "Zeitrahmen";

var re_frmWrk_GraphLblDay1 = "Son"; 
var re_frmWrk_GraphLblDay2 = "Mon"; 
var re_frmWrk_GraphLblDay3 = "Die"; 
var re_frmWrk_GraphLblDay4 = "Mit"; 
var re_frmWrk_GraphLblDay5 = "Don"; 
var re_frmWrk_GraphLblDay6 = "Fre"; 
var re_frmWrk_GraphLblDay7 = "Sam"; 

var re_frmWrk_GraphLblMonth1 = "Jan"; 
var re_frmWrk_GraphLblMonth2 = "Feb"; 
var re_frmWrk_GraphLblMonth3 = "M�r"; 
var re_frmWrk_GraphLblMonth4 = "Apr"; 
var re_frmWrk_GraphLblMonth5 = "Mai"; 
var re_frmWrk_GraphLblMonth6 = "Jun"; 
var re_frmWrk_GraphLblMonth7 = "Jul"; 
var re_frmWrk_GraphLblMonth8 = "Aug"; 
var re_frmWrk_GraphLblMonth9 = "Sep"; 
var re_frmWrk_GraphLblMonth10 = "Okt"; 
var re_frmWrk_GraphLblMonth11 = "Nov"; 
var re_frmWrk_GraphLblMonth12 = "Dez"; 

var re_frmWrk_GraphLblTimeAM = "vormittag";
var re_frmWrk_GraphLblTimePM = "nachmittag";
var re_frmWrk_GraphLblTitle = "Titel";

//SSL dialog
var re_frmWrk_SSLTxt1 = "M�chten Sie zum Switch eine gesicherte Sitzung aufbauen?";
var re_frmWrk_SSLTxt2 = "Nicht noch einmal fragen";
var re_frmWrk_SSLBtn1 = "Ja";
var re_frmWrk_SSLBtn2 = "Nein";

//bottom frame button names
var re_frmWrk_BtnDone = "Fertig";
var re_frmWrk_BtnBack = "Zur�ck";
var re_frmWrk_BtnNext = "Weiter";
var re_frmWrk_BtnFinish = "Beenden";
var re_frmWrk_BtnCancel = "Abbrechen";
var re_frmWrk_BtnRefresh = "Aktualisieren";
var re_frmWrk_BtnHelp = "Hilfe";
var re_frmWrk_BtnSubmit = "Einreichen";

//network assistant
var re_frmWrk_CNATtl = "Network Assistant";

//non-macchiato
//telnet
var re_frmWrk_TelnetTtl = "Telnet";
var re_frmWrk_TelnetTxt = "Die Telnet-Konsole bietet Zugriff auf die Switch CLI Schnittstelle. CLI ist eine erweiterte Methode der Kommunikation mit Ihrem Cisco Switch und wird nur f�r Experten empfohlen. Die Telnet-Konsole startet in einem neuen Fenster.";
var re_frmWrk_TelnetLinkTxt1 = "Starten Sie eine Telnet-Konsole";
var re_frmWrk_TelnetLinkTxt2 = "Telnet ist auf diesem Ger�t nicht aktiviert. Wechseln Sie zu {Express Einrichtung} und aktivieren Sie Telnet.";

//new Strings

//OLH message
var re_frmWrk_OLHErrMsg1="Information:\n\nDie Onlinehilfe steht f�r dieses Fenster nicht zur Verf�gung{0}. Um die Onlinehilfe in {0} anzuzeigen, m�ssen Sie zuerst den Switch mit der {0} Software f�r Switches von Cisco.com erweitern.";

var re_restart_Ttl= "Neu starten / Zur�cksetzen";
var re_restart_txt1="Starten Sie den Switch mit seinen laufenden Einstellungen neu.";
var re_restart_txt2="Setzen Sie den Switch auf die Standardeinstellungen zur�ck und starten Sie den Switch neu.";
var re_restart_txt3="Ger�t wird in {0} Sekunde(n) neu geladen.";
var re_restart_txt4="Ger�t wird neu geladen...";
var re_restart_txt5="Ger�t wurde erfolgreich neu geladen.";
var re_restart_txt6="Erneutes Laden in Bearbeitung....";
var re_restart_ConfMsg1="Das Ger�t wird auf die Standardeinstellungen zur�ckgesetzt und die aktuelle IP-Adresse gel�scht. Wollen Sie fortfahren?";
var re_toolbar_txt_refresh="Aktualisierung";
var re_toolbar_txt_print="Drucken";
var re_toolbar_txt_smartports="Smartports";
var re_toolbar_txt_swupgrade="Software Upgrade";
var re_toolbar_txt_legend="Legende";
var re_toolbar_txt_help="Hilfe";
var re_toolbar_txt_forward="Vorw�rts";
var re_toolbar_txt_back="Zur�ck";

//network assistant
var re_frmWrk_CNATxt1="Der Cisco Network Assistant bietet eine zentralisierte Konfiguration und{\n} Verwaltung f�r Cisco Switches, Router und kabellosen Zugriffs{\n}punkten f�r kleine und mittlere Gesch�ftsnetzwerke an.";
var re_frmWrk_CNATxt2="Einzelpunkt f�r Netzwerkmanagement";
var re_frmWrk_CNATxt3="Intelligente Ger�tekonfiguration";
var re_frmWrk_CNATxt4="Vereinfachte Netzwerk�berwachung und Fehlerbehebung";
var re_frmWrk_CNATxt5="Eingebaute Suchfunktion und Onlinehilfe";
var re_frmWrk_CNATxt6="KOSTENLOSES ZUS�TZLICHES LERNEN und NETWORK ASSISTANT DOWNLOAD!";

//Strings newly added for Uptime display - 03/28/06
var re_Uptime_years ="Jahre";
var re_Uptime_year ="Jahr";
var re_Uptime_weeks ="Wochen";
var re_Uptime_week ="Woche";
var re_Uptime_days ="Tage";
var re_Uptime_day ="Tag";
var re_Uptime_hours ="Stunden";
var re_Uptime_hour ="Stunde";
var re_Uptime_minutes ="Minuten";
var re_Uptime_minute ="Minute";

//Telnet Not supported message for Vista
var re_frmWrk_TelnetLinkTxt3 = "Die Telnet-Funktion ist nicht verf�gbar, wenn Ihr Betriebssystem Windows Vista ist oder Sie Internet Explorer 7.0 verwenden.";


