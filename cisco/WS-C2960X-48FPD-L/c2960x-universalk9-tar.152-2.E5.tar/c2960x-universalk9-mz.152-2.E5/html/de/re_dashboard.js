/*
 *------------------------------------------------------------------
 * dashboard resource file
 * Copyright (c) 2006, 2009 by cisco Systems, Inc.
 * feature code - dshBrd
 *------------------------------------------------------------------
*/

//macchiato
var re_dshBrd_Ttl = "Dashboard";

var re_dshBrd_LblHostName = "Hostname";
var re_dshBrd_LblProductID = "Produkt ID";
var re_dshBrd_LblIPAddress = "IP Adresse";
var re_dshBrd_LblMacAddress = "MAC Adresse";
var re_dshBrd_LblVersionID = "Version ID";
var re_dshBrd_LblSNum = "Seriennummer";
var re_dshBrd_LblSoftware = "Software";
var re_dshBrd_LblContact = "Kontakt";
var re_dshBrd_LblLocation = "Speicherort";
var re_dshBrd_LbBwUsed = "Verwendete Bandbreite";

var re_dshBrd_LblPktError = "Paketfehler";
var re_dshBrd_LblPwrUtil = "PoE Nutzung";
var re_dshBrd_LblFan = "Fan";
var re_dshBrd_LblTemp = "Temp";

var re_dshBrd_Txt1 = "OK";
var re_dshBrd_Txt6 = "DEFEKT";

var re_dshBrd_TltpBwUsed = "Verwendete Bandbreite";
var re_dshBrd_TltpPktError = "Paketfehler";
var re_dshBrd_TltpPwrUsed = "Verwendete Energie";
var re_dshBrd_TltpPwrRemain = "Verbleibende Energie";
var re_dshBrd_TltpFanOk = "FAN ist OK";
var re_dshBrd_TltpFanFaulty = "FAN ist DEFEKT";
var re_dshBrd_TltpTempOk = "Temp ist OK";
var re_dshBrd_TltpTempFaulty = "Temp ist DEFEKT";

var re_dshBrd_Grp1Ttl = "Switch Information";
var re_dshBrd_Grp1Tt2 = "Switch Health";
var re_dshBrd_Grp1Tt3Mach = "Portnutzung/Fehler";

var re_dshBrd_Link1 = "Trends anzeigen";
var re_dshBrd_Link2 = "Portstatistik anzeigen";

var re_dshBrd_Radio1 = "Portnutzung";
var re_dshBrd_Radio2 = "Portfehler";

var re_dshBrd_ErrMsg1 = "Bandbreite CLI wird nicht unterst�tzt. Bitte aktualisieren Sie auf ein unterst�tzendes IOS Image.";

var re_dshBrd_GraphLegendTxt1 = "Empfangen";
var re_dshBrd_GraphLegendTxt2 = "�bertragen";
var re_dshBrd_GraphXAxis = "Ports";

//non-macchiato
var re_dshBrd_LblType = "Typ";
var re_dshBrd_Grp1Tt3 = "Portnutzung";
var re_dshBrd_LblStackBwUsed = "Verwendete Stapelbandbreite";
var re_dshBrd_LblStackPktError = "Stapelpaketfehler";

var re_dshBrd_Txt2 = "FAN 1 OK";
var re_dshBrd_Txt3 = "FAN 1 DEFEKT";
var re_dshBrd_Txt4 = "FAN 2 OK";
var re_dshBrd_Txt5 = "FAN 2 DEFEKT";
var re_dshBrd_LblInlinePwrUtil = "Inline Stromverwendung";

//new strings
var re_dshBrd_Grp1Tt4="Steuerungsinformation";

//additional strings - 03/06/06
var re_dshBrd_TxtIPDHCP ="Mit DHCP verhandelt";
var re_dshBrd_TltpFan1Ok ="GEBL�SE 1 ist OK";
var re_dshBrd_TltpFan1Faulty ="GEBL�SE 1 ist FEHLERHAFT";
var re_dshBrd_TltpFan2Ok ="GEBL�SE 2 ist OK";
var re_dshBrd_TltpFan2Faulty ="GEBL�SE 2 ist FEHLERHAFT";
var re_dshBrd_TltpTemperatureOk ="Temperatur ist OK";
var re_dshBrd_TltpTemperatureFaulty ="Temperatur ist fehlerhaft";
var re_dshBrd_TltpPort ="Port";
var re_dshBrd_TltpUtilization ="Nutzung";

var re_dshBrd_TxtWarning = "Warnung";

//For Stout 11/11/09
re_dshBrd_LblEthMgmtPortIP = "IP-Adresse des{0}Ethernet Management-Ports";