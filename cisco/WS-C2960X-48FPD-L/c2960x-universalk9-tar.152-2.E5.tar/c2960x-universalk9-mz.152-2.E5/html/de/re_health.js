/*
 *------------------------------------------------------------------
 * health resource file
 * Copyright (c) 2006 by cisco Systems, Inc.
 *------------------------------------------------------------------
*/
// NOTE: This file is shared by dashboard and trends page.


//Title
var re_trend_ScrTtl="Trends";

//Resource content for dashboard
var re_trend_ports_Lbl="Ports";
var re_trend_viewtrends_Lbl="Trends anzeigen";

//Table header
var re_trend_TblHeader1="Switch Health";
var re_trend_TblHeader2="Portnutzung";
var re_trend_TblHeader3="Portnutzung/Fehler";
var re_trend_title_Lbl="Titel";


//Table content
var re_trend_bandutil_Lbl="Bandbreitennutzung";
var re_trend_stkbandutil_Lbl="Stapelbandbreitennutzung";
var re_trend_packeterr_Lbl="Paketfehler";
var re_trend_stkpacketerr_Lbl="Stapelpaketfehler";
var re_trend_inpwrutil_Lbl="Inline Stromnutzung";
var re_trend_poeutil_Lbl="PoE Nutzung";
var re_trend_timeslot_Lbl="Zeitrahmen";
var re_trend_pwrutil_Lbl="Stromnutzung";

var re_trend_recutil_Lbl="Nutzung empfangen";
var re_trend_transutil_Lbl="Nutzung �bertragen";
var re_trend_receive_Lbl="Empfangen";
var re_trend_transmit_Lbl="�bertragen";


//Tooltip
var re_trend_TltpLbl4="Nutzung";

//link
var re_trend_viewportstat_Lbl="Portstatistik anzeigen";

var re_trend_sec_Lbl="Sekunden";
var re_trend_min_Lbl="Minuten";
var re_trend_hrs_Lbl="Stunden";
var re_trend_day_Lbl="Tage";

var re_trend_ls_Lbl="Letzte 60 Sekunden";
var re_trend_lm_Lbl="Letzte 60 Minuten";
var re_trend_lh_Lbl="Letzte 24 Stunden";
var re_trend_ld_Lbl="Letzte 14 Tage";

var re_trend_rfsh_Lbl="Aktualisierungszyklus";
var re_trend_porterr_Lbl="Portfehler";
var re_trend_port_Lbl="Port";

//non-macchiato
var re_trend_connport_Lbl="Angeschlossener Port";
var re_trend_noport_Txt="An diesem Ger�t sind keine Ports angeschlossen";
