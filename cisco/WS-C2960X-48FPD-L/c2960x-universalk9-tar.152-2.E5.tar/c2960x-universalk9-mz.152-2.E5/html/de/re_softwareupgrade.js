﻿/*
 *------------------------------------------------------------------
 * software upgrade resource file
 * Copyright (c) 2006, 2010 by cisco Systems, Inc.
 * feature code - swUpg
 *------------------------------------------------------------------
*/

//macchiato

var re_swUpg_Ttl = "Software Upgrade";
var re_swUpg_Btn1 = "Upgrade";

var re_swUpg_Txt1 = "Der Switch betreibt die Cisco IOS Software-Version";
var re_swUpg_Txt2 = "Wechseln Sie zu {0}, wo Sie die neueste Cisco IOS Software (in Tar Dateiformat) für den Switch finden.";
var re_swUpg_Txt3 = "Laden Sie die Tar Datei auf Ihren PC oder ein Netzlaufwerk herunter.";
var re_swUpg_Txt4 = "Wählen Sie die Tar Datei zum Erweitern mit der ... Browsertaste.";
var re_swUpg_Txt5 = "Klicken Sie auf Upgrade.";

var re_swUpg_FileSuchen = "Dateinamen";

var re_swUpg_Grp1Ttl = "Status";
var re_swUpg_TblHeader1Mach = "Phase";
var re_swUpg_TblHeader2Mach = "Dateigröße";

var re_swUpg_ConfMsg1 = "Warnung:\n\nSie sind dabei, die Switch-Software zu aktualisieren. Verwenden oder schließen Sie diese\nBrowser-Sitzung nicht, bis das Update abgeschlossen ist. Wenn der\nUpgrade-Vorgang beendet ist, schließen Sie die Browser-Sitzung und zeigen den \nGerätemanager in einer neuen Browser-Sitzung an.\n\nKlicken Sie OK, um den \nUpgrade fortzusetzen, oder Abbrechen, um ihn zu beenden";

var re_swUpg_ErrMsg1 = "Fehler:\n\nKlicken Sie Browser, um das Switch-Image (Tar Datei) auf Ihrem PC zu navigieren.";
var re_swUpg_ErrMsg2 = "Fehler: Das Switch-Software-upgrade wird in einer anderen Sitzung durchgeführt.";
var re_swUpg_ErrMsg3 = "Software Upgrade wird durchgeführt!";

var re_swUpg_Txt_Stage1Mach = "Tar Datei wird auf den Switch hochgeladen";
var re_swUpg_Txt_Stage2Mach = "Tar Datei geladen";
var re_swUpg_Txt_Stage3Mach = "Erneutes Laden anstehend";
var re_swUpg_Txt_Stage4Mach = "Upgrade fehlgeschlagen";

var re_swUpg_Txt_ImageInstalled = "Neues Software-Abbild wurde installiert. Gerät wird neu gestartet. {0}Bitte warten! Es kann bis zu 5 min. dauern, bis eine neue Verbindung hergestellt werden kann.";
var re_swUpg_Txt_UpgInComplete = "Switch ist noch nicht neu geladen, Gerätemanager wartet auf Reaktion vom Gerät.";
var re_swUpg_Txt_UpgComplete = "Die Switch-Software wurde aktualisiert. Um die neueste Software zu verwenden, beenden Sie die laufende Sitzung des Gerätemanagers und starten Sie eine neue.";
var re_swUpg_Txt_ArchiveStatusMsg = "Die Software wurde erfolgreich erweitert. Um die neueste Software zu verwenden, beenden Sie die laufende Sitzung des Gerätemanagers und starten Sie eine neue.";

var re_swUpg_ErrMsg4 = "Fehler: Der vorangehende Upgrade war nicht erfolgreich oder wurde abgebrochen. Es wurde kein Clean-up durchgeführt.";
var re_swUpg_ErrMsg5 = "Fehler: Der Switch verfügt nicht über genügend Speicherplatz, um das neue Software-Image zu installieren.";
var re_swUpg_ErrMsg6 = "Fehler: Die Datei ist keine gültige Cisco IOS Tar Datei.";
var re_swUpg_ErrMsg7 = "Fehler: Die Software-Image-Datei eignet sich nicht für diesen Switch.";
var re_swUpg_ErrMsg8 = "Fehler: Die Software-Image-Datei ist beschädigt. Laden Sie das Software-Image nochmals von Cisco.com herunter.";
var re_swUpg_ErrMsg9 = "Fehler: Der Switch verfügt nicht über genügend Speicherplatz, um das neue Software-Image zu untersuchen.";
var re_swUpg_ErrMsg10 = "Fehler: Datei existiert nicht";
var re_swUpg_ErrMsg11 = "Fehler: Image kann nicht entpackt werden.";
var re_swUpg_ErrMsg12 = "Fehler: Nicht definiert";


//non-macchiato
var re_swUpg_TblHeader1 = "Phase";
var re_swUpg_TblHeader2 = "Status";

var re_swUpg_Txt_Stage1 = "1. Laden Sie die Tar Datei auf den Switch";
var re_swUpg_Txt_Stage2 = "2. Tar Datei wird verifiziert";
var re_swUpg_Txt_Stage3 = "3. Softwaredateien werden aus der Tar Datei entpackt";
var re_swUpg_Txt_Stage4 = "4. Switch wird neu gestartet";

var re_swUpg_Txt_RestartSwitch = "Bitte warten! Es kann bis zu 5 min. dauern, bis die Verbindung wiederhergestellt wird.";

//additional strings - 03/06/06
var re_swUpg_TltpInProgress ="wird durchgeführt";
var re_swUpg_TltpCompleted ="fertig";
var re_swUpg_TltpFailed ="gescheitert";
var re_swUpg_Txt_Stage5Mach ="Image-Download abgeschlossen";
var re_swUpg_Txt_noUpgradeinProgress="Es wird keine Software Upgrade durchgeführt.";
var re_swUpg_Txt_UpgradeInAnotherSession="Die Software wird bereits in einer anderen Sitzung aktualisiert!";

//new strings - 03/28/06
var re_swUpg_ErrMsg13 ="Fehler: Sie können Cisco IOS 12.2(25)FY nicht auf diesem Switch installieren. Aktualisieren Sie den Switch auf Cisco IOS 12.2(25)SEG oder neuer.";
var re_swUpg_ErrMsg14 ="Fehler: Es ist nicht genügend Speicherplatz auf dem Switch vorhanden, um das neue Software-Image zu laden. Das laufende Software-Image wurde entfernt. Der Switch lädt nun wieder das werkseitige Software-Image.";
var re_swUpg_Txt_UcodeBoot ="Der Switch wurde mit dem werkseitigen Software-Image neu geladen. Beenden Sie Ihre laufende Gerätemanagersitzung und beginnen Sie eine neue.";

var re_swUpg_ErrMsg15 ="Fehler: Sie können Cisco IOS 12.2 (25) FY nicht auf diesem Switch installieren. Aktualisieren Sie den Switch auf Cisco IOS 12.2(25)SEG oder neuer. Das aktuelle Software-Image wurde entfernt. Der Switch lädt nun das werkseitige Software-Image.";
