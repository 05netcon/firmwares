/*
 *------------------------------------------------------------------
 * Resource file for Port settings
 * Copyright (c) 2006 by cisco Systems, Inc.
 *------------------------------------------------------------------
*/

//title
var re_pSet_Scr1Ttl="Porteinstellungen";

//Table headers

var re_pSet_TblHeader1="Port";
var re_pSet_TblHeader2="Beschreibung";
var re_pSet_TblHeader3="Aktivieren";
var re_pSet_TblHeader4="Geschwindigkeit";
var re_pSet_TblHeader5="Duplex";
var re_pSet_TblHeader6="PoE";
var re_pSet_TblHeader7="Auto-MDIX";
var re_pSet_TblHeader8="Inline Strom";

//Warning messages.
var re_pSet_ErrMsg1="FEHLER: Port ist Null";
var re_pSet_ErrMsg2="Die Portbeschreibung darf keine ? oder Tabulatoren enthalten.\n";
var re_pSet_ErrMsg3="Die Portbeschreibung darf nicht mehr als 18 Zeichen enthalten.\n";
var re_pSet_ErrMsg4="Sie k�nnen Auto-MDIX nicht auf einem 1000BASE-SX SFP Port aktivieren.\n";
var re_pSet_ErrMsg5="Sie k�nnen Auto-MDIX nicht auf einem 1000BASE -LX SFP Port aktivieren.\n";
var re_pSet_ErrMsg6="Sie k�nnen Auto-MDIX nicht auf dem {0} Port aktivieren. Dieser Port ist deaktiviert.\n";
var re_pSet_ErrMsg7="Sie k�nnen Auto-MDIX nicht auf dem {0} Port aktivieren. Sowohl Geschwindigkeit, als auch Duplex von Port {1} sollten auf Automatik eingestellt sein.\n";
var re_pSet_ErrMsg8="Sie k�nnen Auto-MDIX auf dem {0} Port nicht deaktivieren. Dieser Port ist deaktiviert.\n";
var re_pSet_ErrMsg9="Sie k�nnen w�hrend der Anfangseinrichtung die Managementschnittstelle {0} nicht deaktivieren.\n";
var re_pSet_ErrMsg10="Sie k�nnen w�hrend der Anfangseinrichtung die Auto-MDIX Einstellung auf der Managementschnittstelle  {0} nicht �ndern.\n";
var re_pSet_ErrMsg11="Sie k�nnen w�hrend der Anfangseinrichtung die Geschwindigkeitseinstellung der Managementschnittstelle {0} nicht �ndern.\n";
var re_pSet_ErrMsg12="Sie k�nnen w�hrend der Anfangseinrichtung die Portgeschwindigkeit nicht von {0} auf 1000 Mbps wechseln, wenn sich der Port im Halb-Duplex Modus befindet.\n";
var re_pSet_ErrMsg13="Sie k�nnen w�hrend der Anfangseinrichtung die Portgeschwindigkeit nicht von {0} auf 'Auto' wechseln, wenn sich der Port im Halb-Duplex Modus befindet.\n";
var re_pSet_ErrMsg14="Sie k�nnen w�hrend der Anfangseinrichtung nicht die Duplexeinstellung der Managementschnittstelle {0} �ndern.\n";
var re_pSet_ErrMsg15="Die Duplexeinstellung auf diesem {0} Port kann nicht auf 'halb' gestellt werden, da die Geschwindigkeit auf 'Automatik' eingestellt ist.\n";
var re_pSet_ErrMsg16="Sie k�nnen die Portgeschwindigkeit nicht von {0} auf 1000 Mbps wechseln, wenn sich der Port im Halb-Duplex Modus befindet.\n";
var re_pSet_ErrMsg17="Sie k�nnen w�hrend der Anfangseinrichtung nicht die PoE Einstellung der Managementschnittstelle {0} �ndern.\n";

//additional strings - 03/06/06
var re_pSet_ErrMsg18="Sie k�nnen den Portduplex {0} nicht auf die H�lfte einstellen, wenn die Portgeschwindigkeit 1000 Mbps ist.\n";
var re_pSet_ErrMsg19="Die Portbeschreibung darf nur englishe Buchstaben enthalten.\n";

